# VideoLooper

VideoLooper is an iOS app which demonstrates looping playback of visual media file with AVQueuePlayer and AVPlayerLooper. 

## Requirements

### Build

Xcode 8.0 or later; iOS 10.0 SDK or later

### Runtime

iOS 10.0 or later

Copyright (C) 2016 Apple Inc. All rights reserved.