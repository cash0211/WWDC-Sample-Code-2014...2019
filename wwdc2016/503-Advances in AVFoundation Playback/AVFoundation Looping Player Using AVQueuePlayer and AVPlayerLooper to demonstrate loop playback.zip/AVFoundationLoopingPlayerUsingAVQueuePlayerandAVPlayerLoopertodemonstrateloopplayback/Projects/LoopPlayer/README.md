# LoopPlayer

LoopPlayer is a simple OS X command line tool which takes as input a media file and then creates AVQueuePlayer to play the media in a loop.

## Requirements

### Build

Xcode 8.0 or later; OS X 10.9 SDK or later

### Runtime

OS X 10.9 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
