/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The Application Delegate is an object which receives notifications when the UIApplication object reaches certain states.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
}

