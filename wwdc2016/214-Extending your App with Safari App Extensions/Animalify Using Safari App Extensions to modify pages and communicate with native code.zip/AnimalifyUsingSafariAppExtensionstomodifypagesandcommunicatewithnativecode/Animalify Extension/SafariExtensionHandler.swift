/*
    Copyright (C) 2016 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    The principal object for the Animalify Extension. This object receives messages from the content script injected by this extension into web pages, and responds with the words to replace and what to replace them with.
*/

import SafariServices

class SafariExtensionHandler: SFSafariExtensionHandler {
    
    override func messageReceived(withName messageName: String, from page: SFSafariPage, userInfo: [String : Any]? = nil) {
        if messageName == "GetWordsAndReplacements" {
            page.dispatchMessageToScript(withName: "WordsAndReplacements", userInfo: ["Bear": "🐻", "Fish": "🐠"]);
        }
    }

}
