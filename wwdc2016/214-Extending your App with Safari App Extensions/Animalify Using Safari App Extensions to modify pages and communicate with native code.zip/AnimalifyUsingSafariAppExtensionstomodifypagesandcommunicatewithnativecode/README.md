# Animalify: Using Safari App Extensions to modify pages and communicate with native code

This sample demonstrates how a Safari App Extension can modify the contents of webpages that its users visit, and how scripts injected into pages by the Safari App Extension can communicate with the app extension’s native code.

## Requirements

### Build

Xcode 8.0 or later; macOS 10.12 SDK or later

### Runtime

macOS 10.12 or later, or OS X 10.11 with Safari 10.0 or later.

Note: By default this extension will not be signed. To use it in Safari, open the Develop menu and select "Allow Unsigned Extensions".

Copyright (C) 2016 Apple Inc. All rights reserved.
