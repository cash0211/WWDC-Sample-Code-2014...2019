# AVCamBarcode

Using AVFoundation to Detect Barcodes and Faces

## Overview

AVCamBarcode demonstrates how to use the AVFoundation capture API to detect barcodes and faces.

## Requirements

### Build

Xcode 9.0, iOS 11.0 SDK

### Runtime

iOS 11.0 or later

Copyright (C) 2017 Apple Inc. All rights reserved.
