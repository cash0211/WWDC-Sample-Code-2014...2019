/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Provides the header for the view controller for the camera interface.
*/

@import UIKit;

@interface AVCamCameraViewController : UIViewController

@end
