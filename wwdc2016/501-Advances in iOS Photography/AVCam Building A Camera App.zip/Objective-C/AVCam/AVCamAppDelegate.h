/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Provides the header for the application delegate.
*/

@import UIKit;

@interface AVCamAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic) UIWindow *window;

@end
