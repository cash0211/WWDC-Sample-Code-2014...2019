# StarterPlaygroundBook: A simple Swift Playground Book

This sample demonstrates the structure of a simple Swift Playground Book. 

## Requirements 

iOS 10.0 or later; Swift Playgrounds 1.0 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
