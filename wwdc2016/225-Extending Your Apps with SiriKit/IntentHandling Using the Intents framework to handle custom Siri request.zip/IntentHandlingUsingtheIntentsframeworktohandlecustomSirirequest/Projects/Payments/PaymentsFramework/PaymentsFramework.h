/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The main header for PaymentsFramework
 */

#import <UIKit/UIKit.h>

//! Project version number for PaymentsFramework.
FOUNDATION_EXPORT double PaymentsFrameworkVersionNumber;

//! Project version string for PaymentsFramework.
FOUNDATION_EXPORT const unsigned char PaymentsFrameworkVersionString[];
