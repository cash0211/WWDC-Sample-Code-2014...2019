/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The main header for AscentFramework
 */

#import <UIKit/UIKit.h>

//! Project version number for AscentFramework.
FOUNDATION_EXPORT double AscentFrameworkVersionNumber;

//! Project version string for AscentFramework.
FOUNDATION_EXPORT const unsigned char AscentFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AscentFramework/PublicHeader.h>


