# APFSCloning: Using clone APIs with APFS

This sample demonstrates use of the COPYFILE_CLONE option for copyfile(3) and clonefileat(2) for cloning of files on APFS.

## Requirements

### Build

Xcode 8.0 or later; OS X 10.12 SDK or later

### Runtime

OS X 10.12 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
