# BasicNeuralNetworkSubroutines: Using The Accelerate Framework's Convolution Filters

BasicNeuralNetworkSubroutines (BNNS) is a new addition to the Accelerate framework. It provides optimized low-level functions dedicated to Machine Learning algorithms. Convolution filters are the main consumer of energy in Deep Neural Networks for image processing. This sample shows how to create and apply a convolution filter on a stack of images. 

## Requirements

### Build

Xcode 8.0 or later; OS X 10.12 SDK or later

### Runtime

OS X 10.12 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
