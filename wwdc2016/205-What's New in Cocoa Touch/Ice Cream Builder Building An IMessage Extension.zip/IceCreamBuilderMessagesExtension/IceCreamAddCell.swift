/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A `UICollectionViewCell` subclass used to display an add button in the `IceCreamsViewController`.
*/

import UIKit

class IceCreamAddCell: UICollectionViewCell {

    static let reuseIdentifier = "IceCreamAddCell"
    
}
