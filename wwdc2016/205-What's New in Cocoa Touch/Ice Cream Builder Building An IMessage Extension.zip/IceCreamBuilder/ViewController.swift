/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application's view controller.
*/

import UIKit

class ViewController: UIViewController {
}

