# QuickSwitch: Supporting Quick Watch Switching with WatchConnectivity

This sample demonstrates proper use of the WatchConnectivity framework in order to support quick watch switching with multiple Apple Watches as well as handling background launching on the Apple Watch. The app on Apple Watch allows you to configure a designator from the NATO phonetic alphabet and a color to identify the watch, and shows a history of received morse codes from the iOS app. When switching between Apple Watches the connected Apple Watch is reflected via information from the WCSession in the iOS app.

The code specific to implementing the WCSessionDelegate methods required for quick watch switching can be found in Shared > WatchConnectivityManager.swift.

## Requirements

### Build

Xcode 8.0 or later; iOS 10.0 SDK or later; watchOS 3.0 SDK or later

### Runtime

iOS 10.0 or later; watchOS 3.0 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
