/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Row Controller for our main interfaceTable
 */

import WatchKit

class ElementRowController: NSObject {
    @IBOutlet var elementLabel: WKInterfaceLabel!
}
