/*
See LICENSE folder for this sample’s licensing information.

Abstract:
View Controller to display the attachment data
*/

import UIKit

class PurchaseDetailsViewController: UIViewController {

    var url: URL!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        view.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        imageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        imageView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10).isActive = true

        let fileCoordinator = NSFileCoordinator()
        var error: NSError?
        fileCoordinator.purposeIdentifier = Attachment.purposeIdentifier
        fileCoordinator.coordinate(readingItemAt: url, options: .withoutChanges, error: &error) { url in
            do {
                let imageData = try Data(contentsOf: url)
                imageView.image = UIImage(data: imageData)
            } catch {
                imageView.image = nil
            }
        }
    }

}
