/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Table View Controller that implements drag and drop delegates.
*/

import UIKit

class ContactsTableViewController: UITableViewController, UITableViewDropDelegate, UITableViewDragDelegate {

    var contactCards: [ContactCard] = [
        ContactCard(name: "Jane Doe", phone: "(444) 444-4444", picture: UIImage(named: "Profile1.png")),
        ContactCard(name: "John Doe", phone: "(555) 555-5555", picture: UIImage(named: "Profile2.png"),
                    attachmentURL: Attachment.url(forName: "John Doe")),
        ContactCard(name: "Mr Z", phone: "(111) 111-1111", picture: UIImage(named: "Profile3.png"),
                    attachmentURL: Attachment.url(forName: "Mr Z")),
        ContactCard(name: "Mr X", phone: "(222) 222-2222", picture: UIImage(named: "Profile4.png")),
        ContactCard(name: "Professor Y", phone: "(000) 000-0000", picture: UIImage(named: "Profile5.png")),
        ContactCard(name: "Dr S", phone: "(888) 888-8888", picture: UIImage(named: "Profile6.png")),
        ContactCard(name: "Sir M", phone: "(333) 333-3333", picture: UIImage(named: "Profile7.png")),
        ContactCard(name: "Lady J", phone: "(777) 777-7777", picture: UIImage(named: "Profile8.png"),
                    attachmentURL: Attachment.url(forName: "Lady J")),
        ContactCard(name: "Miss L", phone: "(999) 999-9999", picture: UIImage(named: "Profile9.png")),
        ContactCard(name: "Mrs B", phone: "(666) 666-6666", picture: UIImage(named: "Profile10.png"))
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Customers"
        navigationController?.navigationBar.prefersLargeTitles = true
        tableView.dropDelegate = self
        tableView.dragDelegate = self
    }

    // MARK: - Table view drag and drop delegates

    func tableView(_ tableView: UITableView, performDropWith coordinator: UITableViewDropCoordinator) {

        guard let insertionIndex = coordinator.destinationIndexPath else {
           return
        }

        for coordinatorItem in coordinator.items {
            let itemProvider = coordinatorItem.dragItem.itemProvider
            if itemProvider.canLoadObject(ofClass: ContactCard.self) {
                itemProvider.loadObject(ofClass: ContactCard.self) { (object, error) in
                    DispatchQueue.main.async {
                        if let contactCard = object as? ContactCard {
                            self.contactCards.insert(contactCard, at: insertionIndex.row)
                            tableView.insertRows(at: [insertionIndex], with: UITableViewRowAnimation.automatic)
                        } else {
                            self.displayError(error)
                        }
                    }
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let contactCard = contactCards[indexPath.row]
        let dragItem = UIDragItem(itemProvider: NSItemProvider(object:contactCard))
        return [dragItem]
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactCards.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactNameCell", for: indexPath)
        cell.textLabel?.text = contactCards[indexPath.row].name
        return cell
    }

    // MARK: - Navigation etc

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsSegue" {
            if let detailsViewController = segue.destination as? ContactDetailsViewController {
                let contactCard = contactCards[tableView.indexPathForSelectedRow!.row]
                detailsViewController.contactCard = contactCard
            }
        }
    }

    func displayError(_ error: Error?) {
        let alert = UIAlertController(title: "Unable to load object", message: error?.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
