/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contact Details View. The attachment can be dragged to drag out a JPEG file.
*/

import UIKit
import MobileCoreServices

class ContactDetailsViewController: UIViewController, UIDragInteractionDelegate {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var contactPhoto: UIImageView!
    @IBOutlet weak var attachmentImageButton: UIButton!
    @IBOutlet weak var viewDataButton: UIButton!
    var contactCard: ContactCard!

    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = contactCard.name
        phoneLabel.text = contactCard.phoneNumber
        contactPhoto.image = contactCard.photo

        self.title = contactCard.name

        if contactCard.attachmentURL != nil {
            let dragInteraction = UIDragInteraction(delegate: self)
            attachmentImageButton.addInteraction(dragInteraction)
            attachmentImageButton.isHidden = false
            viewDataButton.isHidden = false
        }
    }

    @IBAction func viewPurchaseData(_ sender: Any) {
        let purchaseInfoViewController = PurchaseDetailsViewController()
        let url = Attachment.url(forName: contactCard.name)
        purchaseInfoViewController.url = url
        navigationController?.pushViewController(purchaseInfoViewController, animated: true)
    }

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        let itemProvider = NSItemProvider()
        itemProvider.registerFileRepresentation(forTypeIdentifier: kUTTypeJPEG as String, fileOptions: [.openInPlace], visibility: .all) { completionHandler in
            let url = Attachment.url(forName: self.contactCard.name)
            completionHandler(url, true, nil)
            return nil
        }
        let dragItem = UIDragItem(itemProvider: itemProvider)
        return [dragItem]
    }
}
