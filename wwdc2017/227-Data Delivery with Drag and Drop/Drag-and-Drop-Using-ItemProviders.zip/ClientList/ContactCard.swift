/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contact Card object implements the NSItemProviderReading and NSItemProviderWriting protocols
    to read and write vCards/Plain Text
*/

import UIKit
import ContactsUI
import Contacts
import MobileCoreServices

enum ContactCardError: Error {
    case invalidTypeIdentifier
    case invalidVCard
}

class ContactCard: NSObject, NSItemProviderReading, NSItemProviderWriting {
    var name: String
    var phoneNumber: String?
    var photo: UIImage?
    var attachmentURL: URL?

    init(name: String, phone: String? = nil, picture: UIImage? = nil, attachmentURL: URL? = nil) {
        self.name = name
        phoneNumber = phone
        photo = picture
        self.attachmentURL = attachmentURL
        super.init()
    }

    static var readableTypeIdentifiersForItemProvider =  [kUTTypeVCard as String, kUTTypeUTF8PlainText as String]

    required init(itemProviderData data: Data, typeIdentifier: String) throws {
        if typeIdentifier == kUTTypeVCard as String {
            let contacts = try CNContactVCardSerialization.contacts(with: data)
            if let contact = contacts.first {
                name = contact.givenName + " " + contact.familyName
                phoneNumber = contact.phoneNumbers.first?.value.stringValue
                if let photoData = contact.imageData {
                    photo = UIImage(data: photoData)
                }
            } else {
                throw ContactCardError.invalidVCard
            }
        } else if typeIdentifier == kUTTypeUTF8PlainText as String {
            self.name = String(data: data, encoding: .utf8)!
        } else {
            throw ContactCardError.invalidTypeIdentifier
        }
    }

    static var writableTypeIdentifiersForItemProvider: [String] = [kUTTypeVCard as String, kUTTypeUTF8PlainText as String]

    func loadData(withTypeIdentifier typeIdentifier: String,
                  forItemProviderCompletionHandler completionHandler: @escaping (Data?, Error?) -> Void) -> Progress? {
        if typeIdentifier == kUTTypeVCard as String {
            completionHandler(createVCard(), nil)
        } else if typeIdentifier == kUTTypeUTF8PlainText as String {
            completionHandler(name.data(using: .utf8), nil)
        } else {
            completionHandler(nil, ContactCardError.invalidTypeIdentifier)
        }
        return nil
    }

    func createVCard() -> Data? {
        var vCardText = "BEGIN:VCARD\nVERSION:3.0"
        vCardText += "\nFN:\(name)"

        if let phoneNumber = phoneNumber {
            vCardText += "\nTEL;type=pref:\(phoneNumber)"
        }

        if let photo = photo, let pngData = UIImagePNGRepresentation(photo) {
            let base64String = pngData.base64EncodedString()
            vCardText += "\nPHOTO;ENCODING=BASE64;TYPE=PNG:\(base64String)"
        }

        vCardText.append("\nEND:VCARD")
        return vCardText.data(using: .utf8)
    }
}
