/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Utility class to load files from the File Provider
*/

import Foundation

class Attachment {

    static let applicationGroup = "group.com.example.apple-samplecode.ClientList"
    static let attachmentName = "Attachment.jpg"
    static let purposeIdentifier = "com.example.apple-samplecode.ClientList"

    static var directoryURL = {
        return FileManager.default
                    .containerURL(forSecurityApplicationGroupIdentifier: applicationGroup)!
                    .appendingPathComponent("File Provider Storage")
    }()

    static func url(forName name: String) -> URL {
        return directoryURL.appendingPathComponent(name).appendingPathComponent(attachmentName)
    }

    static func load(url: URL) {
        let name = url.deletingLastPathComponent().lastPathComponent
        let resourceName = name + " Data"
        let bundleURL = Bundle.main.url(forResource: resourceName, withExtension: "jpg")

        do {
            try FileManager.default.createDirectory(
                at: url.deletingLastPathComponent(),
                withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o755]
            )

            try FileManager.default.copyItem(at: bundleURL!, to: url)
            try FileManager.default.setAttributes([.posixPermissions: 0o644], ofItemAtPath: url.path)
        } catch {}
    }

    // Use the enclosing folder name as the identifier
    static func identifier(for url: URL) -> String {
        return url.deletingLastPathComponent().lastPathComponent
    }

    static func url(forIdentifier identifier: String) -> URL {
        return url(forName: identifier)
    }
}
