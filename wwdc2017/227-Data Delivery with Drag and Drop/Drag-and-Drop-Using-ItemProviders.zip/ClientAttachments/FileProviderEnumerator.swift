/*
See LICENSE folder for this sample’s licensing information.

Abstract:
File Provider Enumerator
*/

import FileProvider

class FileProviderEnumerator: NSObject, NSFileProviderEnumerator {

    var enumeratedItemIdentifier: NSFileProviderItemIdentifier

    init(enumeratedItemIdentifier: NSFileProviderItemIdentifier) {
        self.enumeratedItemIdentifier = enumeratedItemIdentifier
        super.init()
    }

    func invalidate() { }

    func enumerateItems(for observer: NSFileProviderEnumerationObserver, startingAtPage page: Data) {
        if page == NSFileProviderInitialPageSortedByName as Data || page == NSFileProviderInitialPageSortedByDate as Data {
            do {
                let contents = try FileManager.default.contentsOfDirectory(
                    at: Attachment.directoryURL,
                    includingPropertiesForKeys: [.nameKey],
                    options: [.skipsSubdirectoryDescendants, .skipsHiddenFiles]
                )

                let items = contents.map { FileProviderItem(name: $0.lastPathComponent) }
                observer.didEnumerate(items)
            } catch {}
        }
        observer.finishEnumerating(upToPage: nil)
    }

    func enumerateChanges(for observer: NSFileProviderChangeObserver, fromSyncAnchor anchor: Data) {
        observer.finishEnumeratingChanges(upTo: anchor, moreComing: false)
    }

}
