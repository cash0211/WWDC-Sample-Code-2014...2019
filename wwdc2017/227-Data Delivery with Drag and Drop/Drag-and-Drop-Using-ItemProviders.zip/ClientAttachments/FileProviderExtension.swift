/*
See LICENSE folder for this sample’s licensing information.

Abstract:
File provider Extension. The app needs a File Provider to share files In Place
*/

import FileProvider

class FileProviderExtension: NSFileProviderExtension {

    var fileManager = FileManager()

    override init() {
        super.init()
    }

    func item(for identifier: NSFileProviderItemIdentifier) throws -> NSFileProviderItem? {
        return FileProviderItem(name:identifier as NSString as String)
    }

    override func urlForItem(withPersistentIdentifier identifier: NSFileProviderItemIdentifier) -> URL? {
        return Attachment.url(forIdentifier: identifier as NSString as String)
    }

    override func persistentIdentifierForItem(at url: URL) -> NSFileProviderItemIdentifier? {
        return NSFileProviderItemIdentifier(Attachment.identifier(for: url))
    }

    override func startProvidingItem(at url: URL, completionHandler: ((_ error: Error?) -> Void)?) {
        Attachment.load(url: url)
        completionHandler?(nil)
    }

    // MARK: - Actions

    override func trashItem(withIdentifier itemIdentifier: NSFileProviderItemIdentifier, completionHandler: @escaping (NSFileProviderItem?, Error?) -> Void) {
        do {
            try FileManager.default.removeItem(at:
                Attachment.url(forIdentifier: itemIdentifier as NSString as String
            ).deletingLastPathComponent())

            completionHandler(nil, nil)
        } catch let error {
            completionHandler(nil, error)
        }
    }

    override func deleteItem(withIdentifier itemIdentifier: NSFileProviderItemIdentifier, completionHandler: @escaping (Error?) -> Void) {
        completionHandler(nil)
    }

    // MARK: - Enumeration

    override func enumerator(forContainerItemIdentifier containerItemIdentifier: NSFileProviderItemIdentifier) throws -> NSFileProviderEnumerator {
        let maybeEnumerator: NSFileProviderEnumerator? = nil
        switch containerItemIdentifier {
        case .rootContainer:
            return FileProviderEnumerator(enumeratedItemIdentifier: .rootContainer)
        case .workingSet:
            return FileProviderEnumerator(enumeratedItemIdentifier: .workingSet)
        case .allDirectories:
            return FileProviderEnumerator(enumeratedItemIdentifier: .allDirectories)
        default:
            break
        }
        guard let enumerator = maybeEnumerator else {
            throw NSError(domain: NSCocoaErrorDomain, code: NSFeatureUnsupportedError, userInfo: [:])
        }
        return enumerator
    }

}
