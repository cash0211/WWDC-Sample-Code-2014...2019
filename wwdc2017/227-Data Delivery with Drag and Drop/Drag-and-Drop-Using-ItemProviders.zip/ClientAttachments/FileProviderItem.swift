/*
See LICENSE folder for this sample’s licensing information.

Abstract:
File Provider Item for the JPEG data files
*/

import FileProvider
import MobileCoreServices

class FileProviderItem: NSObject, NSFileProviderItem {

    var identifier: String
    let typeIdentifier = kUTTypeJPEG as String
    let capabilities = NSFileProviderItemCapabilities.allowsAll
    let parentItemIdentifier = NSFileProviderItemIdentifier.rootContainer

    init(name: String) {
        self.identifier = name
    }

    var itemIdentifier: NSFileProviderItemIdentifier {
        return NSFileProviderItemIdentifier(identifier)
    }

    var filename: String {
        return identifier + " Attachment.jpg"
    }

}
