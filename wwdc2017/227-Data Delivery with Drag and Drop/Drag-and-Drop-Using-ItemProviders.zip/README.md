# Drag and Drop with Item Providers

The ClientList app demonstrates how to handle different types of data for Drag and Drop using [`NSItemProvider`s](https://developer.apple.com/documentation/foundation/nsitemprovider).

## Overview

`NSItemProvider`s can now be used to read and write data/files during drag and drop operations.

## Handling System Objects

System Provided Objects like Strings, Attributed Strings, Images, Colors, and URLs can be loaded directly using ItemProviders. Developers can directly call an ItemProvider's [`canLoadObject(ofClass:)`](https://developer.apple.com/documentation/foundation/nsitemprovider/2888333-canloadobject) and [`loadObject(ofClass:completionHandler:)`](https://developer.apple.com/documentation/foundation/nsitemprovider/2888336-loadobject) methods for classes like `NSString`, `UIImage`, etc. In the ClientList app, you can try this by dragging any text and dropping it into the list of names.

## Handling Custom Classes

In order to use custom classes with ItemProviders, the [`NSItemProviderReading`](https://developer.apple.com/documentation/foundation/nsitemproviderreading) and [`NSItemProviderWriting`](https://developer.apple.com/documentation/foundation/nsitemproviderwriting) protocols need to be implemented. In the ClientList app, you can drop contact cards directly from the Contacts app. You can also drag out contact cards and drop them into other apps. The phone numbers, names and pictures would be copied. This works because the `ContactCard` class implements the `NSItemProviderReading` and `NSItemProviderWriting` protocols. It lists the UTIs that the class can read/write. The initializer reads the data from the item provider to set up this object. Wheras, the loadData method provides the data that a drop destination can use.

## Handling Files

An Item Provider's [`registerFileRepresentation(forTypeIdentifier:fileOptions:visibility:loadHandler:)`](https://developer.apple.com/documentation/foundation/nsitemprovider/2888337-registerfilerepresentation) method can be used to transfer files. The method's completion handler is called with the `URL` of the relevant file. If you want other apps to open your files in-place, then you must provide a File Provider `URL`. Your File Provider needs to support enumeration to support Open In Place. In the ClientList app, some contacts (such as Adam Gooseff) have attachment data. The attachment can be dragged and dropped into other apps.

## Requirements

- Xcode 9.0 or later.
- iOS 11.0 or later.
