/*
See LICENSE folder for this sample’s licensing information.

Abstract:
AppDelegate overrides for SyncStartTV
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var window: UIWindow?
}
