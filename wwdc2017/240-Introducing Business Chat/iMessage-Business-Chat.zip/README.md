# Package Delivery: A simple Business Chat Example

This sample illustrates how you can go about building an app extension that interacts with Business Chat. It allows your business to interact with your customer via an iMessage application.

## Overview

This sample code highlights the use of the [`MSMessage`](https://developer.apple.com/documentation/messages/msmessage) URL property as a way to receive additional data from your Customer Service Provider server. This data can be used to drive the state of your application or to provide supplementary information needed by your model. In this specific example, we use the data provided in the URL to initialize our Package model object which is returned with a selected destination when the user replies to the message.

## Getting Started

- Install the PackageDeliveryMessagesExtension on your device.
- Replace all `<team-identifier>` placeholders in the sample JSON (BCSandbox_payload.json) with your team-identifier listed in your iOS developer account.
- Use your Apple Developer account to log in the [Business Chat Sandbox](https://icloud.developer.apple.com/businesschat).
- Select the "My App" tab.
- Drag and drop the JSON file in the Business Chat Sendbox.

## Requirements

### Build

Xcode 9.0 or later; iOS 11.0 SDK or later.

### Runtime

iOS 11.0 or later.
