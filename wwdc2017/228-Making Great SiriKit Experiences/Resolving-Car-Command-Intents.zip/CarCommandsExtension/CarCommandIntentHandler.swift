/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The base car command intent handler class.
*/

import Intents
import CarCommandsKit

class CarCommandIntentHandler: NSObject {
    
    /// - Tag: resolveCarName
    func resolveCarName(carName: INSpeakableString?, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
        let possibleNames = Car.possibleNames()
        guard let carName = carName?.spokenPhrase else {
            completion(.disambiguation(with: possibleNames.map { INSpeakableString(spokenPhrase: $0) }))
            return
        }
        
        let filteredNames = possibleNames.filter { carName.lowercased().contains($0.lowercased()) }
        switch filteredNames.count {
        case 0:
            completion(.disambiguation(with: possibleNames.map { INSpeakableString(spokenPhrase: $0) }))
        case 1:
            completion(.success(with: INSpeakableString(spokenPhrase: filteredNames.first!)))
        default:
            completion(.disambiguation(with: filteredNames.map { INSpeakableString(spokenPhrase: $0) }))
        }
    }
    
}
