/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The CarLockStatusIntentHandler lets users to manage the state of their car locks using Siri.
*/

import Intents
import CarCommandsKit

class CarLockStatusIntentHandler: CarCommandIntentHandler, INSetCarLockStatusIntentHandling, INGetCarLockStatusIntentHandling {
    
    // MARK: - INSetCarLockStatusIntentHandling
    
    func handle(setCarLockStatus intent: INSetCarLockStatusIntent, completion: @escaping (INSetCarLockStatusIntentResponse) -> Void) {
        guard var car = Car(intent.carName?.spokenPhrase) else {
            completion(INSetCarLockStatusIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        if let locked = intent.locked {
            car.doorsLocked = locked ? .locked : .unlocked
        } else {
            car.doorsLocked = .unknown
        }
        
        if car.doorsLocked != .unknown {
            completion(INSetCarLockStatusIntentResponse(code: .success, userActivity: nil))
        } else {
            completion(INSetCarLockStatusIntentResponse(code: .failureRequiringAppLaunch, userActivity: nil))
        }
    }
    
    func resolveCarName(forSetCarLockStatus intent: INSetCarLockStatusIntent, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
        resolveCarName(carName: intent.carName, with: completion)
    }
    
    // MARK: - INGetCarLockStatusIntentHandling
    
    func handle(getCarLockStatus intent: INGetCarLockStatusIntent, completion: @escaping (INGetCarLockStatusIntentResponse) -> Void) {
        guard var car = Car(intent.carName?.spokenPhrase) else {
            completion(INGetCarLockStatusIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        switch car.doorsLocked {
        case .unknown:
            completion(INGetCarLockStatusIntentResponse(code: .failureRequiringAppLaunch, userActivity: nil))
        case .locked:
            let response = INGetCarLockStatusIntentResponse(code: .success, userActivity: nil)
            response.locked = true
            completion(response)
        case .unlocked:
            let response = INGetCarLockStatusIntentResponse(code: .success, userActivity: nil)
            response.locked = false
            completion(response)
        }
    }
    
    func resolveCarName(forGetCarLockStatus intent: INGetCarLockStatusIntent, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
        resolveCarName(carName: intent.carName, with: completion)
    }
}
