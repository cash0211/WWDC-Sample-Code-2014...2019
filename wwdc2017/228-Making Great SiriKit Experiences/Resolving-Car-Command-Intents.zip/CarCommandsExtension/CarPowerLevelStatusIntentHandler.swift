/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The CarPowerLevelStatusIntentHandler lets users to read the state of their car power level using Siri.
*/

import Intents
import CarCommandsKit

class CarPowerLevelStatusIntentHandler: CarCommandIntentHandler, INGetCarPowerLevelStatusIntentHandling {
    // MARK: - INGetCarPowerLevelStatusIntentHandling
    
    func confirm(getCarPowerLevelStatus intent: INGetCarPowerLevelStatusIntent, completion: @escaping (INGetCarPowerLevelStatusIntentResponse) -> Void) {
        readCarPowerLevelStatus(intent: intent, completion: completion)
    }
    
    func handle(getCarPowerLevelStatus intent: INGetCarPowerLevelStatusIntent, completion: @escaping (INGetCarPowerLevelStatusIntentResponse) -> Void) {
        readCarPowerLevelStatus(intent: intent, completion: completion)
    }
    
    func resolveCarName(forGetCarPowerLevelStatus intent: INGetCarPowerLevelStatusIntent, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
        resolveCarName(carName: intent.carName, with: completion)
    }
    
    // MARK: - Private
    
    private func readCarPowerLevelStatus(intent: INGetCarPowerLevelStatusIntent, completion: @escaping (INGetCarPowerLevelStatusIntentResponse) -> Void) {
        guard var car = Car(intent.carName?.spokenPhrase) else {
            completion(INGetCarPowerLevelStatusIntentResponse(code: .failure, userActivity: nil))
            return
        }
        
        let response = INGetCarPowerLevelStatusIntentResponse(code: .success, userActivity: nil)
        response.chargePercentRemaining = car.powerLevel ?? 1.0
        response.distanceRemaining = Measurement(value: 300.0, unit: UnitLength.miles)
        completion(response)
    }
}
