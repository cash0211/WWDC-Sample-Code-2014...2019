/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A simple car commands intent handler that lets users manage their car using Siri. In particular,
     control the status of the car’s locks and read the current power level.
*/

import Intents
import CarCommandsKit

class IntentHandler: INExtension {
    
    // MARK: - INIntentHandlerProviding
    
    /// - Tag: handler
    override func handler(for intent: INIntent) -> Any {
        switch intent {
        case is INSetCarLockStatusIntent, is INGetCarLockStatusIntent:
            return CarLockStatusIntentHandler()
            
        case is INGetCarPowerLevelStatusIntent:
            return CarPowerLevelStatusIntentHandler()
            
        default:
            fatalError("Unhandled intent: \(intent)\n" +
                       "Any intent that is passed through `handler(for:)` is " +
                       "definied in the Info.plist and must have a matching Intent Handler.")
        }
    }
    
}

