/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A car model object shared between the app and the extension.
*/

import Foundation
import Intents

public enum LockState {
    case unknown
    case locked
    case unlocked
}

public struct Car {
    // MARK: - Private
    
    private let lockedStateKeyName = "Locked"
    private let powerLevelKeyName = "PowerLevel"
    private lazy var userDefaults = UserDefaults(suiteName: "group.com.example.apple-samplecode.CarCommands")
    private let name: String
    
    private func keyName(_ keyName: String) -> String? {
        return "\(name)-\(keyName)"
    }
    
    // MARK: - Public
    
    public static func possibleNames() -> [String] {
        return ["First", "Second"]
    }
    
    /// - Tag: updateSiriKnowledgeOfCarNames
    public static func updateSiriKnowledgeOfCarNames() {
        DispatchQueue(label: "CarCommands").async {
            let carNames = NSOrderedSet(array: possibleNames().map { INSpeakableString(spokenPhrase: $0) })
            INVocabulary.shared().setVocabulary(carNames, of: INVocabularyStringType.carName)
        }
    }
    
    public var doorsLocked: LockState {
        mutating get {
            if let userDefaults = self.userDefaults,
                let keyName = keyName(lockedStateKeyName),
                let value = userDefaults.object(forKey: keyName) as? NSNumber {
                return value.boolValue ? .locked : .unlocked
            } else {
                return .unknown
            }
        }
        set {
            if let userDefaults = self.userDefaults, let keyName = keyName(lockedStateKeyName) {
                switch newValue {
                case .unknown:
                    userDefaults.set(nil, forKey: keyName)
                case .locked:
                    userDefaults.set(true, forKey: keyName)
                case .unlocked:
                    userDefaults.set(false, forKey: keyName)
                }
                userDefaults.synchronize()
            }
        }
    }
    
    public var powerLevel: Float? {
        mutating get {
            guard let userDefaults = self.userDefaults,
                let keyName = keyName(powerLevelKeyName),
                let value = userDefaults.object(forKey: keyName) as? NSNumber else {
                return nil
            }
            return value.floatValue
        }
        set {
            if let userDefaults = self.userDefaults, let keyName = keyName(powerLevelKeyName) {
                userDefaults.set(newValue, forKey: keyName)
                userDefaults.synchronize()
            }
        }
    }
    
    public init?(_ name: String?) {
        guard let name = name, Car.possibleNames().contains(name) else {
            return nil
        }
        
        self.name = name
    }
}
