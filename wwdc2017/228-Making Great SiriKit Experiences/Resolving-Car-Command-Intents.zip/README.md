# Resolving Car Command Intents

This sample code demonstrates resolving Car Command intents using a simple intent handler that lets users manage their car using Siri. In particular, control the status of the car’s locks and read the current power level.

As a sample app, this illustrates how to adopt SiriKit by adding an Intents extension.

## Overview

Apps that interact with the user’s car may support the car command intents. These intents let users manage their car using Siri.

This sample code implements support for the following intents:
- Get the status of the car’s locks ([`INGetCarLockStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/ingetcarlockstatusintenthandling))
- Set the status of the car’s locks ([`INSetCarLockStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/insetcarlockstatusintenthandling))
- Get the current fuel or power level ([`INGetCarPowerLevelStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/ingetcarpowerlevelstatusintenthandling))

A user of this app should be able to invoke Siri and say "Unlock my car" or "Unlock my second car". If Siri understands the car name, it unlocks it right away:

![Siri](Documentation/Screenshot1.png)

In case the car name is ambiguous, Siri would prompt user for disambiguation:

![Siri](Documentation/Screenshot2.png)

When they dismiss Siri, they can visually observe the new state of either car locks in the CarCommands app, as shown below:

![Siri](Documentation/Screenshot3.png)

## Project Structure

The CarCommands project consists of the following targets:

### CarCommandsKit (Framework)

A framework is a hierarchical directory that encapsulates a dynamic library, header files, and resources, into a single package. You can learn more about embedding frameworks in an app here: ([`Technical Note TN2435`](https://developer.apple.com/library/content/technotes/tn2435/_index.html#//apple_ref/doc/uid/DTS40017543-CH1-WHAT_IS_A_FRAMEWORK_)).

The CarCommandsKit is a framework that is sharing the `Car` model between the CarCommands app and the CarCommandsExtension SiriKit extension.

The `Car` model is a simple container around [`UserDefaults`](https://developer.apple.com/documentation/foundation/userdefaults) that reads and writes data on demand.

The class initializer takes a car name string as a parameter:
```
public init?(_ name: String?)
```

This class exports the following computed properties:
```
public var doorsLocked: LockState
public var powerLevel: Float?
```

There are two class methods, the first one, `possibleNames` returns car names ("First" and "Second") hard-coded for the sake of simplicity. The second method, `updateSiriKnowledgeOfCarNames` registers user-specific vocabulary that might be included in Siri requests using the ([`INVocabulary`](https://developer.apple.com/documentation/sirikit/invocabulary)) object:

``` swift
public static func updateSiriKnowledgeOfCarNames() {
    DispatchQueue(label: "CarCommands").async {
        let carNames = NSOrderedSet(array: possibleNames().map { INSpeakableString(spokenPhrase: $0) })
        INVocabulary.shared().setVocabulary(carNames, of: INVocabularyStringType.carName)
    }
}
```
[View in Source](x-source-tag://updateSiriKnowledgeOfCarNames)

### CarCommandsExtension (a SiriKit extension)

The entry point of this SiriKit extension is `override func handler(for intent: INIntent) -> Any` of `IntentHandler` that server as a "router":

``` swift
override func handler(for intent: INIntent) -> Any {
    switch intent {
    case is INSetCarLockStatusIntent, is INGetCarLockStatusIntent:
        return CarLockStatusIntentHandler()
        
    case is INGetCarPowerLevelStatusIntent:
        return CarPowerLevelStatusIntentHandler()
        
    default:
        fatalError("Unhandled intent: \(intent)\n" +
                   "Any intent that is passed through `handler(for:)` is " +
                   "definied in the Info.plist and must have a matching Intent Handler.")
    }
}
```
[View in Source](x-source-tag://handler)

The actual work to resolve car names and handle intents is happening in `CarLockStatusIntentHandler` and `CarPowerLevelStatusIntentHandler`, which are both subclasses of `CarCommandIntentHandler`.

The base `CarCommandIntentHandler` class provides the following helper method to resolve car names using in-app vocabulary:

``` swift
func resolveCarName(carName: INSpeakableString?, with completion: @escaping (INSpeakableStringResolutionResult) -> Void) {
    let possibleNames = Car.possibleNames()
    guard let carName = carName?.spokenPhrase else {
        completion(.disambiguation(with: possibleNames.map { INSpeakableString(spokenPhrase: $0) }))
        return
    }
    
    let filteredNames = possibleNames.filter { carName.lowercased().contains($0.lowercased()) }
    switch filteredNames.count {
    case 0:
        completion(.disambiguation(with: possibleNames.map { INSpeakableString(spokenPhrase: $0) }))
    case 1:
        completion(.success(with: INSpeakableString(spokenPhrase: filteredNames.first!)))
    default:
        completion(.disambiguation(with: filteredNames.map { INSpeakableString(spokenPhrase: $0) }))
    }
}
```
[View in Source](x-source-tag://resolveCarName)

The `CarLockStatusIntentHandler` conforms to ([`INGetCarLockStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/ingetcarlockstatusintenthandling)) and ([`INSetCarLockStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/insetcarlockstatusintenthandling)) protocols and implements handle and resolution method of these protocols.

This intent handler simply calls into its superclass' `resolveCarName` method for both resolution steps.

The `CarPowerLevelStatusIntentHandler` conforms to ([`INGetCarPowerLevelStatusIntentHandling`](https://developer.apple.com/documentation/sirikit/ingetcarpowerlevelstatusintenthandling)). Similarly, this class calls into `resolveCarName` of `CarCommandIntentHandler` to resolve car name.

### CarCommands (the app)

The app would request Siri permission for the first time it's launched, as specified in the `AppDelegate`:

``` swift
func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
    
    INPreferences.requestSiriAuthorization { status in
        switch status {
        case .notDetermined:
            print("User has not yet made a choice with regards to this application")
        case .restricted:
            print("This application is not authorized to use Siri services. " +
                  "Due to active restrictions on Siri services, the user cannot change this status, " +
                  "and may not have personally denied authorization.")
        case .denied:
            print("User has explicitly denied authorization for this application, or Siri services are disabled in Settings.")
        case .authorized:
            print("User has authorized this application to use Siri services.")
        }
    }
    
    Car.updateSiriKnowledgeOfCarNames()
    
    return true
}
```
[View in Source](x-source-tag://didFinishLaunchingWithOptions)

Additionally, the app would update Siri knowledge of car names here:
```
Car.updateSiriKnowledgeOfCarNames()
```

The `ViewController` represents a car state by reading the `Car` object and drawing the car view (`CarView`).

## Requirements

### Build

Xcode 9.0 or later; iOS 11.0 SDK or later

### Runtime

iOS 11.0 or later
