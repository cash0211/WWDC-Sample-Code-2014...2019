/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application's only view controller that represents a car.
*/

import UIKit
import CarCommandsKit

class ViewController: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet var carView: CarView!
    @IBOutlet var powerLevelSlider: UISlider!
    
    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(ViewController.updateCarViewState),
                                               name: NSNotification.Name.UIApplicationDidBecomeActive, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateCarViewState()
    }
    
    // MARK: - Private
    
    private lazy var car: Car = Car(self.tabBarItem.title)!
    
    @IBAction private func sliderValueChanged(slider: UISlider) {
        car.powerLevel = slider.value
    }
    
    @objc
    private func updateCarViewState() {
        carView.doorsLocked = car.doorsLocked
        powerLevelSlider.value = car.powerLevel ?? 1.0
    }
}

