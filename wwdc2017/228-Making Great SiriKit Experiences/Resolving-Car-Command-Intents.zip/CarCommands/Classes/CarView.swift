/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The view that displays top view of a car.
*/

import UIKit
import CarCommandsKit

class CarView: UIView {
    
    // MARK: - Constants
    
    private let doorVerticalOffset: CGFloat = 118.0
    private let doorOpenAngle: CGFloat = 25.0
    private let leftDoorHorizontalOffset: CGFloat = 13.0
    private let rightDoorHorizontalOffset: CGFloat = 10.0
    private let unknownLabelVerticalOffset: CGFloat = 20.0
    
    // MARK: - Views
    
    private lazy var unknownLabel: UILabel = {
        let label = UILabel()
        label.text = "❓"
        label.font = UIFont.systemFont(ofSize: 40)
        return label
    }()
    
    private lazy var bodyImageView = UIImageView(image: #imageLiteral(resourceName: "Body"))
    
    private lazy var leftDoorImageView: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "LeftDoor"))
        imageView.layer.anchorPoint = CGPoint(x: 0, y: 0.0)
        return imageView
    }()
    
    private lazy var rightDoorImageView: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "RightDoor"))
        imageView.layer.anchorPoint = CGPoint(x: 1.0, y: 0.0)
        return imageView
    }()
    
    // MARK: - Instance Lifecycle
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    convenience init() {
        self.init(frame: CGRect.zero)
    }
    
    private func commonInit() {
        isAccessibilityElement = true
        addSubview(leftDoorImageView)
        addSubview(rightDoorImageView)
        addSubview(bodyImageView)
        addSubview(unknownLabel)
    }
    
    // MARK: - Layout
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        unknownLabel.sizeToFit()
        unknownLabel.frame = CGRect(x: (frame.width - unknownLabel.frame.width) / 2.0,
                                    y: (frame.height - unknownLabel.frame.height) / 2.0 + unknownLabelVerticalOffset,
                                    width: unknownLabel.frame.width,
                                    height: unknownLabel.frame.height)
        
        if let image = bodyImageView.image {
            bodyImageView.frame = CGRect(x: (frame.width - image.size.width) / 2.0,
                                         y: (frame.height - image.size.height) / 2.0,
                                         width: image.size.width,
                                         height: image.size.height)
        }
        
        if let image = leftDoorImageView.image {
            leftDoorImageView.transform = CGAffineTransform.identity
            leftDoorImageView.frame = CGRect(x: bodyImageView.frame.minX + leftDoorHorizontalOffset,
                                             y: bodyImageView.frame.minY + doorVerticalOffset,
                                             width: image.size.width,
                                             height: image.size.height)
            leftDoorImageView.transform = CGAffineTransform(rotationAngle: (doorsLocked == .unlocked ? doorOpenAngle : 0).degreesToRadians)
        }
        
        if let image = rightDoorImageView.image {
            rightDoorImageView.transform = CGAffineTransform.identity
            rightDoorImageView.frame = CGRect(x: bodyImageView.frame.maxX - image.size.width - rightDoorHorizontalOffset,
                                              y: bodyImageView.frame.minY + doorVerticalOffset,
                                              width: image.size.width,
                                              height: image.size.height)
            rightDoorImageView.transform = CGAffineTransform(rotationAngle: -(doorsLocked == .unlocked ? doorOpenAngle : 0.0).degreesToRadians)
        }
    }
    
    // MARK: - Public
    
    var doorsLocked: LockState = .unknown {
        didSet {
            unknownLabel.isHidden = doorsLocked != .unknown
            UIView.animate(withDuration: 0.3) {
                self.setNeedsLayout()
                self.layoutIfNeeded()
            }
        }
    }
    
    // MARK: - Accessibility
    
    override var accessibilityLabel: String? {
        get {
            if let accessibilityLabel = super.accessibilityLabel {
                return accessibilityLabel
            }
            
            switch doorsLocked {
            case .unknown:
                return "Unknown door lock state"
            case .locked:
                return "Doors are locked"
            case .unlocked:
                return "Doors are unlocked"
            }
        }
        set {
            super.accessibilityLabel = newValue
        }
    }
}

extension FloatingPoint {
    var degreesToRadians: Self { return self * .pi / 180 }
}
