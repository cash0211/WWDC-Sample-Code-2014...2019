/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application delegate.
*/

import UIKit
import Intents
import CarCommandsKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    /// - Tag: didFinishLaunchingWithOptions
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        INPreferences.requestSiriAuthorization { status in
            switch status {
            case .notDetermined:
                print("User has not yet made a choice with regards to this application")
            case .restricted:
                print("This application is not authorized to use Siri services. " +
                      "Due to active restrictions on Siri services, the user cannot change this status, " +
                      "and may not have personally denied authorization.")
            case .denied:
                print("User has explicitly denied authorization for this application, or Siri services are disabled in Settings.")
            case .authorized:
                print("User has authorized this application to use Siri services.")
            }
        }
        
        Car.updateSiriKnowledgeOfCarNames()
        
        return true
    }
}
