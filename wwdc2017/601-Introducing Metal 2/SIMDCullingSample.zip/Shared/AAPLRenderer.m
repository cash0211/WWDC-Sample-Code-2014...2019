/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of renderer class which perfoms Metal setup and per frame rendering
*/
@import simd;
@import ModelIO;
@import MetalKit;

#import "AAPLRenderer.h"
#import "AAPLMathUtilities.h"
// Include header shared between C code here, which executes Metal API commands, and .metal files
#import "AAPLShaderTypes.h"

#define RANDOM_FLOAT(min,max) (float) (arc4random_uniform(INT_MAX) * (1.0/(double)INT_MAX))*(max-min) + min

// The max number of command buffers in flight
static const NSUInteger AAPLMaxBuffersInFlight = 3;

// The 256 byte aligned size of our uniform structure
static const size_t AAPLAlignedUniformsSize = (sizeof(AAPLUniforms) & ~0xFF) + 0x100;

// Radius of our sphere "astroids"
static const float AAPLSphereRadius = 0.75f;

// Total number of displayed objects
uint32_t AAPLNumInstances = 1024*16;
uint32_t AAPLThreadgroupSize = 64;
static const size_t AAPLIndirectBufferSize = sizeof(MTLDrawIndexedPrimitivesIndirectArguments);

// Main class performing the rendering
@implementation AAPLRenderer
{
    dispatch_semaphore_t _inFlightSemaphore;
    id <MTLDevice> _device;
    id <MTLCommandQueue> _commandQueue;

    // Buffer that contains matrices for each object on the scene
    id <MTLBuffer> _modelMatrixBuffer;
    
    // Buffer that contains shader uniforms
    id <MTLBuffer> _dynamicUniformBuffer;
    
    // Buffer that contains an array of indices for objects visiable in current frame
    id <MTLBuffer> _drawStreamBuffer;
    
    // Buffer for atomic instance counters
    id <MTLBuffer> _instanceCounters;
    
    // Indirect draw buffer
    NSMutableArray<id <MTLBuffer>> *_drawIndirectBuffers;
    
    id <MTLComputePipelineState> _computeState;
    id <MTLRenderPipelineState> _pipelineState;
    id <MTLDepthStencilState> _depthState;
	id <MTLTexture> _baseColorMap;
    id <MTLTexture> _normalMap;
    id <MTLTexture> _specularMap;

    // Metal vertex descriptor specifying how vertices will by laid out for input into our render
    //   pipeline and how we'll layout our ModelIO vertices
    MTLVertexDescriptor *_mtlVertexDescriptor;

    // Offset within _dynamicUniformBuffer to set for the current frame
    uint32_t _uniformBufferOffset;

    // Used to determine _uniformBufferStride each frame.
    //   This is the current frame number modulo AAPLMaxBuffersInFlight
    uint8_t _uniformBufferIndex;

    // Address to write dynamic uniforms to each frame
    void* _uniformBufferAddress;

    // Projection matrix calculated as a function of view size
    matrix_float4x4 _projectionMatrix;

    // Current rotation of our object in radians
    float _rotation;

    // MetalKit mesh containing vertex data and index buffer for our object
    MTKMesh *_mesh;
}

/// Initialize with the MetalKit view from which we'll obtain our Metal device.  We'll also use this
/// mtkView object to set the pixelformat and other properties of our drawable
- (nonnull instancetype)initWithMetalKitView:(nonnull MTKView *)mtkView
{
    self = [super init];
    if(self)
    {
        _device = mtkView.device;
        _inFlightSemaphore = dispatch_semaphore_create(AAPLMaxBuffersInFlight);
        [self loadMetal:mtkView];
        [self loadAssets];
    }

    return self;
}

/// Create our metal render state objects including our shaders and render state pipeline objects
- (void) loadMetal:(nonnull MTKView *)mtkView
{
    // Create and load our basic Metal state objects

    // Load all the shader files with a metal file extension in the project
    id <MTLLibrary> defaultLibrary = [_device newDefaultLibrary];

    // Calculate our uniform buffer size.  We allocate AAPLMaxBuffersInFlight instances for uniform
    //   storage in a single buffer.  This allows us to update uniforms in a ring (i.e. triple
    //   buffer the uniforms) so that the GPU reads from one slot in the ring wil the CPU writes
    //   to another.  Also uniform storage must be aligned (to 256 bytes) to meet the requirements
    //   to be an argument in the constant address space of our shading functions.
    NSUInteger uniformBufferSize = AAPLAlignedUniformsSize * AAPLMaxBuffersInFlight;

    // Create and allocate our uniform buffer object.  Indicate shared storage so that both the
    //  CPU can access the buffer
    _dynamicUniformBuffer = [_device newBufferWithLength:uniformBufferSize
                                                 options:MTLResourceStorageModeShared];

    _dynamicUniformBuffer.label = @"UniformBuffer";

    // Load the fragment function into the library
    id <MTLFunction> fragmentFunction = [defaultLibrary newFunctionWithName:@"fragmentLighting"];

    // Load the vertex function into the library
    id <MTLFunction> vertexFunction = [defaultLibrary newFunctionWithName:@"vertexTransform"];

    // Load the vertex program into the library
    id <MTLFunction> kernelProgram = [defaultLibrary newFunctionWithName:@"sphere_culling"];
    
    // Create a vertex descriptor for our Metal pipeline. Specifies the layout of vertices the
    //   pipeline should expect.  The layout below keeps attributes used to calculate vertex shader
    //   output position separate (world position, skinning, tweening weights) separate from other
    //   attributes (texture coordinates, normals).  This generally maximizes pipeline efficiency

    _mtlVertexDescriptor = [[MTLVertexDescriptor alloc] init];

    // Positions.
    _mtlVertexDescriptor.attributes[AAPLVertexAttributePosition].format = MTLVertexFormatFloat3;
    _mtlVertexDescriptor.attributes[AAPLVertexAttributePosition].offset = 0;
    _mtlVertexDescriptor.attributes[AAPLVertexAttributePosition].bufferIndex = AAPLBufferIndexMeshPositions;

    // Normals.
    _mtlVertexDescriptor.attributes[AAPLVertexAttributeNormal].format = MTLVertexFormatHalf4;
    _mtlVertexDescriptor.attributes[AAPLVertexAttributeNormal].offset = 8;
    _mtlVertexDescriptor.attributes[AAPLVertexAttributeNormal].bufferIndex = AAPLBufferIndexMeshGenerics;

    // Position Buffer Layout
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshPositions].stride = 12;
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshPositions].stepRate = 1;
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshPositions].stepFunction = MTLVertexStepFunctionPerVertex;

    // Generic Attribute Buffer Layout
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshGenerics].stride = 32;
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshGenerics].stepRate = 1;
    _mtlVertexDescriptor.layouts[AAPLBufferIndexMeshGenerics].stepFunction = MTLVertexStepFunctionPerVertex;

    mtkView.depthStencilPixelFormat = MTLPixelFormatDepth32Float_Stencil8;
    mtkView.colorPixelFormat = MTLPixelFormatBGRA8Unorm_sRGB;
    mtkView.sampleCount = 1;
    
    // Create a reusable pipeline state
    MTLRenderPipelineDescriptor *pipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
    pipelineStateDescriptor.label = @"MyPipeline";
    pipelineStateDescriptor.vertexFunction = vertexFunction;
    pipelineStateDescriptor.fragmentFunction = fragmentFunction;
    pipelineStateDescriptor.vertexDescriptor = _mtlVertexDescriptor;
    pipelineStateDescriptor.sampleCount = mtkView.sampleCount;
    pipelineStateDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat;
    pipelineStateDescriptor.depthAttachmentPixelFormat = mtkView.depthStencilPixelFormat;
    pipelineStateDescriptor.stencilAttachmentPixelFormat = mtkView.depthStencilPixelFormat;

    NSError *error = NULL;
    _pipelineState = [_device newRenderPipelineStateWithDescriptor:pipelineStateDescriptor error:&error];
    if (!_pipelineState)
    {
        NSLog(@"Failed to created pipeline state, error %@", error);
    }

    MTLDepthStencilDescriptor *depthStateDesc = [[MTLDepthStencilDescriptor alloc] init];
    depthStateDesc.depthCompareFunction = MTLCompareFunctionLess;
    depthStateDesc.depthWriteEnabled = YES;
    _depthState = [_device newDepthStencilStateWithDescriptor:depthStateDesc];

    _computeState = [_device newComputePipelineStateWithFunction:kernelProgram error:nil];
    
    _modelMatrixBuffer = [_device newBufferWithLength:sizeof(AAPLInstanceData)*AAPLNumInstances*AAPLMaxBuffersInFlight options:0];
    _modelMatrixBuffer.label = @"Instances buffer";
    
    _drawStreamBuffer = [_device newBufferWithLength:sizeof(uint32_t)*AAPLNumInstances options:0];
    _drawStreamBuffer.label = @"Mesh stream buffer";
    
    _instanceCounters = [_device newBufferWithLength:256 options:0];
    _instanceCounters.label = @"Atomic instance counters";
    
    // Create the command queue
    _commandQueue = [_device newCommandQueue];
}

- (void)loadAssets
{
	// Create and load our assets into Metal objects including meshes and textures

	NSError *error;

    // Creata a ModelIO vertexDescriptor so that we format/layout our ModelIO mesh vertices to
    //   fit our Metal render pipeline's vertex descriptor layout
    MDLVertexDescriptor *modelIOVertexDescriptor =
        MTKModelIOVertexDescriptorFromMetal(_mtlVertexDescriptor);

    // Indicate how each Metal vertex descriptor attribute maps to each ModelIO  attribute
    modelIOVertexDescriptor.attributes[AAPLVertexAttributePosition].name  = MDLVertexAttributePosition;
    modelIOVertexDescriptor.attributes[AAPLVertexAttributeNormal].name    = MDLVertexAttributeNormal;

    // Create a MetalKit mesh buffer allocator so that ModelIO  will load mesh data directly into
    //   Metal buffers accessible by the GPU
    MTKMeshBufferAllocator *metalAllocator =
        [[MTKMeshBufferAllocator alloc] initWithDevice: _device];

    // Use ModelIO  to create a cylinder mesh as our object
    MDLMesh *modelIOMesh = [MDLMesh newEllipsoidWithRadii:(vector_float3){AAPLSphereRadius, AAPLSphereRadius, AAPLSphereRadius}
                                           radialSegments:10
                                         verticalSegments:10
                                             geometryType:MDLGeometryTypeTriangles
                                            inwardNormals:NO
                                               hemisphere:NO
                                                allocator:metalAllocator];

    // Perform the format/re-layout of mesh vertices by setting the new vertex descriptor in our
    //   ModelIO mesh
    modelIOMesh.vertexDescriptor = modelIOVertexDescriptor;

    // Crewte a MetalKit mesh (and submeshes) backed by Metal buffers
    _mesh = [[MTKMesh alloc] initWithMesh:modelIOMesh
                                   device:_device
                                    error:&error];

    if(!_mesh || error)
    {
        NSLog(@"Error creating MetalKit mesh %@", error.localizedDescription);
    }

    AAPLInstanceData* instances = (AAPLInstanceData*)[_modelMatrixBuffer contents];
    for(int i = 0; i < AAPLNumInstances; i++)
    {
        // Random object rotation
        matrix_float4x4 local_rotation =  matrix4x4_rotation(RANDOM_FLOAT(0,M_PI), RANDOM_FLOAT(0,1), 1, RANDOM_FLOAT(0,1));
        
        // Random object scale
        float scale = RANDOM_FLOAT(1.5f,2.0f);
        matrix_float4x4 scale_matrix = matrix4x4_scale(scale, scale, scale);
        
        // Random object translation
        matrix_float4x4 translation_matrix = matrix4x4_translation(0,RANDOM_FLOAT(-45.0,15.0),RANDOM_FLOAT(20,900.0));
        
        // Random object global rotation
        matrix_float4x4 global_rotation = matrix4x4_rotation(RANDOM_FLOAT(0,M_PI*2.0), 0, 1, 0.0f) ;
        
        // Calculate model transformation matrix
        instances[i].modelMatrix = matrix_multiply(matrix_multiply(global_rotation,translation_matrix),matrix_multiply(local_rotation,scale_matrix));
        
        // Calculate inverted transformation matrix (used later as normal matrix)
        instances[i].invModelMatrix = matrix_invert(matrix_transpose(instances[i].modelMatrix));
        
        instances[i].boundingSphereRadius = AAPLSphereRadius * scale;
    }

    // Create indirect buffers for each submesh
    _drawIndirectBuffers = [NSMutableArray new];
    
    for (NSUInteger bufferIndex = 0; bufferIndex < _mesh.submeshes.count; bufferIndex++)
    {
        [_drawIndirectBuffers addObject:[_device newBufferWithLength:AAPLIndirectBufferSize*AAPLMaxBuffersInFlight options:0]];
        _drawIndirectBuffers[bufferIndex].label = [NSString stringWithFormat:@"Indirect buffer (submesh %lu)",(unsigned long)bufferIndex];
    }
}

- (void)updateDynamicBufferState
{
    // Update the location(s) to which we'll write to in our dynamically changing Metal buffers for
    //   the current frame (i.e. update our slot in the ring buffer used for the current frame)

    _uniformBufferIndex = (_uniformBufferIndex + 1) % AAPLMaxBuffersInFlight;

    _uniformBufferOffset = AAPLAlignedUniformsSize * _uniformBufferIndex;

    _uniformBufferAddress = ((uint8_t*)_dynamicUniformBuffer.contents) + _uniformBufferOffset;
}

- (void)updateGameState
{
    // Update any game state (including updating dynamically changing Metal buffer)

    AAPLUniforms * uniforms = (AAPLUniforms*)_uniformBufferAddress;

	vector_float3 ambientLightColor = {0.1, 0.1, 0.1};
    uniforms->ambientLightColor = ambientLightColor;

	vector_float3 directionalLightDirection = {0, -0.71, 0.71};

    uniforms->directionalLightDirection = directionalLightDirection;

    vector_float3 directionalLightColor = {.4, .4, .4};
    uniforms->directionalLightColor = directionalLightColor;;

    uniforms->materialShininess = 30;

    uniforms->projectionMatrix = _projectionMatrix;
    uniforms->invProjectionMatrix = matrix_invert(_projectionMatrix);
    matrix_float4x4 rotationMatrix =  matrix_multiply(matrix4x4_rotation(-0.5, (vector_float3){1, 0, 0}),
                                                      matrix4x4_rotation(_rotation, (vector_float3){0, 1, 0}));
    uniforms->viewMatrix = matrix_multiply(rotationMatrix, matrix4x4_translation(0, -40, 0) );
    uniforms->invViewMatrix = matrix_invert(matrix_transpose(uniforms->viewMatrix));


    NSUInteger submeshIdx = 0;
    // Create an indirect draw for our submeshtes
    for(MTKSubmesh *submesh in _mesh.submeshes)
    {
        // Clear the indirect buffer
        MTLDrawIndexedPrimitivesIndirectArguments *counters = &((MTLDrawIndexedPrimitivesIndirectArguments*)[_drawIndirectBuffers[submeshIdx] contents])[_uniformBufferIndex];
        NSLog(@"%i objects rendered",counters->instanceCount);
        counters->baseInstance = 0;
        counters->instanceCount = 0;
        counters->baseVertex = 0;
        counters->indexStart = 0;
        counters->indexCount = (uint32_t)submesh.indexCount;

        submeshIdx++;
    }
    
	_rotation += .005;
}

/// Called whenever view changes orientation or layout is changed
- (void) mtkView:(nonnull MTKView *)view drawableSizeWillChange:(CGSize)size
{
    // When reshape is called, update the aspect ratio and projection matrix since the view
    //   orientation or size has changed
	float aspect = size.width / (float)size.height;
    _projectionMatrix = matrix_perspective_left_hand(65.0f * (M_PI / 180.0f), aspect, 10.0f, 1400.0);

}

// Called whenever the view needs to render
- (void) drawInMTKView:(nonnull MTKView *)view
{
    // Wait to ensure only AAPLMaxBuffersInFlight are getting proccessed by any stage in the Metal
    //   pipeline (App, Metal, Drivers, GPU, etc)
    dispatch_semaphore_wait(_inFlightSemaphore, DISPATCH_TIME_FOREVER);

    // Create a new command buffer for each renderpass to the current drawable
    id <MTLCommandBuffer> commandBuffer = [_commandQueue commandBuffer];
    commandBuffer.label = @"MyCommand";

    // Add completion hander which signal _inFlightSemaphore when Metal and the GPU has fully
    //   finished proccssing the commands we're encoding this frame.  This indicates when the
    //   dynamic buffers, that we're writing to this frame, will no longer be needed by Metal
    //   and the GPU.
    __block dispatch_semaphore_t block_sema = _inFlightSemaphore;
    [commandBuffer addCompletedHandler:^(id<MTLCommandBuffer> buffer)
    {
        dispatch_semaphore_signal(block_sema);
    }];
    
    [self updateDynamicBufferState];
    [self updateGameState];

    // This could be done in single compute shader call but here done in MTLBlitCommandEncoder for clarity
    id <MTLBlitCommandEncoder> blitEncoder = [commandBuffer blitCommandEncoder];
    [blitEncoder fillBuffer:_instanceCounters range:NSMakeRange(0, _instanceCounters.length) value:0];
    [blitEncoder endEncoding];
    
    // Perform frustum culling on GPU using compute kernel
    {
        id <MTLComputeCommandEncoder> computeEncoder = [commandBuffer computeCommandEncoder];
        
        // Set pipeline state
        [computeEncoder setComputePipelineState:_computeState];
        
        // Set compute buffers
        [computeEncoder setBuffer:_modelMatrixBuffer offset:0 atIndex:AAPLBufferIndexModelMatrices];
        [computeEncoder setBuffer:_drawStreamBuffer offset:0 atIndex:AAPLBufferIndexDrawStream];
        [computeEncoder setBuffer:_dynamicUniformBuffer offset:_uniformBufferOffset atIndex:AAPLBufferIndexUniforms];
        [computeEncoder setBuffer:_drawIndirectBuffers[0] offset:(AAPLIndirectBufferSize * _uniformBufferIndex) atIndex:AAPLBufferIndexIndirect];
        [computeEncoder setBuffer:_instanceCounters offset:0 atIndex:AAPLBufferIndexCounters];
        
        // Dispatch work to gpu
        [computeEncoder dispatchThreadgroups:MTLSizeMake(AAPLNumInstances/AAPLThreadgroupSize, 1, 1) threadsPerThreadgroup:MTLSizeMake(AAPLThreadgroupSize,1,1)];
        
        [computeEncoder endEncoding];
    }
    
    NSUInteger instanceCountOffset = offsetof(MTLDrawIndexedPrimitivesIndirectArguments,instanceCount);
    NSUInteger instanceCountSize = sizeof(((MTLDrawIndexedPrimitivesIndirectArguments *)0)->instanceCount);
    
    // This could be done in single compute shader call but here done in MTLBlitCommandEncoder for clarity
    blitEncoder = [commandBuffer blitCommandEncoder];
    for (NSUInteger bufferIndex = 1; bufferIndex < _mesh.submeshes.count; bufferIndex++)
    {
        [blitEncoder copyFromBuffer:_drawIndirectBuffers[0]
                       sourceOffset:instanceCountOffset
                           toBuffer:_drawIndirectBuffers[bufferIndex]
                  destinationOffset:instanceCountOffset size:instanceCountSize];
    }
    [blitEncoder endEncoding];

    // Obtain a renderPassDescriptor generated from the view's drawable textures
    MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;

    // If we've gotten a renderPassDescriptor we can render to the drawable, otherwise we'll skip
    //   any rendering this frame because we have no drawable to draw to
    if(renderPassDescriptor != nil)
    {
        // Create a render command encoder so we can render into something
        id <MTLRenderCommandEncoder> renderEncoder =
        [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        renderEncoder.label = @"MyRenderEncoder";

        // Push a debug group allowing us to identify render commands in the GPU Frame Capture tool
        [renderEncoder pushDebugGroup:@"DrawMesh"];

        // Set render command encoder state
		[renderEncoder setCullMode:MTLCullModeBack];
        [renderEncoder setRenderPipelineState:_pipelineState];
        [renderEncoder setDepthStencilState:_depthState];

        // Set any buffers fed into our render pipeline
        [renderEncoder setVertexBuffer:_dynamicUniformBuffer
                                offset:_uniformBufferOffset
                               atIndex:AAPLBufferIndexUniforms];

        [renderEncoder setVertexBuffer:_modelMatrixBuffer
                                offset:0
                               atIndex:AAPLBufferIndexModelMatrices];
        
        [renderEncoder setVertexBuffer:_drawStreamBuffer
                                offset:0
                               atIndex:AAPLBufferIndexDrawStream];
        
        [renderEncoder setFragmentBuffer:_dynamicUniformBuffer
                                  offset:_uniformBufferOffset
                                 atIndex:AAPLBufferIndexUniforms];

        for (NSUInteger bufferIndex = 0; bufferIndex < _mesh.vertexBuffers.count; bufferIndex++)
        {
            MTKMeshBuffer *vertexBuffer = _mesh.vertexBuffers[bufferIndex];
            if((NSNull*)vertexBuffer != [NSNull null])
            {
                [renderEncoder setVertexBuffer:vertexBuffer.buffer
                                        offset:vertexBuffer.offset
                                       atIndex:bufferIndex];
            }
        }

        NSUInteger submeshIdx = 0;
        // Draw each submesh of our mesh
        for(MTKSubmesh *submesh in _mesh.submeshes)
        {
            [renderEncoder drawIndexedPrimitives:submesh.primitiveType
                                       indexType:submesh.indexType
                                     indexBuffer:submesh.indexBuffer.buffer
                               indexBufferOffset:submesh.indexBuffer.offset
                                  indirectBuffer:_drawIndirectBuffers[submeshIdx]
                            indirectBufferOffset:AAPLIndirectBufferSize * _uniformBufferIndex];
            submeshIdx++;
        }

        
        [renderEncoder popDebugGroup];
        
        // We're done encoding commands
        [renderEncoder endEncoding];

        // Schedule a present once the framebuffer is complete using the current drawable
        [commandBuffer presentDrawable:view.currentDrawable];
    }

    // Finalize rendering here & push the command buffer to the GPU
    [commandBuffer commit];
}

@end



