/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header containing types and enum constants shared between Metal shaders and C/ObjC source
*/
#ifndef ShaderTypes_h
#define ShaderTypes_h

#include <simd/simd.h>

// Buffer index values shared between shader and C code to ensure Metal shader buffer inputs match
//   Metal API buffer set calls
typedef enum AAPLBufferIndex
{
    AAPLBufferIndexMeshPositions = 0,
    AAPLBufferIndexMeshGenerics  = 1,
    AAPLBufferIndexUniforms      = 2,
    AAPLBufferIndexModelMatrices = 3,
    AAPLBufferIndexDrawStream    = 4,
    AAPLBufferIndexIndirect      = 5,
    AAPLBufferIndexCounters      = 6,
} AAPLBufferIndex;

// Attribute index values shared between shader and C code to ensure Metal shader vertex
//   attribute indices match the Metal API vertex descriptor attribute indices
typedef enum AAPLVertexAttribute
{
    AAPLVertexAttributePosition = 0,
    AAPLVertexAttributeNormal   = 1,
} AAPLVertexAttribute;

// Structure shared between shader and C code to ensure the layout of uniform data accessed in
//    Metal shaders matches the layout of uniform data set in C code
typedef struct
{
    // Per Frame Uniforms
    matrix_float4x4 projectionMatrix;
    matrix_float4x4 invProjectionMatrix;
    matrix_float4x4 viewMatrix;
    matrix_float4x4 invViewMatrix;

    // Per Mesh Uniforms
    float materialShininess;

    // Per Light Properties
    vector_float3 ambientLightColor;
    vector_float3 directionalLightDirection;
    vector_float3 directionalLightColor;

} AAPLUniforms;

// Per instance data
typedef struct
{
    matrix_float4x4 modelMatrix;
    matrix_float4x4 invModelMatrix;
    float boundingSphereRadius;
} AAPLInstanceData;

#endif /* ShaderTypes_h */

