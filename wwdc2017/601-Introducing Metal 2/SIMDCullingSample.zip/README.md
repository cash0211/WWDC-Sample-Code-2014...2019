# Culling with SIMD Groups
This sample shows usage of simd metal shading language functions to perform stream compaction during frustum culling process. To achieve stream compaction without simd functions atomic device memory access would have to be performed more often with decreasing performance.

## Overview
This sample displays large cloud of spheres (or asteroids). Each sphere is an instance of the same model with it's own specific orientation and position. All are shaded using ambient and directional component. Camera is constantly rotating.

## Algorithm

### Culling
A large number of threads (equal to number of spheres) is dispatched. At the end of this step, the GPU will have created  a list containing instance id's of all visible objects.

On its own thread each, sphere is culled against the camera frustum using the Separating Axis Theorm algorithm. Four normals are generated for each of the frustum walls.  The sphere center is cast on each of these normals and tested if it's within the boundaries of the frustum.  If any separating axis is found, the test is consider to be negative and the object is not visible.  (We don't test against  he far plane as it's not relevant in this example since all the objects are distributed within camera reach.)

Threads are grouped into *simd groups* . When each thread in the group completes visibility test it creates a variable with values `1` for visible objects or `0` for non-visible objects.

### Creating visible instances list
*Stream compaction* is performed next and is done in 2 steps. The first step calculates prefix sum of visibility values for each thread. This is performed using simd group functions as shown here

```c++
template <typename T>
T simd_scan(T in_value, uint simd_id, uint simd_size)
{
    uint num_steps = (uint)log2((float)simd_size);
    uint stride = 2;

    // Sweep up phase
    for(uint i = 0; i < num_steps; i++)
    {
        T other_thread_value = simd_shuffle_up(in_value, stride/2);
        if (simd_id%stride == stride-1) { // Sum up two values
            in_value = in_value + other_thread_value;
        }
        stride*=2;
    }

    stride /= 2;
    // insert zero for last element
    if(simd_id == simd_size-1)
    {
       in_value = 0;
    }

    // sweep down phase
    for(int i = (int)num_steps; i > 0 ; i--)
    {
        T other_thread_value = simd_shuffle_xor(in_value,stride/2);
        if (simd_id%stride == stride-1) { // Sum up values from two lines
            in_value = in_value+other_thread_value;
        }
        else if(simd_id%stride == stride/2 -1) { // Move value from another line
            in_value = other_thread_value;
        }
        stride/=2;
    }
    return in_value;
}
```
The result of above computations looks like this:

![Computation Result](Documentation/ComputationResult.png)

The next step is for the last thread in the group to calculate how many visible objects is in the group

```c++
ObjectsInTheGroup = VisibilityPrefixSum[GroupSize-1] + Visibility[GroupSize-1]
```

For above example this number is 5. Than same thread calls `atomic_fetch_add_explicit` with device memory variable that represents the number of visible objects which has been added to the VisibilityPrefixSum instance list and adds `ObjectsInTheGroup` to it. This way thread has reserved `ObjectsInTheGroup` number of slots inside the list.

The second step of stream compaction is to broadcast the first index of the reserved space to each thread in the group.  With this, each thread can calculate where to insert its instance id.

```c++
template <typename T>
void stream_compact(T in_value, uint32_t maskValue , uint simd_id, uint simd_size, device T *output, device atomic_int *counters)
{
    // calculate prefix sum for each simd group
    uint32_t partial_sum = simd_scan<uint32_t>(maskValue,simd_id,simd_size);

    // calculate amount of objects to append for this simd group (broadcast last value of prefix sum + value of last object)
    uint32_t append_length = maskValue + partial_sum;

    append_length = simd_broadcast((int)append_length,(ushort)(simd_size-1));

    // reserve enough space in the stream
    uint32_t allocation_begin = 0;
    if(simd_id == simd_size-1)
    {
        allocation_begin = atomic_fetch_add_explicit(&counters[0], append_length, memory_order_relaxed);
    }

    // broadcast beggining of the stream
    allocation_begin = simd_broadcast(allocation_begin,simd_size-1);

    // each threads writes out it's value at right position
    if(maskValue)
    {
              output[allocation_begin+partial_sum] = in_value;
    }
}
```

### Rendering
The list of visible instances is actually continuous Metal buffer containing the instances to draw.  A call to `drawIndexedPrimitives:indexType:indexBuffer:indexBufferOffset:indirectBuffer:indirectBufferOffset:` uses this buffer to draw visible objects.

```c++
[renderEncoder drawIndexedPrimitives:submesh.primitiveType
                           indexType:submesh.indexType
                         indexBuffer:submesh.indexBuffer.buffer
                   indexBufferOffset:submesh.indexBuffer.offset
                      indirectBuffer:_drawIndirectBuffers[submeshIdx]
                indirectBufferOffset:AAPLIndirectBufferSize * _uniformBufferIndex];
```
