/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our our iOS Application Delegate
*/


#import <UIKit/UIKit.h>

@interface AAPLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
                        
@end
