# Argument Buffers

This sample is a simple example of Metal's Argument Buffers feature, newly available in iOS 11 and macOS 10.13.

## Overview

An app can use Argument Buffers to encode resource arguments in a standard Metal buffer such that and a shader or kernel can fetch those resources via the buffer. This enables applications to use less of the CPU cycles as shaders can access many textures, samplers, buffers, and constants with the application setting a single buffer containing references to these resources.

This sample draws two quads using two different pipelines.

The vertex shader in first pipeline accesses a vertex coordinate offset encoded an Metal buffer. This coordinate positions the quad in the viewport. The pipeline's fragment shader accesses a sampler object and three texture encoded in a Metal buffer and adds the texture values together.

The second pipeline uses the same vertex shader with a different fragment shader. The fragment shader accesses three constants and three Metal buffers encoded within another Metal buffer.  Even though the shader uses three buffers containing data, the app only sets one buffer, which contains references to the other three buffers. These three buffers contain lists of rectangles. Constants, directly encoded within the buffer set in the encoder, indicate the number of rectangles stored in each of these three indirectly accessed buffers.   The first rectangle list contains rectangles in the quad that should be colored red. The second rectangle list contains rectangles that should be colored green  Finally, the third rectangle list contains rectangles that should be colored blue. The shader iterates through each of list of rectangles, checking whether a fragment is in the bounds of a rectangle, coloring the fragment if it is.

## Requirements
iOS 11.0, macOS 10.13 with a device supporting Metal

### Build
Xcode 9.0, iOS 11.0 SDK, macOS 10.13 SDK

### Runtime
iOS 11.0, or macOS 10.13 or later
