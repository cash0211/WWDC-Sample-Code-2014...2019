/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header containing types and enum constants shared between Metal shaders and C/ObjC source
*/
#ifndef ShaderTypes_h
#define ShaderTypes_h

#include <simd/simd.h>

// Buffer index values shared between shader and C code to ensure Metal shader buffer inputs match
//   Metal API buffer set calls
typedef enum AAPLFragmentBufferIndex
{
    AAPLFragmentBufferIndexArguments = 0,
} AAPLFragmentBufferIndex;

// Buffer index values shared between shader and C code to ensure Metal shader buffer inputs match
//   Metal API buffer set calls
typedef enum AAPLVertexBufferIndex
{
    AAPLVertexBufferIndexVertices     = 0,
    AAPLVertexBufferIndexViewportSize = 1,
    AAPLVertexBufferIndexArguments    = 2
} AAPLVertexBufferIndex;

// Argument buffer indices shared between shader and C code to ensure Metal shader buffer
//   inpute match Metal API texture set calls
typedef enum AAPLArgumentBufferIndex
{
    // Argument buffer inputs for the vertex shader
    AAPLArgumentBufferIndexPositionOffset = 1,

    // Argument buffer inputs for the texture shader
    AAPLArgumentBufferIndexTextureA = 1,
    AAPLArgumentBufferIndexTextureB = 2,
    AAPLArgumentBufferIndexTextureC = 3,
    AAPLArgumentBufferIndexSampler  = 4,

    // Argument buffer inputs for the color rect shader
    AAPLArgumentBufferIndexRedRects      = 1,
    AAPLArgumentBufferIndexGreenRects    = 2,
    AAPLArgumentBufferIndexBlueRects     = 3,
    AAPLArgumentBufferIndexNumRedRects   = 4,
    AAPLArgumentBufferIndexNumGreenRects = 5,
    AAPLArgumentBufferIndexNumBlueRects  = 6,
} AAPLArgumentBufferIndex;

// Stucture used to fill Metal buffers with rectangles to color and read in colorRectShader to
//   actually color in the rectangles
typedef struct AAPLRect {
    float x;
    float y;
    float width;
    float height;
} AAPLRect;

//  Defines the layout of each vertex in the array of vertices set as an input to our
//    Metal vertex shader.
typedef struct
{
    //  Positions in pixel space (i.e. a value of 100 indicates 100 pixels from the origin/center)
    vector_float2 position;
    vector_float2 barycentricCoord;
} AAPLVertex;


#endif /* ShaderTypes_h */
