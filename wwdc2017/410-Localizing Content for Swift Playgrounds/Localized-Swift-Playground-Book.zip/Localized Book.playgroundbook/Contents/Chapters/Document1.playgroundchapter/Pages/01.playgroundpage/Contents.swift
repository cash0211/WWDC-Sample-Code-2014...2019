//#-hidden-code
/*
 See LICENSE.txt for this sample’s licensing information.
 
 Abstract:
 An example playground page showing localized content.
 */
//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 This prose will be subtituted in from the appropriate *.lproj.
 */
//#-hidden-code
import PlaygroundSupport

let viewController = LiveViewController.makeFromStoryboard()
PlaygroundPage.current.liveView = viewController

//#-end-hidden-code
//#-editable-code Tap to enter code

//#-end-editable-code
