/*
See LICENSE folder for this sample’s licensing information.

Abstract:
View controller for the settings page.
*/

import UIKit

class SettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var closeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        closeButton.accessibilityLabel = "Close"
        
        tableView.register(SwitchTableViewCell.self, forCellReuseIdentifier: "SwitchCell")
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func exitTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell: SwitchTableViewCell = tableView.dequeueReusableCell(withIdentifier: "SwitchCell", for: indexPath) as? SwitchTableViewCell else {
            fatalError("Couldn't dequeue Switch Cell for index path \(indexPath)")
        }
        
        var networkName = ""
        switch indexPath.row {
            case 0:
                networkName = "Catbook"
            case 1:
                networkName = "Quacker"
            case 2:
                networkName = "Photolicious"
            case 3:
                networkName = "FreshInsights"
            default:
                fatalError("More than 4 Social Networks attempted to load")
        }
        
        cell.label.text = networkName
        
        return cell
    }

}
