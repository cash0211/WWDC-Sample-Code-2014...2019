/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Table view cell with a label and a UISwitch for enabling/disabling a setting
*/

import UIKit

class SwitchTableViewCell: UITableViewCell {

    let label: UILabel
    let onSwitch: UISwitch
    
    let padding: CGFloat = 20.0
    
    // Make the whole cell the accessible element, not its sub labels and the UISwitch
    override var isAccessibilityElement: Bool {
        get {
            return true
        }
        set { }
    }
    
    // When the VoiceOver user double taps the cell to activate it, switch the UISwitch's on value to the opposite
    // of whatever it was when they activated the cell
    override func accessibilityActivate() -> Bool {
        onSwitch.setOn(!onSwitch.isOn, animated: true)
        return true
    }
    
    // Use accessiblity value to indicate to the user whether or not the setting is enabled
    override var accessibilityValue: String? {
        get {
            return (onSwitch.isOn) ? "On" : "Off"
        }
        set { }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        
        label = UILabel()
        onSwitch = UISwitch()
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
     
        commonInit()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        label = UILabel()
        onSwitch = UISwitch()
        
        super.init(coder: aDecoder)
        
        commonInit()
        
    }
    
    func commonInit() {
        
        backgroundColor = UIColor(named: "AppGray")
        
        label.textColor = .white
        label.font = TextManager.switchCellFont
        
        onSwitch.setOn(false, animated: false)
        onSwitch.isAccessibilityElement = false
        
        label.translatesAutoresizingMaskIntoConstraints = false
        onSwitch.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(label)
        addSubview(onSwitch)
        
        let labelLeading = label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: padding)
        let labelCenterY = label.centerYAnchor.constraint(equalTo: centerYAnchor)
        let labelTrailing = label.trailingAnchor.constraint(equalTo: onSwitch.leadingAnchor, constant: -padding)
        
        let switchCenterY = onSwitch.centerYAnchor.constraint(equalTo: centerYAnchor)
        let switchTrailing = onSwitch.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -padding)
        
        labelLeading.isActive = true
        labelCenterY.isActive = true
        labelTrailing.isActive = true
        
        switchCenterY.isActive = true
        switchTrailing.isActive = true
        
    }
}
