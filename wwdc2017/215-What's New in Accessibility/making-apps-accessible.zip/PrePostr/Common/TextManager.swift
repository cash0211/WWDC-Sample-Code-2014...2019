/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Object used to reference common fonts used throughout the app
 
 Thought it isn't taken advantage of here, having a centralized place to reference fonts from can be helpful
 when adapting your app for Dynamic Type, which is another area of critical importance for accessibility users.
*/

import UIKit

class TextManager: NSObject {
    
    static var subtitleColor = UIColor.lightGray
    
    static var profileNameFont = UIFont.boldSystemFont(ofSize: 22.0)
    
    static var textFont = UIFont.systemFont(ofSize: 18.0)
    
    static var subtitleFont = UIFont.systemFont(ofSize: 14.0)
    
    static var buttonFont = UIFont.boldSystemFont(ofSize: 16.0)
    
    static var switchCellFont = UIFont.boldSystemFont(ofSize: 18.0)
    
}
