/*
See LICENSE folder for this sample’s licensing information.

Abstract:
AppDelegate
*/

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
}
