/*
See LICENSE folder for this sample’s licensing information.

Abstract:
UIView subclass that supports using stars for ratings.
*/

import UIKit

class StarsView: UIView {
    
    var stars: [UIImageView] = []
    let tapRecognizer: UITapGestureRecognizer
    
    // StarView will always be an accessibility element, so always return true
    override var isAccessibilityElement: Bool {
        get {
            return true
        }
        set { }
    }
    
    // Using accessibility label to describe what the view is
    override var accessibilityLabel: String? {
        get {
            return "Star Rating"
        }
        set { }
    }
    
    // Using accessibility value to convey the view's current value
    override var accessibilityValue: String? {
        get {
            switch numStars {
                case 0:
                    return "No rating"
                case 1:
                    return "1 star"
                default:
                    return "\(numStars) stars"
            }
        }
        set { }
    }
    
    // Adding the adjustable trait to accessibility traits indicates to VoiceOver that this view's value can be changed
    // via increment and decrement actions, and that the view responds to those methods below
    override var accessibilityTraits: UIAccessibilityTraits {
        get {
            return super.accessibilityTraits | UIAccessibilityTraitAdjustable
        }
        set { }
    }
    
    // Called when a VoiceOver user swipes up with their finger on this view to increase the value
    override func accessibilityIncrement() {
        if numStars < 5 {
            numStars += 1
        }
    }
    
    // Celled when a VoiceOver user swipes down with their finger on this view to decrease the value
    override func accessibilityDecrement() {
        if numStars != 1 {
            numStars -= 1
        }
    }
    
    var numStars = 0 {
        didSet {
            let index = numStars - 1
            let unfilledStar = #imageLiteral(resourceName: "Star_Empty")
            let filledStar = #imageLiteral(resourceName: "Star_Filled")
            for i in 0...index {
                let star = stars[i]
                star.image = filledStar
            }
            for i in index + 1..<5 {
                let star = stars[i]
                star.image = unfilledStar
            }
        }
    }
    
    init(stars: Int) {
        numStars = stars
        tapRecognizer = UITapGestureRecognizer()
        
        super.init(frame: CGRect.null)
        
        commonInit(numStars: stars)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        tapRecognizer = UITapGestureRecognizer()

        super.init(coder: aDecoder)
        
        commonInit(numStars: 0)
        
    }
    
    func commonInit(numStars: Int) {
        
        backgroundColor = .clear
        
        tapRecognizer.addTarget(self, action: #selector(viewTapped(tapGesture:)))
        addGestureRecognizer(tapRecognizer)
        
        let unfilledStar = #imageLiteral(resourceName: "Star_Empty")
        let filledStar = #imageLiteral(resourceName: "Star_Filled")
        
        // Use filled stars up to our current number of stars
        for index in 0..<numStars {
            let star = UIImageView(image: filledStar)
            star.isUserInteractionEnabled = true
            star.contentMode = .scaleAspectFit
            star.translatesAutoresizingMaskIntoConstraints = false
            addSubview(star)
            stars.insert(star, at: index)
        }
        
        // Use unfilled stars for the remaining stars
        for index in numStars..<5 {
            let star = UIImageView(image: unfilledStar)
            star.isUserInteractionEnabled = true
            star.contentMode = .scaleAspectFit
            star.translatesAutoresizingMaskIntoConstraints = false
            addSubview(star)
            stars.insert(star, at: index)
        }
        
        var prevView: UIImageView?
        for index in 0..<5 {
            let nextStar = stars[index]
            let nextLeading = nextStar.leadingAnchor.constraint(equalTo: (prevView == nil) ? leadingAnchor : prevView!.trailingAnchor)
            let nextCenterY = nextStar.centerYAnchor.constraint(equalTo: centerYAnchor)
            let nextWidth = nextStar.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.2)
            let nextHeight = nextStar.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 0.2)
            
            nextLeading.isActive = true
            nextCenterY.isActive = true
            nextWidth.isActive = true
            nextHeight.isActive = true
            
            if index == 4 {
                let nextTrailing = nextStar.trailingAnchor.constraint(equalTo: trailingAnchor)
                nextTrailing.isActive = true
            }
            
            prevView = nextStar
        }
        
    }
    
    @objc
    func viewTapped(tapGesture: UITapGestureRecognizer) {
        let view = hitTest(tapGesture.location(in: self), with: nil)
        if let imageView = view as? UIImageView, let index = stars.index(of: imageView) {
            numStars = index + 1
        }
    }

}
