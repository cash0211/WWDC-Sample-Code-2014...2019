/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Votable cell featuring text input as content.
*/

import UIKit

class TextVotableCollectionViewCell: VotableCollectionViewCell {
    
    let postTextLabel: UILabel
    
    override init(frame: CGRect) {
        postTextLabel = UILabel()
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        postTextLabel = UILabel()
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override func commonInit() {
        super.commonInit()
        
        postTextLabel.numberOfLines = 0
        postTextLabel.font = TextManager.textFont
        postTextLabel.textColor = UIColor.white
        postTextLabel.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(postTextLabel)
        
        let postTextTop = postTextLabel.topAnchor.constraint(equalTo: profileLine.bottomAnchor, constant: VotableCollectionViewCell.padding)
        let postTextLeading = postTextLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: VotableCollectionViewCell.padding)
        let postTextTrailing = postTextLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -VotableCollectionViewCell.padding)
        
        postTextTop.isActive = true
        postTextLeading.isActive = true
        postTextTrailing.isActive = true
    }
    
}
