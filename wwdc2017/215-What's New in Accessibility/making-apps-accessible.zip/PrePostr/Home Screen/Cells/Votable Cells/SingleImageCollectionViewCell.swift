/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Votable cell featuring text input and an image as content.
*/

import UIKit

class SingleImageCollectionViewCell: TextVotableCollectionViewCell {
    
    let fullImageView: UIImageView
    
    override init(frame: CGRect) {
        fullImageView = UIImageView()
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fullImageView = UIImageView()
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override func commonInit() {
        super.commonInit()
        
        fullImageView.contentMode = .scaleAspectFit
        fullImageView.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(fullImageView)
        
        let imageLeading = fullImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: VotableCollectionViewCell.padding)
        let imageTop = fullImageView.topAnchor.constraint(equalTo: postTextLabel.bottomAnchor, constant: VotableCollectionViewCell.padding)
        let imageTrailing = fullImageView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -VotableCollectionViewCell.padding)
        let imageBottom = fullImageView.bottomAnchor.constraint(equalTo: topLine.topAnchor, constant: -VotableCollectionViewCell.padding)
        
        imageLeading.isActive = true
        imageTop.isActive = true
        imageTrailing.isActive = true
        imageBottom.isActive = true
    }
    
}
