/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Superclass for cells that should be votable via upvote or downvote
*/


import UIKit

class VotableCollectionViewCell: StandardPostCollectionViewCell {
    
    static let buttonHeight: CGFloat = 30.0
    static let buttonWidth: CGFloat = 50.0
    
    let commentButton: UIButton
    let approveButton: UIButton
    let disapproveButton: UIButton
    let topLine: UIView
    let betweenLine1: UIView
    let betweenLine2: UIView
    
    // Change the button title when we set the number of comments
    var numComments = 0 {
        didSet {
            commentButton.setTitle("\(numComments) Comments", for: .normal)
        }
    }
    
    // Update the UI visually to show the new number of up votes, but also update the accessibilityValue
    // accordingly so VoiceOver users always have an accurate read of votes
    var numApproves = 0 {
        didSet {
            approveButton.setTitle("\(numApproves)", for: .normal)
            var axValue = ""
            switch numApproves {
                case 0:
                    axValue = "No votes"
                case 1:
                    axValue = "1 vote"
                default:
                    axValue = "\(numApproves) votes"
            }
            approveButton.accessibilityValue = axValue
        }
    }
    
    // Update the UI visually to show the new number of down votes, but also update the accessibilityValue
    // accordingly so VoiceOver users always have an accurate read of votes
    var numDisapproves = 0 {
        didSet {
            disapproveButton.setTitle("\(numDisapproves)", for: .normal)
            var axValue = ""
            switch numDisapproves {
                case 0:
                    axValue = "No votes"
                case 1:
                    axValue = "1 vote"
                default:
                    axValue = "\(numDisapproves) votes"
            }
            disapproveButton.accessibilityValue = axValue
        }
    }
    
    override init(frame: CGRect) {
        
        commentButton = UIButton()
        approveButton = UIButton()
        disapproveButton = UIButton()
        topLine = UIView()
        betweenLine1 = UIView()
        betweenLine2 = UIView()
        
        super.init(frame: frame)
        
        commonInit()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        commentButton = UIButton()
        approveButton = UIButton()
        disapproveButton = UIButton()
        topLine = UIView()
        betweenLine1 = UIView()
        betweenLine2 = UIView()
        
        super.init(coder: aDecoder)
        
        commonInit()
        
    }
    
    override func commonInit() {
        
        super.commonInit()
        
        commentButton.titleLabel?.font = TextManager.buttonFont
        commentButton.setTitle("\(numComments) Comments", for: .normal)
        
        approveButton.titleLabel?.font = TextManager.buttonFont
        approveButton.setTitle("\(numApproves)", for: .normal)
        approveButton.setImage(#imageLiteral(resourceName: "Up_Icon"), for: .normal)
        approveButton.contentMode = .scaleAspectFit
        
        disapproveButton.titleLabel?.font = TextManager.buttonFont
        disapproveButton.setTitle("\(numDisapproves)", for: .normal)
        disapproveButton.setImage(#imageLiteral(resourceName: "Down_Icon"), for: .normal)
        disapproveButton.contentMode = .scaleAspectFit
        
        topLine.backgroundColor = .white
        betweenLine1.backgroundColor = .white
        betweenLine2.backgroundColor = .white
        
        commentButton.translatesAutoresizingMaskIntoConstraints = false
        approveButton.translatesAutoresizingMaskIntoConstraints = false
        disapproveButton.translatesAutoresizingMaskIntoConstraints = false
        topLine.translatesAutoresizingMaskIntoConstraints = false
        betweenLine1.translatesAutoresizingMaskIntoConstraints = false
        betweenLine2.translatesAutoresizingMaskIntoConstraints = false
        
        // Make sure our buttons have sensible accessibility labels, otherwise they'll just read their number value
        // which is confusing and contextless for VoiceOver users
        approveButton.accessibilityLabel = "Up vote"
        disapproveButton.accessibilityLabel = "Down vote"
        
        addSubview(commentButton)
        addSubview(approveButton)
        addSubview(disapproveButton)
        addSubview(topLine)
        addSubview(betweenLine1)
        addSubview(betweenLine2)
        
        let commentLeading = commentButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: StandardPostCollectionViewCell.padding)
        let commentHeight = commentButton.heightAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonHeight)
        let commentTrailing = commentButton.trailingAnchor.constraint(equalTo: betweenLine1.leadingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let commentBottom = commentButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        let between1Trailing = betweenLine1.trailingAnchor.constraint(equalTo: disapproveButton.leadingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let between1Height = betweenLine1.heightAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonHeight)
        let between1Width = betweenLine1.widthAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.lineWidth)
        let between1Bottom = betweenLine1.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        let disapproveWidth = disapproveButton.widthAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonWidth)
        let disapproveHeight = disapproveButton.heightAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonHeight)
        let disapproveTrailing = disapproveButton.trailingAnchor.constraint(equalTo: betweenLine2.leadingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let disapproveBottom = disapproveButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        let between2Trailing = betweenLine2.trailingAnchor.constraint(equalTo: approveButton.leadingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let between2Height = betweenLine2.heightAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonHeight)
        let between2Width = betweenLine2.widthAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.lineWidth)
        let between2Bottom = betweenLine2.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        let approveLeading = approveButton.leadingAnchor.constraint(equalTo: betweenLine2.trailingAnchor, constant: StandardPostCollectionViewCell.padding)
        let approveHeight = approveButton.heightAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonHeight)
        let approveWidth = approveButton.widthAnchor.constraint(equalToConstant: VotableCollectionViewCell.buttonWidth)
        let approveTrailing = approveButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -2 * StandardPostCollectionViewCell.padding)
        let approveBottom = approveButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        let topLeading = topLine.leadingAnchor.constraint(equalTo: leadingAnchor, constant: StandardPostCollectionViewCell.padding)
        let topTrailing = topLine.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let topHeight = topLine.heightAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.lineWidth)
        let topBottom = topLine.bottomAnchor.constraint(equalTo: betweenLine1.topAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        commentLeading.isActive = true
        commentHeight.isActive = true
        commentTrailing.isActive = true
        commentBottom.isActive = true
        
        between1Trailing.isActive = true
        between1Height.isActive = true
        between1Width.isActive = true
        between1Bottom.isActive = true
        
        disapproveWidth.isActive = true
        disapproveHeight.isActive = true
        disapproveTrailing.isActive = true
        disapproveBottom.isActive = true
        
        between2Trailing.isActive = true
        between2Height.isActive = true
        between2Width.isActive = true
        between2Bottom.isActive = true
        
        approveLeading.isActive = true
        approveHeight.isActive = true
        approveWidth.isActive = true
        approveTrailing.isActive = true
        approveBottom.isActive = true
        
        topLeading.isActive = true
        topTrailing.isActive = true
        topHeight.isActive = true
        topBottom.isActive = true
        
    }
    
}
