/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Superclass for all post cells in feed that has a header with the poster's profile image and name on it.
*/


import UIKit

protocol StandardPostCollectionViewCellDelegate: class {
    func actionTriggered(cell: StandardPostCollectionViewCell)
}

class StandardPostCollectionViewCell: UICollectionViewCell {
    
    static let padding: CGFloat = 8.0
    static let profileImageSize: CGFloat = 30.0
    static let lineWidth: CGFloat = 0.5
    
    let profileImageView: UIImageView
    let profileNameLabel: UILabel
    let voteTimeLabel: UILabel
    let profileLine: UIView
    
    let longPressGestureRecognizer: UILongPressGestureRecognizer
    weak var delegate: StandardPostCollectionViewCellDelegate?
    
    // The minutes remaining before the post expires
    var minutesRemaining = 0 {
        didSet {
            voteTimeLabel.text = ("\(minutesRemaining)mins Remaining")
        }
    }
    
    override init(frame: CGRect) {
        
        profileImageView = UIImageView()
        profileNameLabel = UILabel()
        voteTimeLabel = UILabel()
        profileLine = UIView()
        longPressGestureRecognizer = UILongPressGestureRecognizer()
        
        super.init(frame: frame)
        
        commonInit()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        profileImageView = UIImageView()
        profileNameLabel = UILabel()
        voteTimeLabel = UILabel()
        profileLine = UIView()
        longPressGestureRecognizer = UILongPressGestureRecognizer()
        
        super.init(coder: aDecoder)
        
        commonInit()
        
    }
    
    func commonInit() {
        
        backgroundColor = UIColor(named: "AppGray")
        
        longPressGestureRecognizer.addTarget(self, action: #selector(cellLongPressed))
        longPressGestureRecognizer.minimumPressDuration = 1.0
        
        profileImageView.layer.cornerRadius = StandardPostCollectionViewCell.profileImageSize / 2.0
        profileImageView.clipsToBounds = true
        profileImageView.contentMode = .scaleAspectFit
        
        profileNameLabel.font = TextManager.profileNameFont
        profileNameLabel.textColor = UIColor.white
        
        voteTimeLabel.font = TextManager.subtitleFont
        voteTimeLabel.textColor = TextManager.subtitleColor
        voteTimeLabel.text = ("\(minutesRemaining)mins Remaining")
        voteTimeLabel.textAlignment = .right
        
        // AccessibilityCustom action added so that VoiceOver users can trigger the delete action, since VoiceOver
        // doesn't pass through the long press gesture. Adding this action to the cell itself means that all the cell's
        // subviews will inherit the custom action, so the user can initiate the delete from any subview of the cell
        let customAction = UIAccessibilityCustomAction(name: "Delete", target: self, selector: #selector(cellLongPressed))
        accessibilityCustomActions = [customAction]
        
        profileLine.backgroundColor = UIColor.white
        
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileNameLabel.translatesAutoresizingMaskIntoConstraints = false
        voteTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        profileLine.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(profileImageView)
        addSubview(profileNameLabel)
        addSubview(voteTimeLabel)
        addSubview(profileLine)
        
        addGestureRecognizer(longPressGestureRecognizer)
        
        let profileImageLeading = profileImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: StandardPostCollectionViewCell.padding)
        let profileImageTop = profileImageView.topAnchor.constraint(equalTo: topAnchor, constant: StandardPostCollectionViewCell.padding)
        let profileImageWidth = profileImageView.widthAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.profileImageSize)
        let profileImageHeight = profileImageView.heightAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.profileImageSize)
        
        let profileLabelLeading = profileNameLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: StandardPostCollectionViewCell.padding)
        let profileLabelCenterY = profileNameLabel.centerYAnchor.constraint(equalTo: profileImageView.centerYAnchor)
        let profileLabelHeight = profileNameLabel.heightAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.profileImageSize)
        
        let voteTimeLabelLeading = voteTimeLabel.leadingAnchor.constraint(equalTo: profileNameLabel.trailingAnchor, constant: StandardPostCollectionViewCell.padding)
        let voteTimeLabelFirstBaseline = voteTimeLabel.firstBaselineAnchor.constraint(equalTo: profileNameLabel.firstBaselineAnchor)
        let voteTimeLabelLastBaseline = voteTimeLabel.lastBaselineAnchor.constraint(equalTo: profileNameLabel.lastBaselineAnchor)
        let voteTimeLabelTrailing = voteTimeLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8.0)
        
        let profileLineTop = profileLine.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: StandardPostCollectionViewCell.padding)
        let profileLineHeight = profileLine.heightAnchor.constraint(equalToConstant: StandardPostCollectionViewCell.lineWidth)
        let profileLineLeading = profileLine.leadingAnchor.constraint(equalTo: leadingAnchor, constant: StandardPostCollectionViewCell.padding)
        let profileLineTrailing = profileLine.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        profileImageLeading.isActive = true
        profileImageTop.isActive = true
        profileImageWidth.isActive = true
        profileImageHeight.isActive = true
        
        profileLabelLeading.isActive = true
        profileLabelCenterY.isActive = true
        profileLabelHeight.isActive = true
        
        voteTimeLabelLeading.isActive = true
        voteTimeLabelFirstBaseline.isActive = true
        voteTimeLabelLastBaseline.isActive = true
        voteTimeLabelTrailing.isActive = true
        
        profileLineTop.isActive = true
        profileLineHeight.isActive = true
        profileLineLeading.isActive = true
        profileLineTrailing.isActive = true
        
    }
    
    @objc
    func cellLongPressed() {
        delegate?.actionTriggered(cell: self)
    }
    
}
