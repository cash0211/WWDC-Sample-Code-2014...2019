/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Rateable cell with just an image as content.
*/

import UIKit

class SingleImageRateableCollectionViewCell: RateableCollectionViewCell {
    
    let imageView: UIImageView
    
    override init(frame: CGRect) {
        imageView = UIImageView()
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        imageView = UIImageView()
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override func commonInit() {
        super.commonInit()
        
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(imageView)
        
        let imageTop = imageView.topAnchor.constraint(equalTo: profileLine.bottomAnchor, constant: StandardPostCollectionViewCell.padding)
        let imageLeading = imageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: StandardPostCollectionViewCell.padding)
        let imageTrailing = imageView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -StandardPostCollectionViewCell.padding)
        let imageBottom = imageView.bottomAnchor.constraint(equalTo: starsView.topAnchor, constant: -StandardPostCollectionViewCell.padding)
        
        imageTop.isActive = true
        imageLeading.isActive = true
        imageTrailing.isActive = true
        imageBottom.isActive = true
    }
    
}
