/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Super class for any cell that should be rateable by stars.
*/

import UIKit

class RateableCollectionViewCell: StandardPostCollectionViewCell {
    
    static let starSize: CGFloat = 30.0
    
    let starsView: StarsView
    
    var numStars: Int = 0 {
        didSet {
            starsView.numStars = numStars
        }
    }

    override init(frame: CGRect) {
        starsView = StarsView(stars: 0)
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        starsView = StarsView(stars: 0)
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override func commonInit() {
        super.commonInit()
        
        starsView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(starsView)
        
        let starsCenterX = starsView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let starsBottom = starsView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -StandardPostCollectionViewCell.padding)
        let starsWidth = starsView.widthAnchor.constraint(equalToConstant: 5 * RateableCollectionViewCell.starSize)
        let starsHeight = starsView.heightAnchor.constraint(equalToConstant: RateableCollectionViewCell.starSize)
        
        starsCenterX.isActive = true
        starsBottom.isActive = true
        starsWidth.isActive = true
        starsHeight.isActive = true
        
    }
    
}
