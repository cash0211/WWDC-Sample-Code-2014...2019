/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The View Controller that the app launches into. Main page of app with feed of posts.
*/

import UIKit

class HomeViewController: PostCollectionViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var profileNameLabel: UILabel!
    @IBOutlet weak var openPostsLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var notificationsButton: UIButton!
    @IBOutlet weak var settingsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profileImageView.layer.cornerRadius = profileImageView.bounds.width / 2.0
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(profileTapped))
        profileImageView.addGestureRecognizer(tapGesture)
        
        collectionView.contentInset = UIEdgeInsets(top: headerView.bounds.height, left: 0, bottom: 0, right: 0)
        collectionView.register(TextVotableCollectionViewCell.self, forCellWithReuseIdentifier: "TextCell")
        collectionView.register(SingleImageCollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        collectionView.register(SingleImageRateableCollectionViewCell.self, forCellWithReuseIdentifier: "RatingCell")
        
        // Set proper accessibility labels for our button in the header view
        addButton.accessibilityLabel = "New Post"
        notificationsButton.accessibilityLabel = "Notifications"
        // We want to say (the number of notifications) unread as our string, but since the titleLabel is optional
        // on UIButton, we need to provide a default case for this string
        notificationsButton.accessibilityValue = "\(notificationsButton.titleLabel?.text ?? "0") unread"
        settingsButton.accessibilityLabel = "Settings"
        
        // To join together the profile elements and indicate that they're a button to the VoiceOver user, we're going
        // to create an accessibility element that represents them grouped, and set its properties like we would
        // any other view
        let profileElement = UIAccessibilityElement(accessibilityContainer: headerView)
        profileElement.accessibilityLabel = profileNameLabel.text
        profileElement.accessibilityValue = openPostsLabel.text
        profileElement.accessibilityTraits |= UIAccessibilityTraitButton // Tells VoiceOver to treat our new view like a button
        
        let combinedLabelFrame = profileNameLabel.frame.union(openPostsLabel.frame)
        let profileElementFrame = combinedLabelFrame.union(profileImageView.frame)
        // This tells VoiceOver where the element is on screen so a user can find it as they touch around for elements
        profileElement.accessibilityFrameInContainerSpace = profileElementFrame
        
        // The header view's accessibilityElements are its accessible elements. Their order determines their swipe
        // order when swiping with VoiceOver
        headerView.accessibilityElements = [ profileElement, addButton, notificationsButton, settingsButton ]
    }
    
    override func postsArray() -> [Post] {
        return PostsDataSource.allPosts()
    }
    
    @objc
    func profileTapped() {
        performSegue(withIdentifier: "MyPostsSegue", sender: nil)
    }
    
}

