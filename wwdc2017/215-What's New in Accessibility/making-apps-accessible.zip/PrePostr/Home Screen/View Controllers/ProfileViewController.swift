/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The View Controller showing just the posts for a given user.
*/

import UIKit

class ProfileViewController: PostCollectionViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.register(TextVotableCollectionViewCell.self, forCellWithReuseIdentifier: "TextCell")
        collectionView.register(SingleImageCollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        collectionView.register(SingleImageRateableCollectionViewCell.self, forCellWithReuseIdentifier: "RatingCell")
    }
    
    @IBAction func closeTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func postsArray() -> [Post] {
        return PostsDataSource.allMyPosts()
    }

}
