/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The View Controller superclass for a collection of posts in a collection view.
*/


import UIKit

class PostCollectionViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, StandardPostCollectionViewCellDelegate {
    
    // Overriden by subclasses
    func postsArray() -> [Post] {
        return []
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return postsArray().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let posts = postsArray()
        let post = posts[indexPath.row]
        
        var cell: StandardPostCollectionViewCell = StandardPostCollectionViewCell()
        
        // There are 2 kinds of posts: votable posts and rateable posts. So we check to see what
        // kind of post we have to get the right cell type
        if post.isRating {
            
            guard let ratingCell = collectionView.dequeueReusableCell(withReuseIdentifier: "RatingCell", for: indexPath) as? SingleImageRateableCollectionViewCell else {
                fatalError("Could not dequeue Rating Cell at indexPath: \(indexPath)")
            }
            
            ratingCell.imageView.image = post.postImage
            cell = ratingCell
            
        } else {
            
            guard var textCell: TextVotableCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "TextCell", for: indexPath) as? TextVotableCollectionViewCell else {
                fatalError("Could not dequeue Text Cell at indexPath: \(indexPath)")
            }
            
            // There's a specific subclass of text cell that contains an image view, so if
            // our post has an image, need to make sure actually dequeue the correct cell kind
            if post.postImage != nil {
                guard let imageCell: SingleImageCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as? SingleImageCollectionViewCell else {
                    fatalError("Could not dequeue Image Cell at indexPath: \(indexPath)")
                }
                imageCell.fullImageView.image = post.postImage
                textCell = imageCell
            }
            
            // These lines apply to both image cells and cells with just text
            textCell.postTextLabel.text = post.postComment
            textCell.numComments = post.numComments
            textCell.numApproves = post.numUpvotes
            textCell.numDisapproves = post.numDownvotes
            cell = textCell
            
        }
        
        // These lines apply to all post cells, regardless of their kind
        cell.profileImageView.image = post.profileImage
        cell.profileNameLabel.text = post.profileName
        cell.minutesRemaining = post.minutesRemaining
        cell.delegate = self
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var height: CGFloat = 0
        let posts = postsArray()
        let post = posts[indexPath.row]
        
        // All post cell types have the profile area, so we can always add this height by default
        let profileAreaHeight: CGFloat = StandardPostCollectionViewCell.profileImageSize + 2.0 * StandardPostCollectionViewCell.padding
        height += profileAreaHeight
        
        // Rateable and votable cells can have images, so we account for that size regardless of cell type
        if post.postImage != nil {
            height += ((collectionView.bounds.width - 2 * StandardPostCollectionViewCell.padding) * post.postImage!.size.height) / post.postImage!.size.width
        }
        
        if post.isRating {
            height += 2 * StandardPostCollectionViewCell.padding + RateableCollectionViewCell.starSize
        } else {
            // Votable cells have the button area as well as possible text heights we need to acccount for
            let buttonAreaHeight: CGFloat = VotableCollectionViewCell.buttonHeight + 2.0 * StandardPostCollectionViewCell.padding
            
            // Using a dummy label to get the proper height for our text, setup with the same configuration
            // as the label in the actual cell will have
            let dummyLabel = UILabel()
            dummyLabel.font = TextManager.textFont
            dummyLabel.text = post.postComment
            dummyLabel.numberOfLines = 0
            let labelSize = dummyLabel.sizeThatFits(CGSize(width: collectionView.bounds.width - 2 * StandardPostCollectionViewCell.padding, height: 0))
            
            height += labelSize.height + buttonAreaHeight + 2 * StandardPostCollectionViewCell.padding
        }
        
        return CGSize(width: collectionView.bounds.width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func actionTriggered(cell: StandardPostCollectionViewCell) {
        let alertController = UIAlertController(title: "Delete Post", message: "Do you want to delete this post?", preferredStyle: .actionSheet)
        alertController.addAction(UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive) { _ in
            // Execute Delete Code
        })
        alertController.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) { _ in
            // Execute Cancel Code
        })
        present(alertController, animated: true, completion: nil)
    }

}
