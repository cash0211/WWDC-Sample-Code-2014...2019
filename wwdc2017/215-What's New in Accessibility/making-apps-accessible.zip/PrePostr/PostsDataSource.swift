/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A data source object that simply returns a pre-defined set of test data.
*/

import UIKit

struct Post {
    
    var profileImage: UIImage?
    var profileName: String?
    var minutesRemaining: Int
    var postComment: String?
    var postImage: UIImage?
    var numComments: Int
    var numUpvotes: Int
    var numDownvotes: Int
    var isRating: Bool
    
}

class PostsDataSource: NSObject {
    
    class func allPosts() -> [Post] {
        return [ friendPost1(), friendPost2(), myPost1(), friendPost3(), friendPost4(), myPost2(), friendPost5() ]
    }
    
    class func allMyPosts() -> [Post] {
        return [ myPost1(), myPost2() ]
    }
    
    class func friendPost1() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 5,
                        postComment: "Just finished the second day of my first WWDC ever! My brain hurts from information overload 😵",
                        postImage: nil,
                        numComments: 3,
                        numUpvotes: 3,
                        numDownvotes: 1,
                        isRating: false)
        return post
    }
    
    class func friendPost2() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 12,
                        postComment: "We have fun at home",
                        postImage: #imageLiteral(resourceName: "TestImage"),
                        numComments: 8,
                        numUpvotes: 12,
                        numDownvotes: 0,
                        isRating: false)
        return post
    }
    
    class func friendPost3() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 30,
                        postComment: "Maybe it's just the cold water talking, but begging @FirstLast to take me back feels like the right move.",
                        postImage: nil,
                        numComments: 4,
                        numUpvotes: 0,
                        numDownvotes: 7,
                        isRating: false)
        return post
    }
    
    class func friendPost4() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 44,
                        postComment: nil,
                        postImage: #imageLiteral(resourceName: "TestImage"),
                        numComments: 0,
                        numUpvotes: 0,
                        numDownvotes: 0,
                        isRating: true)
        return post
    }
    
    class func friendPost5() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 6,
                        postComment: "So excited to show you all the exciting things we just released! 💃🏻",
                        postImage: #imageLiteral(resourceName: "TestImage"),
                        numComments: 8,
                        numUpvotes: 16,
                        numDownvotes: 2,
                        isRating: false)
        return post
    }
    
    class func myPost1() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 14,
                        postComment: nil,
                        postImage: #imageLiteral(resourceName: "TestImage"),
                        numComments: 0,
                        numUpvotes: 0,
                        numDownvotes: 0,
                        isRating: true)
        return post
    }
    
    class func myPost2() -> Post {
        let post = Post(profileImage: #imageLiteral(resourceName: "TestProfileImage"),
                        profileName: "First Last",
                        minutesRemaining: 27,
                        postComment: "Feeling like the pressure is off now that a big deadline has passed!",
                        postImage: nil,
                        numComments: 2,
                        numUpvotes: 0,
                        numDownvotes: 6,
                        isRating: false)
        return post
    }

}
