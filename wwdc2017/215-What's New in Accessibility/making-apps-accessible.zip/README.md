# PrePostr

This sample mimics a social networking app as an example of how to make an app accessible.

## Overview

PrePostr conceptually is a social network for testing out your posts to another social network. The idea is that you would have a close group of friends that you would share a post with, those friends would comment on, upvote, downvote, or rate your post, giving you valuable feedback before you post your content worldwide.

Of course, this sample is not an actual functional social network (no servers running or real integrations). It is instead populated with artificial test data to present what such an app would look like if it were fully functional. This artificial data, and the various views that display it are used to exemplify how an app can be made accessible with the UIAccessibility API; ranging from the very basics, to the slightly more complex. The sample includes solutions to common problems that developers may face when making their own apps accessible, as well as illustrative examples of what we consider best practices when it comes to accessibility.

## Getting Started

No special setup is required, simply install the app on an iOS device running iOS 11 or later. To test accessibility features, enable VoiceOver on your device and open the app, paying particular attention to the way items are described and the various interaction flows that VoiceOver users follow to execute certain actions within the app.
