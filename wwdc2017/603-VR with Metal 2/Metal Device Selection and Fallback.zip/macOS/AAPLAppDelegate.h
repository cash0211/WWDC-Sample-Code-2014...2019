/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our macOS Application Delegate
*/


#import <Cocoa/Cocoa.h>

@interface AAPLAppDelegate : NSObject <NSApplicationDelegate>

@end
