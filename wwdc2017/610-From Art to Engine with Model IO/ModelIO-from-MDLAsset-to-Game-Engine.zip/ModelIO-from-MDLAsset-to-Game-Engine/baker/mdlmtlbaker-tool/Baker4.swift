/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains Baker that additionally processes rigid animation
*/

import Foundation
import ModelIO

/// - Tag: Animation
class Baker {
    var nodeNames = [String]()
    var texturePaths = [String]()

    var localTransforms = [matrix_float4x4]()
    var parentIndices = [Int?]()
    var meshNodeIndices = [Int]()
    var meshSkinIndices = [Int?]()
    var instanceCount = [Int]()

    var vertexDescriptors = [MDLVertexDescriptor]()
    var vertexBuffers = [Data]()
    var indexBuffers = [Data]()

    var meshes = [MeshData]()
    var skins = [SkinData]()

    var sampleTimes = [Double]()
    var localTransformAnimations = [[matrix_float4x4]]()
    var localTransformAnimationIndices = [Int?]()

    var skeletonAnimations = [AnimatedSkeleton]()
    var cameraData = CameraData()

    init() {}

    init(asset: MDLAsset) {
        sampleTimes = sampleTimeInterval(start: asset.startTime, end: asset.endTime, frameInterval: 1.0 / 60.0)
        storeAllMeshesInSceneGraph(with: asset)
        flattenSceneGraphHierarchy(with: asset)
        findCamera(with: asset)
        fixupPaths(asset, &texturePaths)
    }

    /// Record all buffers and materials for an MDLMesh
    func store(_ mesh: MDLMesh) {
        let vertexBufferCount = mesh.vertexBuffers.count
        let vbStartIdx = vertexBuffers.count
        let ibStartIdx = indexBuffers.count
        var idxCounts = [Int]()
        var idxTypes = [MDLIndexBitDepth]()
        var materials = [Material]()

        vertexDescriptors.append(mesh.vertexDescriptor)

        vertexBuffers += (0..<vertexBufferCount).map { vertexBufferIndex in
            let vertexBuffer = mesh.vertexBuffers[vertexBufferIndex]
            return Data(bytes: vertexBuffer.map().bytes, count: Int(vertexBuffer.length))
        }

        for case let submesh as MDLSubmesh in mesh.submeshes! {
            let idxBuffer = submesh.indexBuffer
            indexBuffers.append(Data(bytes: idxBuffer.map().bytes, count: Int(idxBuffer.length)))

            idxCounts.append(Int(submesh.indexCount))
            idxTypes.append(submesh.indexType)

            var material = Material()
            if let mdlMaterial = submesh.material {
                material.baseColor = readMaterialProperty(mdlMaterial, .baseColor, getMaterialFloat3Value)
                material.metallic = readMaterialProperty(mdlMaterial, .metallic, getMaterialFloatValue)
                material.roughness = readMaterialProperty(mdlMaterial, .roughness, getMaterialFloatValue)
                (_, material.normalMap) = readMaterialProperty(mdlMaterial, .bump, getMaterialFloat3Value)
                (_, material.ambientOcclusionMap) = readMaterialProperty(mdlMaterial, .ambientOcclusion,
                                                                         getMaterialFloat3Value)
            }
            materials.append(material)
        }

        let meshData = MeshData(vbCount: vertexBufferCount, vbStartIdx: vbStartIdx,
                                ibStartIdx: ibStartIdx, idxCounts: idxCounts,
                                idxTypes: idxTypes, materials: materials)
        meshes.append(meshData)
    }

    /// Record a node's parent index and store its local transform
    func flattenNode(_ nodeObject: MDLObject, nodeIndex: Int, parentNodeIndex: Int?) {
        nodeNames.append(nodeObject.path)
        if let transform = nodeObject.transform {
            localTransforms.append(transform.matrix)
            if transform.keyTimes.count > 1 {
                let sampledXM = sampleTimes.map { transform.localTransform!(atTime: $0) }
                localTransformAnimations.append(sampledXM)
                localTransformAnimationIndices.append(localTransformAnimations.count - 1)
            } else {
                localTransformAnimationIndices.append(nil)
            }
        } else {
            localTransforms.append(matrix_identity_float4x4)
            localTransformAnimationIndices.append(nil)
        }

        parentIndices.append(parentNodeIndex)
    }

    /// Store scene graph hierarchy's data in linear arrays
    func flattenSceneGraphHierarchy(with asset: MDLAsset) {
        walkSceneGraph(in: asset) { object, currentIdx, parentIdx in
            self.flattenNode(object, nodeIndex: currentIdx, parentNodeIndex: parentIdx)
        }
    }

    /// Store camera data
    func findCamera(with asset: MDLAsset) {
        guard let cameras = asset.childObjects(of: MDLCamera.self) as? [MDLCamera], cameras.count > 0 else {
            print("No cameras found")
            return
        }

        // select the first camera, since we only support one and the last one is default usually
        let camera = cameras.first!
        let cameraXFormIdx = nodeNames.index(of: camera.path)

        self.cameraData = CameraData(transformIndex: cameraXFormIdx,
                                     nearPlane: camera.nearVisibilityDistance,
                                     farPlane: camera.farVisibilityDistance,
                                     fieldOfView: camera.fieldOfView)
    }

    /// Record all mesh data required to render a particular mesh
    func storeAllMeshesInSceneGraph(with asset: MDLAsset) {
        var masterMeshes: [MDLMesh] = []
        walkMasters(in: asset) { object in
            guard let mesh = object as? MDLMesh else { return }
            store(mesh)
            masterMeshes.append(mesh)
        }

        var instanceMeshIdx = [Int]()
        walkSceneGraph(in: asset) { object, currentIdx, _ in
            if let mesh = object as? MDLMesh {
                meshNodeIndices.append(currentIdx)
                store(mesh)
                instanceMeshIdx.append(meshes.count - 1)
            } else if let instance = object.instance {
                meshNodeIndices.append(currentIdx)
                instanceMeshIdx.append(findMasterIndex(masterMeshes, instance)!)
            }
        }

        let (permutation, instCount) = sortedMeshIndexPermutation(instanceMeshIdx)
        meshNodeIndices = permutation.map { meshNodeIndices[$0] }
        instanceCount = instCount
    }

    /// Read a material's property of a particular semantic (e.g. .baseColor),
    /// and return tuple of uniform value or texture index
    func readMaterialProperty<T>(_ mdlMaterial: MDLMaterial, _ semantic: MDLMaterialSemantic,
                                 _ getPropertyValue: (MDLMaterialProperty) -> T) -> (uniform: T?, textureIndex: Int?) {
        var result: (uniform: T?, textureIndex: Int?) = (nil, nil)

        for property in mdlMaterial.properties(with: semantic) {
            switch property.type {
                case .float, .float3:
                    result.uniform = getPropertyValue(property)
                    return result
                case .string, .URL:
                    result.textureIndex = findTextureIndex(property.stringValue, &texturePaths)
                default: break
            }
        }
        return result
    }
}
