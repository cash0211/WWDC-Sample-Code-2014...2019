# Model IO Metal Art Pipeline

This sample demonstrates how the user would utilize Model IO to create baked data for use in a real time renderer.

## Overview

The worspace BakerAndEngine contains both mdlmtlbaker-tool and gameEngine projects

This sample contains the following folders:

* assets: contains all the assets the baker will turn into binary data used by the gameEngine
* baker: Contains mdlmtlbaker-tool, project and src, which converts assets in the assets folder into scene data and puts them in src_data/bakeddata for use in the gameEngine.
* engine: Contains a basic gameEngine with source, runs assets baked by the mdlmtlbaker-tool.

Each baker version adds additional data to the previous baker's output (see below).
To easily inspect what additional Model I/O API is used to export the new data, compare the source code of two consecutive bakers in a file compare tool such as FileMerge (located in /Applications/Xcode.app/Contents/Applications/FileMerge.app)

## Getting Started

### Setup for running gameEngine and mdlmtlbaker-tool in Xcode

Open the workspace file: BakerAndEngine and compile using Xcode

### Running

mdlmtlbaker project contains 5 targets which takes assets from assets->usd->race_track
and turns it into binary data in the same folder:
- [`Baker1`](x-source-tag://GeometryAndTransforms): export's Geometry and Transform Data
- [`Baker2`](x-source-tag://Materials): adds Materials to the export
- [`Baker3`](x-source-tag://Instancing): adds Instancing
- [`Baker4`](x-source-tag://Animation): adds rigid animation
- [`Baker5`](x-source-tag://Skinning): adds skinned animation
    
Afterwards run the gameEngine project to see the results.
