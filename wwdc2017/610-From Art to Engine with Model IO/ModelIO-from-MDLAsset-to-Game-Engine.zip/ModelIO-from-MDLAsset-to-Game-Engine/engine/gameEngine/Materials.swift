/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of materials and definitions
*/

import Foundation
import ModelIO
import MetalKit

struct MaterialUniforms {
    var baseColor = float4(1.0, 1.0, 1.0, 1.0)
    var irradiatedColor = float4(1.0, 1.0, 1.0, 1.0)
    var roughness: Float = 1.0
    var metalness: Float = 0.0
}
