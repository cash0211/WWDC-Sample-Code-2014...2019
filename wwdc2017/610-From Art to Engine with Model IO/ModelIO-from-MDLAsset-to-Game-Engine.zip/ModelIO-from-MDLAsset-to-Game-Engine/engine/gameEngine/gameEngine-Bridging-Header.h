/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Bridging header to grab all non swift related declarations
*/

#ifndef gameEngine_Bridging_Header_h
#define gameEngine_Bridging_Header_h

#import "ShaderTypes.h"
#import "SkyCubeShape.h"

#endif /* gameEngine_Bridging_Header_h */
