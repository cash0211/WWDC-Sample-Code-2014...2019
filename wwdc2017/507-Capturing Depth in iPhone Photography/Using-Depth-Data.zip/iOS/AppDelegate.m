/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Application delegate.
*/

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	return YES;
}

@end
