/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Main view controller.
*/

@import UIKit;

@interface MainViewController : UIViewController<UINavigationControllerDelegate,
                                                 UIImagePickerControllerDelegate>

@end


