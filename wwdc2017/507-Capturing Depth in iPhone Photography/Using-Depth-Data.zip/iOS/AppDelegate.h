/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Application delegate.
*/

@import UIKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

