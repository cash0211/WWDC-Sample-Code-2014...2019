/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Main application entry point.
*/

@import UIKit;

#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
