/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A simple swift example for calling cblas_sgemm().
*/

import Foundation
import Accelerate

//  This example multiplies two matrices, A and B, producing a third matrix C.
//  The dimensions of the matrices are defined by the variables M, N, and K
//  where matrix A is M x K, B is K x N, and the result matrix C is M x N.
//
//  For purposes of illustration, we assume column major layout of the matrices.
//  This layout can be counter intuitive to long time users of C/C++ as they are
//  likely more familiar with row major.  Below is an example illustrating the
//  difference between column major and row major:
//
//  Row Major:
//
//        K
//  +------------+
//  | -------->  |
//  |            |
//  |            |   M
//  |     A      |
//  |            |
//  |            |
//  |            |
//  +------------+
//
//  In the above illustration, the arrow indicates the direction of the rows.
//  Indexing into the above matrix then becomes: A[x+y*K].  That is, K is the
//  distance between values of y.  If instead, the  matrix was stored in
//  column major (as illustrated below):
//
//  Column Major:
//
//        M
//  +------------+
//  | |          |
//  | |          |
//  | |          |   K
//  | |   A      |
//  | v          |
//  |            |
//  |            |
//  +------------+
//
//  Then indexing into the above matrix would be: A[x+y*M].  For column major
//  matrices this also happens to be the first (or leading) dimension that
//  describes the matrix.  This makes the leading dimension of the matrix
//  effectively a stride.  For row major inputs, the stride would be the second
//  dimension of the matrix, in this case, K.

// Dimensions of the problem
let M: Int32 = 64
let N: Int32 = 128
let K: Int32 = 256

// The leading dimension of matrix A (M x K)
let LDA = M

// The leading dimension of matrix B (K x N)
let LDB = K

// The leading dimension of matrix C (M x N)
let LDC = M

// Matrix A is M x K
var A =  [Float](repeating: 1.0, count: Int(M * K) )

// Matrix B is K x N
var B =  [Float](repeating: 1.0, count: Int(K * N) )

// Matrix C is M x N
var C =  [Float](repeating: 1.0, count: Int(M * N) )

// C = alpha * AB + beta * C
// We are picking alpha = 1 and beta = 0
cblas_sgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, M, N, K, 1.0, &A, LDA, &B, LDB, 0, &C, LDC)

// Check the result
var correct = true
for element in C {

    if element != Float(K) {
        correct = false
        break
    }
}

if correct {
    print("\nThe result is correct.\n")
} else {
    print("\nThe result is incorrect.\n")
}
