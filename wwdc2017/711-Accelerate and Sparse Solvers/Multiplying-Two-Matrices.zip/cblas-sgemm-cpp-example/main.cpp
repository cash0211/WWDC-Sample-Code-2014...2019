/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A simple C++ example for calling cblas_sgemm().
*/

#include <iostream>
#include <Accelerate/Accelerate.h>

using namespace std;

//  This example multiplies two matrices, A and B, producing a third matrix C.
//  The dimensions of the matrices are defined by the variables M, N, and K
//  where matrix A is M x K, B is K x N, and the result matrix C is M x N.
//
//  For purposes of illustration, we assume column major layout of the matrices.
//  This layout can be counter intuitive to long time users of C/C++ as they are
//  likely more familiar with row major.  Below is an example illustrating the
//  difference between column major and row major:
//
//  Row Major:
//
//        K
//  +------------+
//  | -------->  |
//  |            |
//  |            |   M
//  |     A      |
//  |            |
//  |            |
//  |            |
//  +------------+
//
//  In the above illustration, the arrow indicates the direction of the rows.
//  Indexing into the above matrix then becomes: A[x+y*K].  That is, K is the
//  distance between values of y.  If instead, the  matrix was stored in
//  column major (as illustrated below):
//
//  Column Major:
//
//        M
//  +------------+
//  | |          |
//  | |          |
//  | |          |   K
//  | |   A      |
//  | v          |
//  |            |
//  |            |
//  +------------+
//
//  Then indexing into the above matrix would be: A[x+y*M].  For column major
//  matrices this also happens to be the first (or leading) dimension that
//  describes the matrix.  This makes the leading dimension of the matrix
//  effectively a stride.  For row major inputs, the stride would be the second
//  dimension of the matrix, in this case, K.

int main()
{
    // Dimensions of the problem
    const int M = 64;
    const int N = 128;
    const int K = 256;

    // The leading dimension of matrix A (M x K)
    const int LDA = M;

    // The leading dimension of matrix B (K x N)
    const int LDB = K;

    // The leading dimension of matrix C (M x N)
    const int LDC = M;

    // Matrix A is M x K
    float *A = new float[M*K];

    // Matrix B is K x N
    float *B = new float[K*N];

    // Matrix C is M x N
    float *C = new float[M*N];


    // Initialize the input matrices (in this case, to a trivial value)
    for(int i=0; i < M*K; i++) A[i] = 1;
    for(int i=0; i < K*N; i++) B[i] = 1;

    // C = alpha * AB + beta * C
    // We are picking alpha = 1 and beta = 0
    cblas_sgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, M, N, K, 1.0, A, LDA, B, LDB, 0, C, LDC);


    // Check the result
    bool correct = true;
    for(int i=0; i < M*N; i++)
    {
        if( C[i] != K )
        {
            correct = false;
            break;
        }
    }

    if( correct )
    {
        cout << "\nThe result is correct.\n";
    }
    else
    {
        cout << "\nThe result is incorrect.\n";
    }

    return 0;
}

