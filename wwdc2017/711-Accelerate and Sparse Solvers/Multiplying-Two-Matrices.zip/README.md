# Accelerate Matrix Multiply Example

This project provides an example of how to call [`cblas_sgemm()`](https://developer.apple.com/documentation/accelerate/1513264-cblas_sgemm) in C, C++, and Swift.

## Overview

This example demonstrates how to multiply two matrices in the fastest and most energy efficient manner. This is accomplished by using the `cblas_sgemm()` primitive, one of over 7000 primitives provided by the Accelerate framework.

## Getting Started

Simply open the Xcode project, select an example to run, and click play. Additional information can be found in the source for the example.
