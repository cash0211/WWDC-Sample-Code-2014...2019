/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Supporting code: implements a simple matrix format for elemental matrices
*/

import Foundation

/// Type implementing an elemental matrix.
// An elemental matrix is a sparse matrix that is made up of one or more
// dense sub-matrices known as elements. These elements are defined on a
// subset of rows and columns, and may overlap with each other.
struct ElementMatrix {
    // Each element is a dense matrix that is defined over some subset of indices
    struct Element {
        var size: Int = 0           // number of indices in element
        var indices: [Int] = []     // Indices of element
        var values: [Double] = []   // Values of element
        
        init(size: Int, indices: [Int], values: [Double] ) {
            self.size = size; self.indices = indices; self.values = values
        }
        
        // Extracts elements from x, and stores result of y += E*x to relevant indices of y
        func multiplyAdd(trans: Bool, x: UnsafeMutablePointer<Double>, y: UnsafeMutablePointer<Double>) {
            for jj in 0..<size {
                let j = indices[jj]
                for ii in 0..<size {
                    let i = indices[ii]
                    if trans { // Multiply by A^T
                        y[j] += values[jj * size + ii] * x[i]
                    } else {   // Multiply by A
                        y[i] += values[jj * size + ii] * x[j]
                    }
                }
            }
        }
    }
    
    // Underlying data for class
    var maximumIndex: Int  // Largest number used to index a variable + 1 (i.e. size of matrix)
    var elements: [Element] = []    // elements of matrix
    
    // Initialize by speciying maximum index, and then using addElement() to add elements
    init(maximumIndex: Int) { self.maximumIndex = maximumIndex }
    mutating func addElement(size: Int, indices: [Int], values: [Double]) {
        elements.append(Element(size: size, indices: indices, values: values))
    }
    
    // Performs the operation y =     op(A) x (if accumulate is false)
    //                     or y = y + op(A) x (if accumulate is true)
    // where op(A) = A or A^T depending on the value of trans
    func multiply(accumulate: Bool, trans: Bool, x: UnsafeMutablePointer<Double>, y: UnsafeMutablePointer<Double>) {
        // Initialize y to zero if we are not asked to accumulate
        if !accumulate {
            for i in 0..<maximumIndex { y[i] = 0.0 }
        }
        
        // Loop over elements, performing a matrix-vector product restricted to their indices with each
        for element in elements {
            element.multiplyAdd(trans: trans, x: x, y: y)
        }
    }
    
    // Create a Block-Jacobi (diagonal) preconditioner
    // A block jacobi preconditioner is one that is equivalent to solving Dx = b, where D is the
    // matrix consisting of only the diagonal blocks of our full matrix.
    func buildPreconditioner() -> BlockJacobiPreconditioner {
        let blockSize = 3 // We will use 3x3 blocks (we use __CLPK_integer for compatibility with LAPACK later)
        let blockCount = (self.maximumIndex - 1) / blockSize + 1 // Number of blocks required
        
        // Initialize preconditioner
        var preconditioner = BlockJacobiPreconditioner(blockCount: blockCount, blockSize: blockSize)
        
        // Iterate over element representation, adding entries to preconditioner
        for element in self.elements {
            let size = element.size // Number of indices in this element
            for jj in 0..<size {
                for ii in 0..<size {
                    preconditioner.addEntry(row: element.indices[ii],
                                            column: element.indices[jj],
                                            value: element.values[jj * size + ii])
                }
            }
        }
        
        // Tell the preconditioner to factorize the diagonal blocks, the last step prior to application
        preconditioner.factor()
        
        // All the information we need to apply the preconditioner is now stored in P.mem, so return
        // the fully constructed SparseOpaquePreconditioner_Double object.
        return preconditioner
    }
}

