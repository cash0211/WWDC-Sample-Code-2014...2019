/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Solve a symmetric positive-definite linear system using the Conjugate Gradient Method
*/

// Note that it is generally recommended that a direct method such as Cholesky
// factorization should be employed except in cases where either:
// * The matrix is not directly available, but multiplication by the matrix is
//   available as a function (i.e. A is treated as an operator in the mathematical
//   sense).
// * Performance and/or memory constraints make the direct method infeasible.
//
// This is because a problem-specific preconditioner is normally required to
// achieve convergence and/or performance in the iterative method, and as such
// more developer effort is required.

import Foundation
import Accelerate

// This program solves the following equation via the Conjugate Gradient (CG) Method.
//   ( 10.0  1.0      2.5 )     ( 2.20 )
//   (  1.0 12.0 -0.3 1.1 ) x = ( 2.85 )
//   (      -0.3  9.5     )     ( 2.79 )
//   (  2.5  1.1      6.0 )     ( 2.87 )
// We refer to the 4x4 matrix as A, and the right-hand side vector as b, and are
// hence solving the equation Ax = b.
//
// Note that A is sparse: some entries (those that are blank) are zero. Whilst for
// small matrices such as this there is little gain in exploiting this structure,
// it is essential for larger systems, which would not otherwise fit in memory even
// on a large machine.
//
// We will be using an iterative method, this requires the multiplication of a vector
// by a the matrix A. To aid convergence we will also specify a preconditioner to use,
// in this case the inverse of the diagonal of A (also known as Jacobi preconditioning).
// CG requires that the matrix is symmetric positive-definite, that is to say A=A^T and
// all eigenvalues are greater than zero. A sufficient (but not necessary) condition for
// a this is that the matrix is diagonally dominant (the sum of the absolute values of
// the off-diagonal entries in each row or column is less than the value of the diagonal).
// This is the case for the above matrix.

// We use a format known as Compressed Sparse Column (CSC) to store the data. Further,
// as the matrix is symmetric, we only need to store half the data. The CSC format
// stores the matrix as a series of column vectors where only the non-zero entries are
// specified, stored as the pair of (row index, value), although in seperate arrays:
var rowIndices: [Int32] = [    0,   1,   3,    1,    2,   3,   2,   3 ]
var values              = [ 10.0, 1.0, 2.5, 12.0, -0.3, 1.1, 9.5, 6.0 ]
// In addition to the (row index, value) pairs we need to specify where each column
// starts in these arrays. It is assumed to continue until the next column starts,
// which is why there is an additional entry in the next array so that the final
// column's length is known.
var columnStarts        = [    0,               3,              6,   7,   8]
// In this library, this raw information is all wrapper into a flexible data type
// that allows for more complex use cases in other situations.
let a = SparseMatrix_Double(
    // Structure of the matrix, without any values
    structure: SparseMatrixStructure(
        rowCount:     4,
        columnCount:  4,
        columnStarts: &columnStarts,
        rowIndices:   &rowIndices,
        // Matrix meta-data
        attributes: SparseAttributes_t(
            transpose: false,
            triangle: SparseLowerTriangle,
            kind: SparseSymmetric,
            _reserved: 0,
            _allocatedBySparse: false
        ),
        // For some problems, there may be a blockSize x blockSize block of values associated with
        // each structural matrix entry, rather than a single value. This is not the case in our
        // example, so we set blockSize=1.
        blockSize: 1
    ),
    // Numerical values of the matrix
    data: &values
)

// Once we have the factorization, we can perform the solve. The right-hand side and
// solution vectors are again arrays wrapped in flexible data-types. The actual values
// of x do not matter, as they will be overwritten by the solution.
var bValues = [ 2.20, 2.85, 2.79, 2.87 ]
var xValues = [ 0.00, 0.00, 0.00, 0.00 ]
let b = DenseVector_Double(
    count: 4,       // Number of entries in the vector, used for error checking
    data:  &bValues // The numerical values
)
let x = DenseVector_Double(
    count: 4,       // Number of entries in the vector, used for error checking
    data:  &xValues // The numerical values
)

// Perform the solve using the Conjugate Gradient Method with diagonal preconditioning
let status = SparseSolve(SparseConjugateGradient(), a, b, x, SparsePreconditionerDiagonal)
// If there was an error, the above code would print an error message and terminate.
// The user may instead capture the error by using the optional options argument to
// SparseConjugateGradient() with the member options.reportError set to a user-supplied error
// handling routine.

// Check the return status and print an error message if we failed to converge
if status != SparseIterativeConverged {
    print("Failed to converge. Returned with error ", status)
    exit(1)
}

// We can then print the solution. We should get the output:
//   x =  0.10 0.20 0.30 0.40
print("x = ", terminator: " ")
for xv in xValues {
    print(xv, terminator: " ")
}
print()
