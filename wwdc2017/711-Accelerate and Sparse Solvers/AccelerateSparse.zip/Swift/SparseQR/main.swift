/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Solve a least squares problem using the iterative method QR
*/

import Foundation
import Accelerate

// This program solves the following overdetermined equation via Sparse QR factorization
// to find the least squares solution.
//   ( 2.0  1.0     )     ( 1.200 )
//   ( -0.2 3.2 1.4 ) x = ( 1.013 )
//   (     -0.1 0.5 )     ( 0.205 )
//   ( 2.5  1.1     )     (-0.172 )
// We refer to the 4x3 matrix as A, and the right-hand side vector as b, and are
// hence find a solution to the equation Ax = b. As A is overdetermined (it has more
// rows than columns), for most right-hand sides there will not be an exact solution.
// In this case, it is normally required to find the closest solution, in the sense
// that it minimizes the 2-norm of the error. That is, it solves the optimization
//   min || Ax-b ||_2.
// This is known as the least-squares solution. If instead, A were underdetermined
// (it had more columns than rows) there would be more than one solution for any
// given right-hand side, and instead we might wish to find the solution of
// minimum norm. That is, to solve the optimization
//   min || x ||_2 s.t. Ax=b.
// By default, the SparseSolve() function from the Sparse QR factorization will
// return the solution to whichever of these two problems is appropriate given the
// dimensions of A. Note that in the square case these two problems are equivalent
// to solving Ax=b exactly.
//
// Note that A above is sparse: some entries (those that are blank) are zero. Whilst for
// small matrices such as this, there is little gain in exploiting this structure,
// it is essential for larger systems, which would not otherwise fit in memory even
// on a large machine.
//
// We will be performing a Sparse QR factorization, equivalent to the LAPACK
// function DGEQRF. As the factorization is not pivoted, the matrix must be non-singular.

// We use a format known as Compressed Sparse Column (CSC) to store the data. Further,
// as the matrix is symmetric, we only need to store half the data. The CSC format
// stores the matrix as a series of column vectors where only the non-zero entries are
// specified, stored as the pair of (row index, value), although in seperate arrays:
var rowIndices: [Int32] = [   0,    1,   3,   0,   1,    2,   3,   1,   2 ]
var values              = [ 2.0, -0.2, 2.5, 1.0, 3.2, -0.1, 1.1, 1.4, 0.5 ]
// In addition to the (row index, value) pairs we need to specify where each column
// starts in these arrays. It is assumed to continue until the next column starts,
// which is why there is an additional entry in the next array so that the final
// column's length is known.
var columnStarts        = [   0,              3,                   7,        9]
// In this library, this raw information is all wrapper into a flexible data type
// that allows for more complex use cases in other situations.
let a = SparseMatrix_Double(
    // Structure of the matrix, without any values
    structure: SparseMatrixStructure(
        rowCount:     4,
        columnCount:  3,
        columnStarts: &columnStarts,
        rowIndices:   &rowIndices,
        // Matrix meta-data
        attributes: SparseAttributes_t(
            transpose: false,
            triangle:  SparseLowerTriangle, // Actual value is irrelevant beacus kind=SparseOrdinary
            kind:      SparseOrdinary,      // We are storing an ordinary matrix
            _reserved: 0,
            _allocatedBySparse: false
        ),
        // For some problems, there may be a blockSize x blockSize block of values associated with
        // each structural matrix entry, rather than a single value. This is not the case in our
        // example, so we set blockSize=1.
        blockSize: 1
    ),
    // Numerical values of the matrix
    data: &values
)

// Perform the actual QR factorization, finding Q and R such that A = QR.
let qr = SparseFactor(SparseFactorizationQR, a)
// If there was an error, the above code would print an error message and terminate.
// The user may instead capture the error by using the optional options argument with
// the member options.reportError set to a user-supplied error handling routine. The
// resulting return value QR will have the property that QR.status value that reflects
// the error.

// Once we have the factorization, we can perform the solve. The right-hand side and
// solution vectors are again arrays wrapped in flexible data-types. The actual values
// of x do not matter, as they will be overwritten by the solution.
var bValues = [ 1.200, 1.013, 0.205, -0.172 ]
var xValues = [   0.0,   0.0,   0.0 ]
let b = DenseVector_Double(
    count: 4,       // Number of entries in the vector, used for error checking
    data:  &bValues // The numerical values
)
let x = DenseVector_Double(
    count: 3,       // Number of entries in the vector, used for error checking
    data:  &xValues // The numerical values
)

// The solve call takes the factorization A = QR and solves the least-squares problem by
// through normal equations A^TAx = A^Tb => R^TQ^TQRx = R^TQb => Rx = Qb by performing:
// 1) The multiplication y = Qb; then
// 2) Solving Rx = y.
// However the user needs only to supply the right-hand side and the factorization
SparseSolve(qr, b, x)
// Again, any errors will print an error message and terminate, unless the user set
// options.errorReport on the initial call to SparseFactor().

// We can then print the solution. We should get the output:
//   x =  0.10 0.20 0.30
print("x = ", terminator: " ")
for xv in xValues {
    print(String(format: "%.2f", xv), terminator: " ")
}
print()
