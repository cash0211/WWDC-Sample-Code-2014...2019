# Solving Sparse Systems

This sample demonstrates how to use the new Sparse Solvers in the Accelerate Framework.

## Overview

In addition to Sparse BLAS operations, Accelerate now provides sparse linear solvers that provide a sparse equivalent to the
dense solvers in Accelerate's LAPACK library.

A sparse matrix is one in which most entries are zero. By exploiting knowledge of this structure, sparse matrices require
significantly less storage than dense matrices. Further, linear algebra algorithms that exploit the sparse structure can
be thousands of times faster than their dense equivalents.

Accelerate provides both direct methods (matrix factorizations) and iterative methods to solve linear equations *Ax = b* and
least squares problems min *||Ax-b||*.
- **Direct methods** are the easiest to use, and often the fastest for all except the largest matrices.
- **Iterative methods** provide fast approximate solutions for large matrices where an expert user provides a good preconditioner
  for their problem.

## Getting Started

Examples are provided in both C and Swift. In both cases all that is required is to use the Accelerate framework:

C:

```#include <accelerate/accelerate.h>```

Swift:

```import Accelerate```

If you are using XCode, linking should be automatic, otherwise you may need to supply the following argument at link time:
```-framework accelerate```

## Direct Method Examples 

The following files provide examples of using direct methods
- **SparseCholesky** - example of solving *Ax=b* for symmetric positive-definte matrices *A* using a Cholesky factorization.
- **SparseQR** - example of solving the least squares problem *||Ax-b||* for rectangular matrices using a QR factorization.

## Iterative Method Exaples

The following files provide examples of using iterative methods
- **SparseCG** - example of solving *Ax=b* for symmetric positive-definte matrices *A* using the Conjugate Gradient method.
- **SparseLSMR** -  example of solving the least squares problem *||Ax-b||* for rectangular matrices using the LSMR method.
- **SparseIterativeAdvanced** - example of solving *Ax=b* where an operator function is provided rather than an explicit matrix,
  and a user-supplied preconditioner is used.

## Further Reading

- [Accelerate's Sparse Solver Documentation](https://developer.apple.com/documentation/accelerate/sparse_solvers)
