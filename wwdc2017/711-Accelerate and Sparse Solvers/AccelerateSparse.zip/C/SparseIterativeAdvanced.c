/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Demonstrates advanced usage of iterative methods using user-defined matrix-vector operator and
 preconditioner.
*/

#include <stdio.h>
#include <Accelerate/Accelerate.h>

// Structure to hold an elemental matrix descriptor
typedef struct {
  int n, nelt;
  int *sizes, *indices;
  double *data;
} Element;

// Function prototypes, see definitions for description
void doMatrixVector(Element matrix, bool accumulate, bool trans, const double *x, double *y);
SparseOpaquePreconditioner_Double buildPreconditioner(Element matrix);
void applyPreconditioner(void *mem, enum CBLAS_TRANSPOSE trans, DenseMatrix_Double X, DenseMatrix_Double Y);

// A simple routine to print status reports from GMRES
void reportStatus(const char *msg) { printf("GMRES: %s", msg); }

int main(void) {
  // This program demonstrates advanced usage of Accelerate's Sparse Solvers by using the
  // iterative method GMRES in a matrix-free context with a Block Jacobi preconditioner.
  //
  // We consider a simple finite element problem with the following grid:
  //
  //  0 ----- 1 ----- 2 ----- 3
  //  |       |       |       |
  //  |   A   |   B   |   C   |
  //  |       |       |       |
  //  4 ----- 5 ----- 6 ----- 7
  //  |       |       |       |
  //  |   D   |   E   |   F   |
  //  |       |       |       |
  //  8 ----- 9 ---- 10----- 11
  //
  // In each element A-F, there are sets of equations that relate the values at nodes 0-11.
  // For the purposes of this example, we have a single degree of freedom at each node, and
  // further assume the values at 3, 7 and 11 are constrained. Let the elemental matrices
  // (the constrains mentioned previously) be as follows:
  //
  // A: 0 (  0.2  0.1  0.4  0.6 ) B: 1 (  1.0  0.7  7.8  1.1 ) C: 2 (  5.5  0.4 )
  //    1 ( -3.0  0.5 -0.5 -2.2 )    2 ( -0.2 -0.2 -0.6  0.9 )    6 ( -0.3  0.2 )
  //    4 (  4.5  0.1  0.3  9.0 )    5 (  0.3  0.1  0.8  0.5 )
  //    5 ( -0.1 -2.0  0.1  0.3 )    6 (  5.4  1.5  0.1  0.7 )
  //
  // D: 4 ( -1.5  0.2  0.3  0.7 ) E: 5 (  0.2 -0.6  0.8  0.8 ) F: 6 ( -0.4  0.2 )
  //    5 (  0.2  0.1  2.5  0.2 )    6 ( -2.5  0.3 -1.6  0.7 )   10 (  3.1 -0.7 )
  //    8 ( -4.5 -2.1  0.3 -4.0 )    9 (  3.1  0.1  0.8  3.5 )
  //    9 (  0.1  0.1  1.3  0.1 )   10 (  0.2  0.5  2.8  2.5 )
  //
  // The fact that 3, 7 and 11 are constrained means that they don't appear in our equation,
  // but we will treat them as zero rows and columns to make addressing easier - if we make the
  // right-hand side zero and the starting guess for x in those locations zero, then they will
  // have no effect on the iterative method's convergence.
  int elementSizes[] = { 4, 4, 2, 4, 4, 2 };
  int elementIndices[] = { 0, 1, 4, 8,      // A
                           1, 2, 5, 6,      // B
                           2, 6,            // C
                           4, 5, 8, 9,      // D
                           5, 6, 9, 10,     // E
                           6, 10         }; // F
  double elementValues[] = {
     0.2, -3.0,  4.5, -0.1,  0.1,  0.5,  0.1, -2.0,  0.4, -0.5,  0.3,  0.1,  0.6, -2.2,  9.0,  0.3, // A
     1.0, -0.2,  0.3,  5.4,  0.7, -0.2,  0.1,  1.5,  7.8, -0.6,  0.8,  0.1,  1.1,  0.9,  0.5,  0.7, // B
     5.5,  0.4, -0.3,  0.2,                                                                         // C
    -1.5,  0.2, -4.5,  0.1,  0.2,  0.1, -2.1,  0.1,  0.3,  2.5,  0.3,  1.3,  0.7,  0.2, -4.0,  0.1, // D
     0.2, -2.5,  3.1,  0.2, -0.6,  0.3,  0.1,  0.5,  0.8, -1.6,  0.8,  2.8,  0.8,  0.7,  3.5,  2.5, // E
    -0.4,  3.1,  0.2, -0.7 };                                                                       // F
  Element matrix = { .n=12, .nelt=6, .sizes=elementSizes, .indices=elementIndices, .data=elementValues };
  // Whilst we could assemble these element matrices to get one large sparse matrix,
  // it can be more efficient to just store them separately if we just need to perform
  // a matrix-vector multiplication. This is done in the routine doMatrixVector().
  //
  // To aid convergence, we will build a block-Jacobi preconditioner by assembling only the diagonal
  // blocks of the full matrix and factorizing them. This is done in the routine buildPreconditioner().

  // We will solve for the right-hand side that is zero, except in positions 2, 6, and 10
  // on the basis that those values participate in elements with constrained nodes.
  double bdata[] = { 0.0, 0.0, 2.5, 0.0, 0.0, 0.0, 1.2, 0.0, 0.0, 0.0, 3.0, 0.0 };
  DenseVector_Double b = { .count=12, .data=bdata }; // 3 constrained nodes are just be set to zero.

  // Make the initial guess 0.0
  double xdata[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
  DenseVector_Double x = { .count=12, .data=xdata };

  // Create the preconditioner
  __auto_type P = buildPreconditioner(matrix);

  // Make the main SparseSolve() call
  __auto_type status = SparseSolve(
    SparseGMRES((SparseGMRESOptions) {
      // We set some options for the method to use
      .variant = SparseVariantGMRES,    // Use GMRES rather than the default DQGMRES as it's faster for this example
      .reportError = reportStatus,      // Report errors via reportStatus() instead of trapping.
      .reportStatus = reportStatus,     // Also print status every few iterations.
      .nvec = 8                         // Only use 8 vectors for orthagonalization.
    }),
    // This block specifies how to apply the matrix-multiplication operator
    // We just call our doMatrixVector() routine
    ^void(bool accumulate, enum CBLAS_TRANSPOSE trans, DenseVector_Double x, DenseVector_Double y) {
      doMatrixVector(matrix, accumulate, (trans==CblasTrans), x.data, y.data);
    }, b, x, P);
  // Check the return status and print an error message if we failed to converge
  if (status != SparseIterativeConverged) {
    printf("Failed to converge. Returned with error %d\n", status);
    exit(1);
  }
  // In the output we should see the residual decreasing. Only the residual for the first
  // right-hand side is printed, if more information is desired, use SparseIterate() instead.
  //   GMRES:     0     4.09e+00
  //   GMRES:     1     2.50e+00
  //   GMRES:     2     2.42e+00
  //   GMRES:     3     2.41e+00
  //   GMRES:     4     2.24e+00
  //   GMRES:     5     1.22e+00
  //   GMRES:     6     9.63e-01
  //   GMRES:     7     3.33e-01
  //   GMRES:     8     8.60e-02
  //   GMRES:     9     8.59e-02
  //   GMRES:    16     2.38e-03
  //   GMRES:    24     7.00e-05
  //   GMRES:    32     1.30e-06
  //   GMRES:    40     3.82e-08

  // We can now print the solution. We should get the output:
  //   x = -0.05 -0.06 0.37 0.00 0.01 -0.14 0.73 0.00 0.02 0.10 0.07 0.00
  printf("x = "); for (int i=0; i<x.count; i++) printf(" %.2f", x.data[i]); printf("\n");

  return 0;
}

// Performs the operation y =     op(A) x (if accumulate is false)
//                     or y = y + op(A) x (if accumulate is true)
// where op(A) = A or A^T depending on the value of trans
void doMatrixVector(Element matrix, bool accumulate, bool trans, const double *x, double *y) {
  // Initialize y to zero if we are not asked to accumulate
  if (!accumulate) {
      for (int i=0; i<matrix.n; i++) {
          y[i] = 0.0;
      }
  }

  // Loop over elements, performing a matrix-vector product restricted to their indices with each
  int *indices = matrix.indices; double *values = matrix.data;
  for (int elt=0; elt<matrix.nelt; elt++) {
    int sz = matrix.sizes[elt]; // Number of indices in this element
    if (trans) {
      // Multiplying by A^T
      for (int jj=0; jj<sz; jj++) {
        int j = indices[jj];
        for (int ii=0; ii<sz; ii++) {
          int i = indices[ii];
          y[j] += values[jj*sz+ii] * x[i];
        }
      }
    } else {
      // Multiplying by A
      for (int jj=0; jj<sz; jj++) {
        int j = indices[jj];
        for (int ii=0; ii<sz; ii++) {
          int i = indices[ii];
          y[i] += values[jj*sz+ii] * x[j];
        }
      }
    }
    // Increment index and value pointers
    indices += sz;
    values  += sz*sz;
  }
}

// Create a Block-Jacobi (diagonal) preconditioner
// A block jacobi preconditioner is one that is equivalent to solving Dx = b, where D is the
// matrix consisting of only the diagonal blocks of our full matrix.
SparseOpaquePreconditioner_Double buildPreconditioner(Element matrix) {
  __CLPK_integer blockSize = 3; // We will use 3x3 blocks (we use __CLPK_integer for compatibility with LAPACK later)
  int blockElements = blockSize * blockSize;
  int nblk = (matrix.n-1)/blockSize + 1; // Number of blocks required

  // To construct the preconditioner we need to store all the data we will need
  // in a single storage block.
  size_t dataSize = 2*sizeof(__CLPK_integer) +             // Storage for blockSize and nblk
                    nblk*blockElements*sizeof(double) +    // Storage for block data
                    nblk*blockSize*sizeof(__CLPK_integer); // Storage for LAPACK pivoting permutation
  SparseOpaquePreconditioner_Double P = {
    .type = SparsePreconditionerUser, // User-defined preconditioner. SparseCleanup() will have no effect if called.
    .mem = malloc(dataSize),          // void* pointer passed unchanged to applyPreconditioner()
    .apply = applyPreconditioner      // Function pointer for routine to apply the preconditioner
  };

  // Store nblk and blockSize into our memory block
  ((__CLPK_integer*) P.mem)[0] = nblk;
  ((__CLPK_integer*) P.mem)[1] = blockSize;

  // For ease of reference, we construct pointers into our single storage block.
  double *blockData        = (double*) ((char*)P.mem + 2*sizeof(__CLPK_integer));
  __CLPK_integer *ipivData = (__CLPK_integer*) ((char*)P.mem + 2*sizeof(__CLPK_integer) + nblk*blockElements*sizeof(double));

  // Zero block data
  memset(blockData, 0, nblk*blockElements*sizeof(double));

  // Iterate over element representation, dropping entries into place
  int *indices = matrix.indices; double *values = matrix.data;
  for (int elt=0; elt<matrix.nelt; elt++) {
    int sz = matrix.sizes[elt]; // Number of indices in this element
    for (int jj=0; jj<sz; jj++) {
      int j = indices[jj];          // The index of variable jj of this element
      int jBlock = j / blockSize;   // Block index of block j belongs to
      double *block = &blockData[jBlock*blockElements]; // Pointer to the preconditioner block j is in
      for (int ii=0; ii<sz; ii++) {
        int i = indices[ii];        // The index of variable ii of this element
        int iBlock = i / blockSize; // Block index of block i belongs to
        if (iBlock == jBlock) {
          // Entry falls within a diagonal block, sum it into the current value
          block[ (j % blockSize)*blockSize + (i % blockSize) ] += values[jj*sz+ii];
        }
      }
    }
    // Increment index and value pointers
    indices += sz;
    values  += sz*sz;
  }

  // Iterate over blocks, performing an LU factorization using the LAPACK routine DGETRF.
  for (int blk=0; blk<nblk; blk++) {
    double *block = &blockData[blk*blockElements];   // Pointer to current block's data
    __CLPK_integer *ipiv = &ipivData[blk*blockSize]; // Pointer to current block's pivoting permutation

    // If there is a zero on the diagonal, variable corresponds to a constrained (ommitted) variable,
    // to prevent LAPACK complaining, we set the diagonal to 1.0 in these cases.
    for (int i=0; i<blockSize; i++)
      if (block[i*blockSize+i]==0.0) block[i*blockSize+i] = 1.0;

    // Call LAPACK to perform LU factorization
    __CLPK_integer info;
    dgetrf_(&blockSize, &blockSize, block, &blockSize, ipiv, &info);
  }

  // All the information we need to apply the preconditioner is now stored in P.mem, so return
  // the fully constructed SparseOpaquePreconditioner_Double object.
  return P;
}

// Applies our Block Jacobi preconditioner after unpacking data passed via mem
// We use the LAPACK function DGETRS to perform a solve using the output from DGETRF when we built
// the preconditioner.
void applyPreconditioner(void *mem, enum CBLAS_TRANSPOSE trans, DenseMatrix_Double X, DenseMatrix_Double Y) {
  // We assume X and Y are not transposed (as we haven't used transpose in our SparseSolve() call)
  // and that we have a single right-hand side.
  __CLPK_integer nrhs = 1; // Number of right-hand sides

  // Extract useful information from mem
  __CLPK_integer nblk      = ((__CLPK_integer*) mem)[0];
  __CLPK_integer blockSize = ((__CLPK_integer*) mem)[1];
  int blockElements = blockSize * blockSize;
  double *blockData        = (double*) ((char*)mem + 2*sizeof(__CLPK_integer));
  __CLPK_integer *ipivData = (__CLPK_integer*) ((char*)mem + 2*sizeof(__CLPK_integer) + nblk*blockElements*sizeof(double));

  // Copy X into Y, as LAPACK's solves are in-place.
  // Note we assume a single right-hand side.
  for (int i=0; i<Y.rowCount; i++)
    Y.data[i] = X.data[i];

  // Apply the preconditioner by performing a solve with each block in turn
  for (int blk=0; blk<nblk; blk++) {
    double *block = &blockData[blk*blockElements];   // Pointer to current block's data
    __CLPK_integer *ipiv = &ipivData[blk*blockSize]; // Pointer to current block's pivoting permutation
    char transC = (trans==CblasNoTrans) ? 'N' : 'T'; // Transpose indicator
    __CLPK_integer ldy = Y.columnStride;             // Leading dimension of Y
    __CLPK_integer info;
    dgetrs_(&transC, &blockSize, &nrhs, block, &blockSize, ipiv, &Y.data[blk*blockSize], &ldy, &info);
  }
}
