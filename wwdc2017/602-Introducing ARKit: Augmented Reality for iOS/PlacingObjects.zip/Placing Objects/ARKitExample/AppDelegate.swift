/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Empty application delegate class.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var window: UIWindow?
}

