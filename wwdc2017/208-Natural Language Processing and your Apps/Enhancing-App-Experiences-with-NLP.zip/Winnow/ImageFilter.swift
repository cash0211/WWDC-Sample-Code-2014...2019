/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageFilter` class, which filters a collection of images based on a search string.
*/

import Foundation

import Cocoa

extension Notification.Name {
    static let imageFilterImagesDidChangeNotification = Notification.Name("ImageFilterImagesDidChangeNotification")
}

/**
    `ImageFilter` is a class that filters a collection of images based on their captions and a search string.
     It uses NSLinguisticTagger to tokenize and lemmatize both the captions and the search string, so that
     it can find a match even if different inflected forms of a word are used.
*/
class ImageFilter {
    // MARK: Properties
    
    let imageCollection: ImageCollection?
    
    fileprivate(set) var filteredImages = [ImageFile]()
    
    fileprivate var wordSets = [String: Set<String>]()
    
    fileprivate var languages = [String: String]()
    
    var searchString = "" {
        didSet {
            filterImages()
        }
    }
    
    // MARK: Initializer
    
    init(imageCollection: ImageCollection?) {
        self.imageCollection = imageCollection
        NotificationCenter.default.addObserver(self, selector: #selector(ImageFilter.imageCollectionDidChange(_:)),
                                               name: .imageCollectionDidChangeNotification, object: imageCollection)
    }

    @objc
    func imageCollectionDidChange(_ notification: Notification) {
        extractWordSetsAndLanguages()
        filterImages()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: .imageCollectionDidChangeNotification, object: imageCollection)
    }
    
    // MARK: Filtering
    
    /// Takes a string and produces a set of word forms from it, including all of the words of the text and their lemmas.
    /// - Tag: setOfWords
    fileprivate func setOfWords(string: String, language: inout String?) -> Set<String> {
        var wordSet = Set<String>()
        let tagger = NSLinguisticTagger(tagSchemes: [.lemma, .language], options: 0)
        let range = NSRange(location: 0, length: string.utf16.count)
        
        tagger.string = string
        if let language = language {
            // If language has a value, it is taken as a specification for the language of the text and set on the tagger.
            let orthography = NSOrthography.defaultOrthography(forLanguage: language)
            tagger.setOrthography(orthography, range: range)
        } else {
            // If language is nil, then the tagger sets it based on automatic identification of the language of the string.
            language = tagger.dominantLanguage
        }
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .lemma, options: [.omitPunctuation, .omitWhitespace]) { tag, tokenRange, _ in
            let token = (string as NSString).substring(with: tokenRange)
            // Each word of the text is inserted into the result set (in lowercase form).
            wordSet.insert(token.lowercased())
            if let lemma = tag?.rawValue {
                // If there is a lemma, it is also inserted into the result set (in lowercase form).
                wordSet.insert(lemma.lowercased())
            }
        }
        
        return wordSet
    }
    
    fileprivate func extractWordSetsAndLanguages() {
        var newWordSets = [String: Set<String>]()
        var newLanguages = [String: String]()
        
        // Make sure we have a word set and language for each image in our collection.
        if let images = imageCollection?.images {
            for image in images {
                let caption = image.caption
                
                if let wordSet = wordSets[caption] {
                    // If we have a cached set of words, use it.
                    newWordSets[caption] = wordSet
                    newLanguages[caption] = languages[caption]
                } else {
                    // Otherwise extract a set of words and identify the language.
                    var language: String?
                    let wordSet = setOfWords(string: caption, language: &language)
                    newWordSets[caption] = wordSet
                    newLanguages[caption] = language
                }
            }
        }
        
        wordSets = newWordSets
        languages = newLanguages
    }
            
    fileprivate func filterImages() {
        var language: String?
        var filterSet = setOfWords(string: searchString, language: &language)
        
        for existingLanguage in Set<String>(languages.values) {
            // Lemmatize the search string using each of our previously identified caption languages in turn.
            language = existingLanguage
            filterSet = filterSet.union(setOfWords(string: searchString, language: &language))
        }
        
        filteredImages.removeAll()
        
        if let images = imageCollection?.images {
            if filterSet.isEmpty {
                // If no search words, return all images.
                filteredImages.append(contentsOf: images)
            } else {
                // If we have search words, return those images whose caption words match the search words.
                for image in images {
                    guard let wordSet = wordSets[image.caption], !wordSet.intersection(filterSet).isEmpty else { continue }
                    filteredImages.append(image)
                }
            }
        }
        
        NotificationCenter.default.post(name: .imageFilterImagesDidChangeNotification, object: self)
    }
}
