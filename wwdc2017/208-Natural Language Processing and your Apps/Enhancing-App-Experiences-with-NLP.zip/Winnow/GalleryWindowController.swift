/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains a simple window controller subclass that displays an `ImageCollection`.
*/

import Cocoa

/**
    `GalleryWindowController` is a window controller that creates and manages
     the connections between two split panes in a `NSSplitViewController`
     set up as its `contentViewController`, with one `ImageCollectionController`
     and one `ImageViewerController`.
*/
class GalleryWindowController: NSWindowController {
    // MARK: Properties

    override var windowNibName: NSNib.Name? {
        return NSNib.Name("GalleryWindowController")
    }

    lazy var imageCollectionController: ImageCollectionController = {
        let imageCollectionController = ImageCollectionController()
        let imagesURL = Bundle.main.url(forResource: "Images", withExtension: "")!
        
        imageCollectionController.imageCollection = ImageCollection(rootURL: imagesURL)
        
        imageCollectionController.imageSelectionHandler = { [weak self] imageFile in
            self?.imageViewerController.imageFile = imageFile
        }

        return imageCollectionController
    }()

    lazy var imageViewerController: ImageViewerController = {
        let imageViewerController = ImageViewerController()
        
        imageViewerController.searchStringHandler = { [weak self] searchString in
            self?.imageCollectionController.searchString = searchString
        }
        
        return imageViewerController
    }()
    
    lazy var splitViewController: NSSplitViewController = {
        let splitViewController = NSSplitViewController()
        splitViewController.view.wantsLayer = true
        
        let imageViewerSplitViewItem = NSSplitViewItem(viewController: self.imageViewerController)
        imageViewerSplitViewItem.minimumThickness = 700
        imageViewerSplitViewItem.maximumThickness = 700
        splitViewController.addSplitViewItem(imageViewerSplitViewItem)
        
        let imageCollectionControllerSplitViewItem = NSSplitViewItem(viewController: self.imageCollectionController)
        imageCollectionControllerSplitViewItem.minimumThickness = 550
        splitViewController.addSplitViewItem(imageCollectionControllerSplitViewItem)
        
        return splitViewController
    }()

    // MARK: Life Cycle
    
    override func windowDidLoad() {
        super.windowDidLoad()
        
        guard let window = window else { fatalError("`window` is expected to be non nil by this time.") }
        
        let frameSize = window.contentRect(forFrameRect: window.frame).size
        splitViewController.view.setFrameSize(frameSize)
        window.contentViewController = splitViewController
    }
}
