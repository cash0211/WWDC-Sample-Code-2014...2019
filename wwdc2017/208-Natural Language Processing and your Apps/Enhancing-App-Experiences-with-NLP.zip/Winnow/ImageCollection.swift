/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageCollection` class, which is a collection of `ImageFile`s.
*/

import Cocoa

extension Notification.Name {
    static let imageCollectionDidChangeNotification = Notification.Name("ImageCollectionDidChangeNotification")
}

/**
    `ImageCollection` represents a directory on the file system that contains images.
    It creates and vends `ImageFile`s for each of those image files in the directory.
*/
class ImageCollection {
    // MARK: Properties
    
    fileprivate(set) var rootURL: URL
    
    fileprivate(set) var images = [ImageFile]()
    
    fileprivate var captions: [String: String]?
        
    // MARK: Initializer
    
    init(rootURL: URL) {
        self.rootURL = rootURL
        let captionsURL = rootURL.appendingPathComponent("Captions.plist", isDirectory: false)
        self.captions = NSDictionary(contentsOf: captionsURL) as? [String: String]
        ImageCollection.imageFileFetchingQueue.addOperation(loadImageFiles)
    }
    
    // MARK: Image List Manipulation
    
    fileprivate func addImageFile(_ imageFile: ImageFile) {
        images.append(imageFile)
        NotificationCenter.default.post(name: .imageCollectionDidChangeNotification, object: self)
    }
    
    // MARK: ImageFile Fetching
    
    fileprivate static var imageFileFetchingQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "ImageCollection Image Fetching Queue"
        return queue
    }()
        
    fileprivate func loadImageFiles() {
        let resourceValueKeys = [
            URLResourceKey.isRegularFileKey,
            URLResourceKey.typeIdentifierKey
        ]
        
        let options: FileManager.DirectoryEnumerationOptions = [.skipsSubdirectoryDescendants, .skipsPackageDescendants]
        
        // Create an enumerator to enumerate all of the immediate files in the referenced directory.
        guard let directoryEnumerator = FileManager.default.enumerator(at: rootURL,
                  includingPropertiesForKeys: resourceValueKeys, options: options, errorHandler: { url, error in
            print("`directoryEnumerator` error: \(error) at \(url).")
            return true
        }) else { return }
        
        var imageURLs = [URL]()
        
        for case let url as URL in directoryEnumerator {
            do {
                let resourceValues = try url.resourceValues(forKeys: Set(resourceValueKeys))
                
                // Verify the URL is a file and not a directory or symlink.
                guard let isRegularFile = resourceValues.isRegularFile,
                    isRegularFile else { continue }
                
                // Verify the URL is an image.
                guard let typeIdentifier = resourceValues.typeIdentifier,
                    UTTypeConformsTo(typeIdentifier as CFString, "public.image" as CFString) else { continue }
                
                imageURLs.append(url)
            } catch {
                print("Unexpected error occured: \(error).")
            }
        }
        
        // Update the image on the main queue.
        OperationQueue.main.addOperation {
            for url in imageURLs {
                guard let captions = self.captions,
                    let caption = captions[url.lastPathComponent] else { continue }
                let imageFile = ImageFile(url: url, caption: caption)
                self.addImageFile(imageFile)
            }
        }
    }
}
