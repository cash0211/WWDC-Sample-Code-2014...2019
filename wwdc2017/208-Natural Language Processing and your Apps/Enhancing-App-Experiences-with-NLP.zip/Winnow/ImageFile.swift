/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageFile` class, which represents an image at a given URL.
*/

import Cocoa

extension Notification.Name {
    static let imageFileThumbnailDidLoadNotification = Notification.Name("imageFileThumbnailDidLoadNotification")
    static let imageFileImageDidLoadNotification = Notification.Name("ImageFileImageDidLoadNotification")
}

/**
    `ImageFile` represents an image on disk. It can create thumbnail and full image representations.
*/
class ImageFile {
    // MARK: Properties

    fileprivate(set) var url: URL
    
    fileprivate(set) var caption: String
        
    static let preferredSize = NSSize(width: 533, height: 400)
    
    fileprivate static var thumbnailLoadingOperationQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "ImageFile Thumbnail Loading Queue"
        return queue
    }()
    
    fileprivate static var imageLoadingOperationQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "ImageFile Image Loading Queue"
        return queue
    }()
    
    fileprivate lazy var imageSource: CGImageSource? = {
        let imageSource = CGImageSourceCreateWithURL(self.url.absoluteURL as CFURL, nil)
        
        if let imageSource = imageSource {
            // Verify the image source has a valid uniform type identifier.
            guard CGImageSourceGetType(imageSource) != nil else { return nil }
        }
        
        return imageSource
    }()

    fileprivate var thumbnail: NSImage?
    
    fileprivate var image: NSImage?
    
    // MARK: Initializer

    init(url: URL, caption: String) {
        self.url = url
        self.caption = caption
    }

    // MARK: Image Loading

    func fetchThumbnailWithCompletionHandler(_ completionHandler: @escaping (NSImage) -> Void) {
        if let thumbnail = thumbnail {
            // If the thumbnail is already loaded, invoke the `completionHandler` with it immediately.
            completionHandler(thumbnail)
        } else {
            // Otherwise, load the thumbnail and callback once it has loaded.
            ImageFile.thumbnailLoadingOperationQueue.addOperation {
                guard let imageSource = self.imageSource else { return }

                let thumbnailOptions = [
                    String(kCGImageSourceCreateThumbnailFromImageIfAbsent): true,
                    String(kCGImageSourceThumbnailMaxPixelSize): 160
                ] as [String : Any]
                
                guard let thumbnailRef = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, thumbnailOptions as CFDictionary?) else { return }

                let thumbnailImage = NSImage(cgImage: thumbnailRef, size: NSSize.zero)

                OperationQueue.main.addOperation {
                    self.thumbnail = thumbnailImage
                    NotificationCenter.default.post(name: .imageFileThumbnailDidLoadNotification, object: self)
                    completionHandler(thumbnailImage)
                }
            }
        }
    }

    func fetchImageWithCompletionHandler(_ completionHandler: @escaping (NSImage) -> Void) {
        if let image = image {
            // If the image is already loaded, invoke the completionHandler with it immediately.
            completionHandler(image)
        } else {
            // Otherwise, load the image and callback once it has loaded.
            ImageFile.thumbnailLoadingOperationQueue.addOperation {
                guard let imageSource = self.imageSource else { return }

                // Create a full image from the image source.
                guard let imageRef = CGImageSourceCreateImageAtIndex(imageSource, 0, nil) else { return }

                let image = NSImage(cgImage: imageRef, size: ImageFile.preferredSize)

                OperationQueue.main.addOperation {
                    self.image = image
                    NotificationCenter.default.post(name: .imageFileImageDidLoadNotification, object: self)
                    completionHandler(image)
                }
            }
        }
    }
}

// `ImagesFile`s are equivalent if their URLs are equivalent.
extension ImageFile: Hashable {
    var hashValue: Int {
        return url.hashValue
    }
}

extension ImageFile: Equatable { }

func ==(lhs: ImageFile, rhs: ImageFile) -> Bool {
    return lhs.url == rhs.url
}
