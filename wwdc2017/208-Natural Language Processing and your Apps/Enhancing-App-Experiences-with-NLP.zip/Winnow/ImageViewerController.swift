/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageViewerController` view controller class, which displays an `ImageFile.`
*/

import Cocoa

/**
    `ImageViewerController` displays an `ImageFile` in a scrollable `NSImageView`. It shows
     the title of the set image file in a `NSTextField` label. It can be given a handler
     to report when the search string changes.
*/
class ImageViewerController: NSViewController {
    // MARK: Properties

    override var nibName: NSNib.Name? {
        return NSNib.Name("ImageViewerController")
    }
        
    @IBOutlet var imageView: NSImageView!
    @IBOutlet var scrollView: NSScrollView!
    @IBOutlet var titleField: NSTextField!
    @IBOutlet var bottomOverlayView: NSVisualEffectView!
    @IBOutlet var searchField: NSTextField!

    var imageFile: ImageFile? {
        didSet {
            guard isViewLoaded else { return }
            updateImageViewWithImageFile(imageFile)
        }
    }

    var searchStringHandler: ((String) -> Void)?
    
    // MARK: Life Cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        updateImageViewWithImageFile(imageFile)
    }
    
    func updateImageViewWithImageFile(_ imageFile: ImageFile?) {
        if let imageFile = imageFile {
            imageFile.fetchImageWithCompletionHandler { image in
                guard self.imageFile == imageFile else { return }
                
                let imageOrigin = NSPoint(x: ceil((self.scrollView.frame.size.width - image.size.width) / 2.0),
                                          y: ceil((self.scrollView.frame.size.height - image.size.height) / 2.0 - 25))
                self.imageView.image = image
                self.imageView.frame = NSRect(origin: imageOrigin, size: image.size)
                self.scrollView.magnify(toFit: self.imageView.frame)
            }
        } else {
            imageView.image = nil
        }

        titleField.stringValue = imageFile?.caption ?? ""
    }
    
    @IBAction func updateSearch(_ sender: AnyObject?) {
        guard let searchStringHandler = searchStringHandler else { return }
        searchStringHandler(searchField.stringValue)
    }
}
