/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageCollectionController` view controller subclass
      that displays the images in an `ImageCollection`.
*/

import Cocoa

/**
    `ImageCollectionController` displays the `ImageFiles` in a given `ImageCollection`
     as filtered by an `ImageFilter` in an `NSCollectionView`. It can be given a selection
     handler to report when an `ImageFile` is selected.
*/
class ImageCollectionController: NSViewController, NSCollectionViewDataSource, NSCollectionViewDelegate {
    // MARK: Properties

    override var nibName: NSNib.Name? {
        return NSNib.Name("ImageCollectionController")
    }
    
    fileprivate static let imageCollectionViewItemIdentifier = "ImageItem"
    
    @IBOutlet var collectionView: NSCollectionView!
    
    var imageSelectionHandler: ((ImageFile?) -> Void)?
    
    var imageFilter: ImageFilter = ImageFilter(imageCollection: nil)
    
    var imageCollection: ImageCollection? {
        didSet {
            // Observe the new filter for changes, and unobserve the old filter.
            NotificationCenter.default.removeObserver(self, name: .imageFilterImagesDidChangeNotification, object: imageFilter)
            imageFilter = ImageFilter(imageCollection: imageCollection)
            NotificationCenter.default.addObserver(self, selector: #selector(ImageCollectionController.imagesDidChange(_:)),
                                                   name: .imageFilterImagesDidChangeNotification, object: imageFilter)
            
            guard isViewLoaded else { return }
            reloadCollectionViewAndSelectFirstItemIfNecessary()
        }
    }

    var searchString: String = "" {
        didSet {
            imageFilter.searchString = searchString
        }
    }
    
    // MARK: Life Cycle
    
    @objc
    func imagesDidChange(_ notification: Notification) {
        reloadCollectionViewAndSelectFirstItemIfNecessary()
    }

    deinit {
	NotificationCenter.default.removeObserver(self, name: .imageFilterImagesDidChangeNotification, object: imageFilter)
    }
    
    override func viewDidLoad() {
        let nib = NSNib(nibNamed: NSNib.Name("ImageCollectionViewItem"), bundle: nil)

        collectionView.register(nib, forItemWithIdentifier:
            NSUserInterfaceItemIdentifier(ImageCollectionController.imageCollectionViewItemIdentifier))
        collectionView.dataSource = self
        collectionView.delegate = self

        // Create a grid layout that is somewhat flexible for the various widths it might have.
        let gridLayout = NSCollectionViewGridLayout()
        gridLayout.minimumItemSize = NSSize(width: 100, height: 100)
        gridLayout.maximumItemSize = NSSize(width: 175, height: 175)
        gridLayout.minimumInteritemSpacing = 10
        gridLayout.margins = NSEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        collectionView.collectionViewLayout = gridLayout

        reloadCollectionViewAndSelectFirstItemIfNecessary()

        super.viewDidLoad()
    }

    fileprivate func reloadCollectionViewAndSelectFirstItemIfNecessary() {
        collectionView.reloadData()

        guard collectionView.selectionIndexPaths.isEmpty else { return }
        collectionView.selectionIndexPaths = [IndexPath(item: 0, section: 0)]
        handleSelectionChanged()
    }

    // MARK: Collection View Data Source / Delegate

    func collectionView(_ collectionView: NSCollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageFilter.filteredImages.count
    }

    func collectionView(_ collectionView: NSCollectionView, itemForRepresentedObjectAt indexPath: IndexPath) -> NSCollectionViewItem {
        let item = collectionView.makeItem(withIdentifier:
            NSUserInterfaceItemIdentifier(ImageCollectionController.imageCollectionViewItemIdentifier), for: indexPath)
        let index = indexPath.item
        let filteredImages = imageFilter.filteredImages

        if let imageItem = item as? ImageCollectionViewItem, index >= 0 && index < filteredImages.count {
            imageItem.imageFile = filteredImages[index]
        }
    
        return item
    }

    func collectionView(_ collectionView: NSCollectionView, didSelectItemsAt indexPaths: Set<IndexPath>) {
        handleSelectionChanged()
    }

    func collectionView(_ collectionView: NSCollectionView, didDeselectItemsAt indexPaths: Set<IndexPath>) {
        handleSelectionChanged()
    }

    fileprivate func handleSelectionChanged() {
        guard let imageSelectionHandler = imageSelectionHandler else { return }
        
        let filteredImages = imageFilter.filteredImages
        let selectedImage: ImageFile?

        if let selectedIndex = collectionView.selectionIndexPaths.first?.item,
            selectedIndex >= 0 && selectedIndex < filteredImages.count {
            selectedImage = filteredImages[selectedIndex]
        } else {
            selectedImage = nil
        }

        imageSelectionHandler(selectedImage)
    }
}
