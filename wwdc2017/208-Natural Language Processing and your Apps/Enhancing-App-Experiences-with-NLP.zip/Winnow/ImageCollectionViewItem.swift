/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the `ImageCollectionViewItem` class, which is a collection view item
     that displays an `ImageFile`'s thumbnail.
*/

import Cocoa

/**
    `ImageCollectionViewItem` is a collection view item that displays an `ImageFile`.
*/
class ImageCollectionViewItem: NSCollectionViewItem {
    // MARK: Properties

    var imageFile: ImageFile? {
        didSet {
            guard isViewLoaded else { return }
            updateImageViewWithImageFile(imageFile)
        }
    }

    override var isSelected: Bool {
        didSet {
            updateAppearance()
        }
    }

    override var highlightState: NSCollectionViewItem.HighlightState {
        didSet {
            updateAppearance()
        }
    }

    // MARK: Life Cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        updateImageViewWithImageFile(imageFile)
    }

    override func viewDidAppear() {
        super.viewDidAppear()
        updateAppearance()
    }
    
    func updateImageViewWithImageFile(_ imageFile: ImageFile?) {
        if let imageFile = imageFile {
            imageFile.fetchThumbnailWithCompletionHandler { thumbnail in
                if self.imageFile == imageFile {
                    self.imageView?.image = thumbnail
                }
            }
        } else {
            imageView?.image = nil
        }
    }

    // MARK: Appearance Updating

    fileprivate func updateAppearance() {
        let baseHighlightColor = NSColor.alternateSelectedControlColor

        let backgroundColor: CGColor

        switch highlightState {
            case .forSelection:
                backgroundColor = baseHighlightColor.withAlphaComponent(0.4).cgColor

            case .asDropTarget:
                backgroundColor = baseHighlightColor.withAlphaComponent(1.0).cgColor

            default:
                if isSelected {
                    backgroundColor = baseHighlightColor.withAlphaComponent(0.8).cgColor
                } else {
                    backgroundColor = NSColor.clear.cgColor
                }
            }
        
        view.layer?.backgroundColor = backgroundColor
    }
}
