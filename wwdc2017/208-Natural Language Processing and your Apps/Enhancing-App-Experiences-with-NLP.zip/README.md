# Winnow

Winnow is a sample project that shows the use of [`NSLinguisticTagger`](https://developer.apple.com/documentation/foundation/nslinguistictagger) to process text for searching. It displays a collection of images with captions, and allows a search string to be entered that is used to filter the images to those whose captions match a word in the search string.

## Overview

### Model

The `ImageFilter` class filters a collection of images by matching their captions against a search string. It uses `NSLinguisticTagger` to tokenize and lemmatize both the captions and the search string, so that it can find a match even if the search string uses a different inflected form of a word than the caption does. The method using `NSLinguisticTagger` is `setOfWords(string:language:)`, which takes a string and produces a set of word forms from it, including all of the words of the text and their lemmas.

``` swift
fileprivate func setOfWords(string: String, language: inout String?) -> Set<String> {
    var wordSet = Set<String>()
    let tagger = NSLinguisticTagger(tagSchemes: [.lemma, .language], options: 0)
    let range = NSRange(location: 0, length: string.utf16.count)
    
    tagger.string = string
    if let language = language {
        // If language has a value, it is taken as a specification for the language of the text and set on the tagger.
        let orthography = NSOrthography.defaultOrthography(forLanguage: language)
        tagger.setOrthography(orthography, range: range)
    } else {
        // If language is nil, then the tagger sets it based on automatic identification of the language of the string.
        language = tagger.dominantLanguage
    }
    
    tagger.enumerateTags(in: range, unit: .word, scheme: .lemma, options: [.omitPunctuation, .omitWhitespace]) { tag, tokenRange, _ in
        let token = (string as NSString).substring(with: tokenRange)
        // Each word of the text is inserted into the result set (in lowercase form).
        wordSet.insert(token.lowercased())
        if let lemma = tag?.rawValue {
            // If there is a lemma, it is also inserted into the result set (in lowercase form).
            wordSet.insert(lemma.lowercased())
        }
    }
    
    return wordSet
}
```
[View in Source](x-source-tag://setOfWords)

`setOfWords(string:language)` also has an `inout language` parameter. If this parameter has a value, it is taken as a specification for the language of the text and set on the tagger. If it is nil, then the tagger sets it based on automatic identification of the language of the string. This is used to determine an overall set of languages based on identifying the language of each caption. When a search string is entered, it is lemmatized using each of these languages in turn, since a search string is usually too short for its language to be unambiguously identified by automatic means.

Some example words that can be typed as search strings:
**"hike" (returns images with captions containing "hikes", "hiked", "hiking")**
**"party" (returns images with captions containing "parties", "partied", etc.)**
**"marcher" (returns images with captions in French containing "marchais", "marchent", "marchons", etc.)**
**"spielen" (returns images with captions in German containing "spielen", "gespielt", etc.)**

The `ImageCollection` class represents a directory at a given `URL`. On initialization, it asynchronously creates `ImageFile`s to represent the images files in that directory. `ImageFile` lazily and asynchronously provides thumbnails and images for the represented image file `URL`.

### View Controllers

The `ImageCollectionController` displays the images in an `ImageCollection` in an `NSCollectionView`.

The `ImageViewerController` displays a single `ImageFile` in a scrollable `NSImageView`. The `GalleryWindowController` sets the visualized `ImageFile` based on the selection in the `ImageCollectionController`.

### Window Controllers

The `GalleryWindowController` controls the main window. It has an `NSSplitViewController` as its content, which displays an `ImageCollectionController` and `ImageViewerController` as children.

## Requirements

### Build

Xcode 9.0, macOS 10.13 SDK

### Runtime

macOS 10.13
