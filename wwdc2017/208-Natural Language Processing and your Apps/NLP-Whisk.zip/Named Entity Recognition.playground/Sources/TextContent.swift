import Foundation

public let text = """
Tim Cook is the CEO of Apple Inc. that is headquartered in Cupertino, California.
"""
