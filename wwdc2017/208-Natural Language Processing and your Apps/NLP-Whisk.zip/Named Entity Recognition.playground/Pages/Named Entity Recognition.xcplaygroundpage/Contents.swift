/*:
 # Named Entity Recognition
 
 This playground demonstrates how to use [`NSLinguisticTagger`](https://developer.apple.com/documentation/foundation/nslinguistictagger)'s [`enumerateTags(in:unit:scheme:options:using:)`](https://developer.apple.com/documentation/foundation/nslinguistictagger/2875124-enumeratetags) API.
 
 */
import Foundation

// In this example, we'll use `[.nameType]` as `tagSchemes` to create a `tagger` of Named Entities.
let tagger = NSLinguisticTagger(tagSchemes: [.nameType], options: 0)

// Set the string the tagger will tag.
tagger.string = text

// Set the linguistic tags to extract person, place and organization names.
let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]

// The tagger can omit whitespaces and punctuation. Also, it can return names as a single token.
let options: NSLinguisticTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames]

// Range of the string the tagger will look upon.
let range = NSRange(location: 0, length: text.utf16.count)

// Call `enumerateTags(in:unit:scheme:options:using:)` to extract named entities from the selected range.
tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, _ in
    // Make sure that the tag that was found is in the list of tags that we care about.
    guard let tag = tag, tags.contains(tag) else { return }

    let token = (text as NSString).substring(with: tokenRange)
    print("{token: \(token), tag: \(tag.rawValue), range: \(tokenRange)}")
}
//: [LICENSE](LICENSE)
