import Foundation

let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
let tagger = NSLinguisticTagger(tagSchemes: [.nameType], options: 0)

tagger.string = text

let options: NSLinguisticTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames]
let range = NSRange(location: 0, length: (text as NSString).length)

tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, _ in
    /*
        Make sure that the tag that was found is in the list of tags that we care
        about.
    */
    guard let tag = tag, tags.contains(tag) else { return }

    let token = (text as NSString).substring(with: tokenRange)
    print("[token: \(token), tag: \(tag.rawValue), range: \(range)]")
}
