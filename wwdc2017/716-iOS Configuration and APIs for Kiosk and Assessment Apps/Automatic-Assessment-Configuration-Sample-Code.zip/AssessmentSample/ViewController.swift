/*
See LICENSE folder for this sample’s licensing information.

Abstract:
ViewController for the main view
*/

import UIKit

class ViewController: UIViewController {
    /// Keeps track of what has happened in the app.
    @IBOutlet weak var logTextView: UITextView!

    var guidedAccessDidChangeToken: AnyObject?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateTitle()

        // ASAM requires iOS 9.3.2 or newer.
        guard #available(iOS 9.3.2, *) else {
            log("Version is: \(UIDevice.current.systemVersion) - API requires iOS 9.3.2")
            return
        }

        // Register for a notification whenever guided access state changes.
        guidedAccessDidChangeToken = NotificationCenter.default.addObserver(forName: .UIAccessibilityGuidedAccessStatusDidChange, object: nil, queue: .main) { _ in
            self.updateTitle()
            self.log("Notification: App Lock Status is now \(UIAccessibilityIsGuidedAccessEnabled() ? "On" : "Off")")
        }
    }

    /// Attempt to enter Single App mode and log the result.
    ///
    /// - Parameter sender: The button that was tapped.
    @IBAction func didTapOnButton(_ sender: UIButton) {
        UIAccessibilityRequestGuidedAccessSession(true) { didSucceed in
            self.log("Enable App Lock request - \(didSucceed ? "Succeeded" : "Failed")")
        }
    }
    
    /// Attempt to exit Single App mode and log the result.
    ///
    /// - Parameter sender: The button that was tapped.
    @IBAction func didTapOffButton(_ sender: UIButton) {
        UIAccessibilityRequestGuidedAccessSession(false) { didSucceed in
            self.log("Disable App Lock request - \(didSucceed ? "Succeeded" : "Failed")")
        }
    }
    
    /// Log a line of text.
    /// For convenience, prepend the line with an indication if guided access is
    /// on or off.
    ///
    /// The newest message is added at the top, so it's not obscured by the
    /// keyboard.
    ///
    /// - Parameter string: The string to be logged.
    func log(_ string: String) {
        let currentText = self.logTextView.text!
        let newLine = (UIAccessibilityIsGuidedAccessEnabled() ? "(Enabled)" : "(Disabled)") + " " + string + "\n"
        self.logTextView.text = newLine + currentText
    }
    
    /// Updates the title with the current status.
    func updateTitle() {
        title = "App Lock is \(UIAccessibilityIsGuidedAccessEnabled() ? "Enabled" : "Disabled")"
    }

    deinit {
        if let guidedAccessDidChangeToken = guidedAccessDidChangeToken {
            NotificationCenter.default.removeObserver(guidedAccessDidChangeToken)
        }
    }
}

extension ViewController: UITextFieldDelegate {
    
    // Resign first responder when the return key is tapped.
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
