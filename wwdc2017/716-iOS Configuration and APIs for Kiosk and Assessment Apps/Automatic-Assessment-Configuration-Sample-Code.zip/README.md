# ASAMple: iOS Configuration and APIs for Kiosk and Assessment Apps

This sample code demonstrates how to request a Guided Access session to lock the device into a single app, and to restrict the user to this application while they complete a specific task, such as taking a test.


## Overview

This sample code demonstrates how to request a Guided Access session to lock the device into a single app, to restrict the user to this application while they complete a specific task like taking a test.

Guided Access sessions can also be used in Kiosk applications to lock them in the foreground.


## Getting Started

There are two ways in which a device can be locked into a single application: Autonomous Single App Mode and Automatic Assessment Configuration.


### Autonomous Single App Mode (ASAM) — Requires device supervision and MDM management

Once the app's identifier has been whitelisted by MDM, calling this API will automatically lock the application in Single App Mode without requesting user confirmation.


### Automatic Assessment Configuration (AAC) — Requires EDU Assessment Mode entitlement

The Automatic Assessment Configuration (AAC) entitlement called EDU Assessment Mode (`com.apple.developer.edu-assessment-mode`) authorizes your iOS app to be configured automatically for giving tests.

This entitlement allows approved assessment developers to build apps that will lock an iOS device into a single app and invoke a specific set of restrictions. Automatic Assessment Configuration is the preferred method for administering assessment on iPad, as it requires no administrator overhead or configuration.

When using the EDU Assessment Mode entitlement, iOS will present an alert to the user requesting confirmation before locking them into the app.


#### Requesting access to the EDU Assessment Mode Entitlement

If you are an assessment developer, you may request access to this entitlement. Please [submit a Technical Support Incident](https://developer.apple.com/support/technical/) requesting access to the EDU Assessment Mode entitlement, along with a justification. The request will be evaluated by Apple's engineering team who will decide if the use case merits access to the EDU Assessment Mode entitlement.

Once it has been granted, the EDU Assessment Mode entitlement will be added to the developer portal and can be used when creating or updating provisioning profiles.


#### Signing the app with the EDU Assessment Mode Entitlement

As it stands, this sample code demonstrates Autonomous Single App Mode (ASAM) feature for requesting a Guided Access session, adding the EDU Assessment Mode entitlement will extend the app's capabilities; the API call itself does not change.

You can add the entitlements through the entitlements plist. If you are currently using the walk-through entitlements UI in Xcode, you will need to switch over to using an entitlements plist in this case.

When granted, the entitlement key and value will look like this in the plist:
``` xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
<key>com.apple.developer.edu-assessment-mode</key>
<true/>
</dict>
</plist>
```

In order to sign the app, a provisioning profile will need to be generated in the Developer Portal [Certificates, Identifiers & Profiles](https://developer.apple.com/account/ios/profile/) section that relates the App ID to the granted EDU Assessment Mode entitlement. This can be achieved by selecting Provisioning Profiles on the menu and then clicking the "+" button to create a new provisioning profile. Make sure the EDU Assessment Mode entitlement is selected in the Entitlements dropdown at the end of the profile creation process. You will need to go through process manually when generating both development and distribution provisioning profiles.

Once the profiles have been generated, bring them into Xcode, and then uncheck the `Automatically manage signing` box in the application target's "Signing" section.

Select the newly created provisioning profiles for Debug and Release, and double check the app is being signed using the EDU Assessment Mode entitlement by clicking the Info button adjacent to the Provisioning Profile in Xcode's Targets window, and looking for the string `com.apple.developer.edu-assessment-mode`.

Once your application has been signed using the EDU Assessment Mode entitlement, calling the API will present an alert to the user requesting confirmation before locking them into the app. Once they accept, the iOS device will lock itself into the application, and your app will be ready to proceed with the assessment.


## Requirements

### Build

Xcode 8.0 or later

### Runtime

iOS 9.3.2 or later
