/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Empty app delegate.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    // Nothing to do here. See ViewController for main functionality.

}

