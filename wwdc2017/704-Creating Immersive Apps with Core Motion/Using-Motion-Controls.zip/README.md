# Using Motion Controls

Demonstrates how to add motion based controls to an existing game.

## Overview

This is based on the Badger game from the [Badger: Advanced Rendering in SceneKit](https://developer.apple.com/library/content/samplecode/Badger/Introduction/Intro.html) sample.

The [`MotionManager`](x-source-tag://MotionManager) class shows you how to use the `CoreMotion` framework to request Device Motion samples. Once these samples are available, we use algorithms to detect whether the user has tilted the device from side to side, rotated the device upwards towards them or bumped the device downward to trigger the game controls.

### Build

Xcode 9.0 or later; iOS 11.0 SDK or later

### Runtime

iOS 11.0 or later
