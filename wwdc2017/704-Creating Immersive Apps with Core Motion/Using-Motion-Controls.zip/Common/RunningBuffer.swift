/*
See LICENSE folder for this sample’s licensing information.

Abstract:
This class manages a running buffer of Double values.
*/

import Foundation

struct RunningBuffer {
    // MARK: Properties

    var buffer = [Double]()
    var size = 0

    // MARK: Initialization

    init(size: Int) {
        self.size = size
        self.buffer = [Double](repeating: 0.0, count: self.size)
    }

    // MARK: Running Buffer

    mutating func addSample(_ sample: Double) {
        buffer.insert(sample, at:0)
        if buffer.count > size {
            buffer.removeLast()
        }
    }

    mutating func clear() {
        buffer.removeAll(keepingCapacity: true)
    }

    func isFull() -> Bool {
        return size == buffer.count
    }

    func sum() -> Double {
        return buffer.reduce(0.0, +)
    }

    func min() -> Double {
        var min = 0.0
        if let bufMin = buffer.min() {
            min = bufMin
        }
        return min
    }

    func max() -> Double {
        var max = 0.0
        if let bufMax = buffer.max() {
            max = bufMax
        }
        return max
    }

    func mean() -> Double {
         return self.sum() / Double(self.size)
    }
}
