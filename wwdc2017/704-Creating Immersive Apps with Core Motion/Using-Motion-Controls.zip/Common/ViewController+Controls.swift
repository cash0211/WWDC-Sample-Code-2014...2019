/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Handles touch (iOS) and controller input for controlling the game.
*/

import GameKit

extension ViewController {

    // MARK: Game Controller Events

    func setupGameControllers() {

        // Gesture recognizers
        let directions: [UISwipeGestureRecognizerDirection] = [.right, .left, .up, .down]
        for direction in directions {
            let gesture = UISwipeGestureRecognizer(target: self, action: #selector(didSwipe))
            gesture.direction = direction
            sceneView.addGestureRecognizer(gesture)
        }

    }

    @objc
    func handleControllerDidConnectNotification(_ notification: NSNotification) {
        guard let gameController = notification.object as? GCController else {
            return
        }
        registerCharacterMovementEvents(gameController)
    }

    private func registerCharacterMovementEvents(_ gameController: GCController) {
        // An analog movement handler for D-pads and thumbsticks.
        let movementHandler: GCControllerDirectionPadValueChangedHandler = { [unowned self] dpad, _, _ in
            self.controllerDPad = dpad
        }

        // Gamepad D-pad
        if let gamepad = gameController.gamepad {
            gamepad.dpad.valueChangedHandler = movementHandler
        }

        // Extended gamepad left thumbstick
        if let extendedGamepad = gameController.extendedGamepad {
            extendedGamepad.leftThumbstick.valueChangedHandler = movementHandler
        }
    }

    // MARK: Touch Events

    @objc
    func didSwipe(sender: UISwipeGestureRecognizer) {
        if startGameIfNeeded() {
            return
        }
    }

    // MARK: Controlling the Character

    func updateSpeed () {
        let speed = boostSpeedFactor * characterSpeed
        let effectiveSpeed = CGFloat(speedFactor * speed)

        scene.rootNode.animationPlayer(forKey: cartAnimationName)!.speed = effectiveSpeed
        wheels.animationPlayer(forKey: "wheel")!.speed = effectiveSpeed
        idleAnimationOwner.animationPlayer(forKey: "bob_idle-1")!.speed = effectiveSpeed

        // Update sound.
        updateCartSound()
    }

    func squat() {
        SCNTransaction.begin()
        SCNTransaction.completionBlock = {
            self.squatCounter -= 1
        }
        squatCounter += 1

        character.addAnimation(squatAnimation, forKey: nil)
        character.runAction(.playAudio(cartHide, waitForCompletion: false))

        SCNTransaction.commit()
    }

    func jump() {
        character.addAnimation(jumpAnimation, forKey: nil)
        character.runAction(.playAudio(cartJump, waitForCompletion: false))
    }

    func leanLeft() {
        character.addAnimation(leanLeftAnimation, forKey: nil)
        character.runAction(.playAudio(cartTurnLeft, waitForCompletion: false))
    }

    func leanRight() {
        character.addAnimation(leanRightAnimation, forKey: nil)
        character.runAction(.playAudio(cartTurnRight, waitForCompletion: false))
    }
}
