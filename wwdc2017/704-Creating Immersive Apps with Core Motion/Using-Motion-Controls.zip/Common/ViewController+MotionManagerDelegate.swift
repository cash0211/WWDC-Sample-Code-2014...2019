/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Handles motion control triggers
*/

import CoreGraphics

extension ViewController: MotionManagerDelegate {

    // MARK: Motion Manager Delegate

    func setMotionManagerDelegate() {
        motionManager.delegate = self
    }

    func deviceDidTilt(_ manager: MotionManager, percentage: Double) {
        // lean left or right based on tilt from gravity
        if percentage > 0.0 {
            leanRightPlayer.blendFactor = 0
            leanLeftPlayer.blendFactor = CGFloat(percentage)
        } else {
            leanLeftPlayer.blendFactor = 0
            leanRightPlayer.blendFactor = CGFloat(abs(percentage))
        }
    }

    func deviceDidRotateUp(_ manager: MotionManager) {
        jump()
    }

    func deviceDidBumpDownward(_ manager: MotionManager) {
        squat()
    }
}
