/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Handles the game's sound effects.
*/

import SceneKit

extension ViewController {
    // MARK: Sound effects

    func startTurn() {
        guard isSoundEnabled else { return }

        let player = SCNAudioPlayer(source: railSqueakSound)
        leftWheelEmitter.addAudioPlayer(player)
    }

    func stopTurn() {
        guard isSoundEnabled else { return }

        leftWheelEmitter.removeAllAudioPlayers()
    }

    func startWood() {
        isOverWood = true
        updateCartSound()
    }

    func stopWood() {
        isOverWood = false
        updateCartSound()
    }

    func trigger(characterSpeed speed: Float) {
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 2.0
        characterSpeed = speed
        SCNTransaction.commit()
    }

    func triggerCollision() {
        guard squatCounter <= 0 else { return }

        // Play sound and animate.
        character.runAction(.playAudio(hitSound, waitForCompletion: false))
        character.addAnimation(slapAnimation, forKey: nil)

        // Add stars.
        let emitter = character.childNode(withName: "Bip001_Head", recursively: true)
        emitter?.addParticleSystem(stars)
    }

    func changeSpeedSound(speed: UInt) {
        railSoundSpeed = speed
        updateCartSound()
    }

    func updateCartSound() {
        guard isSoundEnabled else { return }
        wheels.removeAllAudioPlayers()

        switch railSoundSpeed {
        case _ where isOverWood:
            wheels.addAudioPlayer(SCNAudioPlayer(source:railWoodSound))

        case 1:
            wheels.addAudioPlayer(SCNAudioPlayer(source:railLowSpeedSound))

        case 3:
            wheels.addAudioPlayer(SCNAudioPlayer(source:railHighSpeedSound))

        case let speed where speed > 0:
            wheels.addAudioPlayer(SCNAudioPlayer(source:railMediumSpeedSound))

        default: break
        }
    }

    func startMusic() {
        guard isSoundEnabled else { return }

        let musicIntroSource = Assets.sound(named: "music_intro.mp3")
        let musicLoopSource = Assets.sound(named: "music_loop.mp3")
        musicLoopSource.loops = true
        musicIntroSource.isPositional = false
        musicLoopSource.isPositional = false

        // `shouldStream` must be false to wait for completion.
        musicIntroSource.shouldStream = false
        musicLoopSource.shouldStream = true

        sceneView.scene?.rootNode.runAction(.playAudio(musicIntroSource, waitForCompletion: true)) { [unowned self] in
            self.sceneView.scene?.rootNode.addAudioPlayer(SCNAudioPlayer(source:musicLoopSource))
        }
    }
}
