/*
See LICENSE folder for this sample’s licensing information.

Abstract:
An SCNView used to setup the 2D overlay.
*/

import GameKit

class View: SCNView {

    // Resizing

    override func layoutSubviews() {
        super.layoutSubviews()
        update2DOverlays()
    }

    // MARK: Overlays

    private let _overlayNode = SKNode()
    private let _scaleNode = SKNode()
    private let _collectedItemsCountLabel = SKLabelNode(fontNamed: "Superclarendon")

    private func update2DOverlays() {
        _overlayNode.position = CGPoint(x: 0.0, y: bounds.size.height)
    }

    func setup2DOverlay() {
        let w = bounds.size.width
        let h = bounds.size.height

        // Setup the game overlays using SpriteKit.
        let skScene = SKScene(size: CGSize(width: w, height: h))
        skScene.scaleMode = .resizeFill

        skScene.addChild(_scaleNode)
        _scaleNode.addChild(_overlayNode)
        _overlayNode.position = CGPoint(x: 0.0, y: h)

        // The Bob icon.
        let bobSprite = SKSpriteNode(imageNamed: "BobHUD.png")
        bobSprite.position = CGPoint(x: 70, y:-50)
        bobSprite.xScale = 0.5
        bobSprite.yScale = 0.5
        _overlayNode.addChild(bobSprite)

        _collectedItemsCountLabel.text = "x0"
        _collectedItemsCountLabel.horizontalAlignmentMode = .left
        _collectedItemsCountLabel.position = CGPoint(x: 135, y:-63)
        _overlayNode.addChild(_collectedItemsCountLabel)

        // Assign the SpriteKit overlay to the SceneKit view.
        self.overlaySKScene = skScene
        skScene.isUserInteractionEnabled = false
    }

    var collectedItemsCount = 0 {
        didSet {
            _collectedItemsCountLabel.text = "x\(collectedItemsCount)"
        }
    }

    func didCollectItem() {
        collectedItemsCount += 1
    }

    func didCollectBigItem() {
        collectedItemsCount += 10
    }

}
