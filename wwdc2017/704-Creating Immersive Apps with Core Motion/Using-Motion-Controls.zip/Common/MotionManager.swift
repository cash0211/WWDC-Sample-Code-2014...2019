/*
See LICENSE folder for this sample’s licensing information.

Abstract:
This class is processing data from CoreMotion to produce game events.
*/

import UIKit
import CoreMotion

protocol MotionManagerDelegate: class {
    func deviceDidRotateUp(_ manager: MotionManager)
    func deviceDidBumpDownward(_ manager: MotionManager)
    func deviceDidTilt(_ manager: MotionManager, percentage: Double)
}

/// - Tag: MotionManager
class MotionManager {
     // MARK: Properties

    let motionManager: CMMotionManager
    var rateAlongHorizontalBuffer = RunningBuffer(size: 20)  // 1/3 sec buffer assuming ~60 fps
    var userAlongGravityBuffer = RunningBuffer(size: 20)     // 1/3 sec buffer assuming ~60 fps

    // App Specific Constants
    let rotationRateThreshold = 100.0                  // [dps]
    let userAccelerationThreshold = 0.3                // [g]
    let tiltRange = 15.0                               // [deg] Tilt angle required to get full lean

    var tiltAngleSign = 1.0
    var gestureSign = 1.0

    weak var delegate: MotionManagerDelegate?

    let queue = OperationQueue()

    // MARK: Motion Manager

	init() {
        motionManager = CMMotionManager()

        // Serial queue for sample handling and calculations.
        queue.maxConcurrentOperationCount = 1
        queue.name = "MotionManagerQueue"
	}

    func startMotionUpdates() {
        if !motionManager.isDeviceMotionAvailable {
            print("Device Motion is not available.")
            return
        }

        if !CMMotionManager.availableAttitudeReferenceFrames().contains(CMAttitudeReferenceFrame.xArbitraryZVertical) {
            print("The reference frame XArbitraryZVertical is not available.")
            return
        }

        motionManager.startDeviceMotionUpdates(using: CMAttitudeReferenceFrame.xArbitraryZVertical,
                                               to: queue,
                                               withHandler: motionHandler)

        // Device Orientation
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
    }

    func stopMotionUpdates() {
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
    }

    // MARK: Motion Processing

    var motionHandler: (CMDeviceMotion?, Error?) -> Void {
        return {
         (deviceMotion: CMDeviceMotion?, error: Error?) in

            guard deviceMotion != nil else { return }

            if deviceMotion != nil {
                self.updateRotationRate(deviceMotion!)
                self.updateUserAcceleration(deviceMotion!)
            }
        }
    }

    func pullSamples() {
        guard let deviceMotion = motionManager.deviceMotion else { return }

        setSignFromOrientation()

        // Detect when user accelerates downward beyond the threshold.
        if userAlongGravityBuffer.isFull() && userAlongGravityBuffer.mean() > userAccelerationThreshold {
            userAlongGravityBuffer.clear()
            delegate?.deviceDidBumpDownward(self)
        // Jump when a pulse up in rate is detected.
        } else if rateAlongHorizontalBuffer.isFull() && rateAlongHorizontalBuffer.mean() > rotationRateThreshold {
            rateAlongHorizontalBuffer.clear()
            delegate?.deviceDidRotateUp(self)
        } else {
            delegate?.deviceDidTilt(self, percentage: leanPercentage(deviceMotion))
        }
    }

    // MARK: Tilt

    func leanPercentage(_ deviceMotion: CMDeviceMotion) -> Double {
        let deadband = 2.0 / tiltRange      // [deg] Minimum tilt required for any lean

        let gravity = deviceMotion.gravity
        // Component of gravity in the x-z body frame
        let vertical = sqrt(pow(gravity.x, 2) + pow(gravity.z, 2))

        // Tilt is the angle between the gravity vector and the body x-z plane.
        // The sign of the angle (i.e. left vs right) is dependent on the device orientation.
        var tilt = atan2(gravity.y, vertical)
        tilt *= tiltAngleSign * 180 / Double.pi

        var percentage = tilt / tiltRange
        percentage = abs(percentage) < deadband ? 0.0 : percentage

        if percentage > 0.0 {
            return percentage - deadband
        } else {
            return percentage + deadband
        }
    }

    // MARK: Device Rotation

    func updateRotationRate(_ deviceMotion: CMDeviceMotion) {

        // horizontalRotationRate is the rate around the horizontal body axis.
        // The sign (i.e. up vs down) is dependent on the device orientation.
        let rotationRate = deviceMotion.rotationRate
        var horizontalRotationRate = rotationRate.y
        horizontalRotationRate *= gestureSign * 180 / Double.pi

        rateAlongHorizontalBuffer.addSample(horizontalRotationRate)
    }

    // MARK: Bump Downward

    func updateUserAcceleration(_ deviceMotion: CMDeviceMotion) {
        let gravity = deviceMotion.gravity
        let userAcceleration = deviceMotion.userAcceleration

        // userAlongGravity is the user acceleration along the gravity vector.
        // The sign (i.e. up vs down) is dependent on the device orientation.
        var userAccelerationAlongGravity = userAcceleration.x * gravity.x +
                                           userAcceleration.y * gravity.y +
                                           userAcceleration.z * gravity.z
        userAccelerationAlongGravity *= gestureSign * -1

        userAlongGravityBuffer.addSample(userAccelerationAlongGravity)
    }

    // MARK: Device Orientation

    func setSignFromOrientation() {
        // This demo only supports landscape. To support other orientations, you would customize this method.
        let orientation = UIDevice.current.orientation

        switch orientation {
            case .portrait, .portraitUpsideDown:
                // These could be supported by redefining vertical and tilt inside of leanPercentage.
                break
            case .landscapeLeft:
                // Body +y axis is to the right.
                tiltAngleSign = 1.0
                gestureSign = -1.0
            case .landscapeRight:
                // Body +y axis is to the left, so invert!
                tiltAngleSign = -1.0
                gestureSign = 1.0
            case .faceUp, .faceDown:
                // Handling faceUp and faceDown could be achieved using
                // UIInterfaceOrientation and the direction of gravity.
                break
            default:
                break
        }
    }
}
