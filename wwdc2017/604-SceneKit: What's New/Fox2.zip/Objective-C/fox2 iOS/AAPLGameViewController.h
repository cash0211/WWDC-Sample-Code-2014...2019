/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app's main view controller.
*/

#import <UIKit/UIKit.h>

@interface AAPLGameViewController : UIViewController

@end
