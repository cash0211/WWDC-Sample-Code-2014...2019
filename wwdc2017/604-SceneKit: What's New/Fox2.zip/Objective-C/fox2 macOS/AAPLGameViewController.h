/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app's main view controller.
*/

#import <Cocoa/Cocoa.h>

@interface AAPLGameViewController : NSViewController

@end

