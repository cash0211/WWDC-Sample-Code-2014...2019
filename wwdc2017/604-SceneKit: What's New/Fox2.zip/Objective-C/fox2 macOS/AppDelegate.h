/*
See LICENSE folder for this sample’s licensing information.

Abstract:
a standard App Delegate.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

