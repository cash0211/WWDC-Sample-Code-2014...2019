/*
See LICENSE folder for this sample’s licensing information.

Abstract:
a standard App Delegate.
*/

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    
}
