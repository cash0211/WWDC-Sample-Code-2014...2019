/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The NotificationManager is in charge of the UNUserNotificationCenter and manages the
         set-up and responses to notifications.
*/

import UIKit
import UserNotifications

/**
     The `NotificationManager` is responsible for maintaining the UNUserNotificationCenter, which
     controls how the phone registers, generates, and responds to notifications. The
     `PotlocViewController` creates an instance of `NotificationManager`, which calls
     registerForNotifications(_  geofenceTrigger: UNNotificationTrigger)
     and setupAndGenerateLocalNotification(_  geofenceTrigger: UNNotificationTrigger).
*/

class NotificationManager: NSObject {

    func registerForNotifications(_  geofenceTrigger: UNNotificationTrigger) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
            if granted {
                self.setupAndGenerateLocalNotification(geofenceTrigger)
            }
            if error != nil {
                print(error!)
            }
        }
    }

    func setupAndGenerateLocalNotification(_  geofenceTrigger: UNNotificationTrigger) {
        let content = UNMutableNotificationContent()
        content.title = "Geofence Notification"
        content.subtitle = "Core Location Region Monitoring"
        content.body = "You just entered/exited a geofence!"
        content.badge = 1
        content.sound = UNNotificationSound.default()

        let center = UNUserNotificationCenter.current()
        let request = UNNotificationRequest(identifier: "LocalNotification", content: content, trigger: geofenceTrigger)
        center.add(request) { error in
            if let error = error {
                print(error)
            }
        }
    }

    func removeNotifications() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
}

/**
     The `NotificationManager` extension implements the `UNUserNotificationCenterDelegate`, which handles
     function callbacks in response to registering and sending notifications.
 */

extension NotificationManager: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .sound, .badge])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
    }

    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: NSError) {

        print("Failed to register for notifications")
    }

    func application(_ application: UIApplication,
                     didReceiveRemoteNotification userInfo: [NSObject : AnyObject],
                     fetchCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
        print("Received notification")
    }
}
