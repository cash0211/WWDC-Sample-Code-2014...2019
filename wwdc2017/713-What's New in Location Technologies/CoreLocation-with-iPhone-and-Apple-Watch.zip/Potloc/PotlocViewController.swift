/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the PotlocViewController which shows how to use CLLocationManager to authorize
         location services using the new authorization prompt and how to enable location monitoring
         via location-based notifications even with only WhenInUse authorization.
*/

import UIKit
import CoreLocation
import UserNotifications

/**
     The `PotlocViewController` is responsible for maintaining the `CLLocationManager`.
 
     The `PotlocViewController` can create a location-based notification by creating a geofence at the
     current location with a 100m radius. Every time the iPhone enters or exits the boundaries of the
     geofence, the iPhone will receive a corresponding notification.
 
     Historically, location monitoring via geofences, significant location changes, and significant location
     visits were only available with Always authorization. We now require developers to adopt WhenInUse
     authorization, which still allows for geofence-based notifications.
*/

class PotlocViewController: UIViewController, CLLocationManagerDelegate {
    // MARK: Properties

    /// Location manager used to start and stop updating location.
    let manager = CLLocationManager()

    // Notification manager controls how the phone registers, generates, and responds to notifications
    let notificationManager = NotificationManager()

    // Indicates whether there is a geofence.
    var doesGeofenceExist = false

    /**
        Label to show the status of the Location Manager: running or not running.
        This label is useful for debugging.
    */

    // Button to create a geofence at the current location.
    @IBOutlet weak var geofenceCreationButton: UIButton!

    // Informs whether or not the user has entered or exited the geofence last created.
    @IBOutlet weak var geofenceStatusLabel: UILabel!

    // MARK: Localized String Convenience

    var createGeofenceButtonTitle: String {
        return NSLocalizedString("Create a Geofence", comment: "Pressing this button will create a geofence at the current location")
    }

    var removeGeofenceButtonTitle: String {
        return NSLocalizedString("Remove Geofence", comment: "Pressing this button will remove the geofence last created")
    }

    var geofenceEnteredText: String {
        return NSLocalizedString("Geofence Entered", comment: "Informs the user that the device has entered the geofence last created")
    }

    var geofenceExitedText: String {
        return NSLocalizedString("Geofence Exited", comment: "Informs the user that the device has exited the geofence last created")
    }

    var geofenceCreatedText: String {
        return NSLocalizedString("Geofence Created", comment: "Informs the user that the device has created a geofence")
    }

    var geofenceNoneText: String {
        return NSLocalizedString("There are no geofences", comment: "Informs the user that there are no geofences initially")
    }

    var geofenceUnauthorizedText: String {
        return NSLocalizedString("There are no geofences. Authorize location services to install a geofence.", comment:
            "Informs the user that the device has no geofences because it is not authorized")
    }

    // MARK: Initialization

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        commonInit()
    }

    /**
         Responds to the button press by either creating or removing geofences
         depending on the current state.
     */
    @objc
    func createRemoveGeofence() {
        if !doesGeofenceExist {
            createGeofence()
        } else {
            removeGeofence()
        }
    }

    func commonInit() {
        // Initialize the `CLLocationManager`.
        manager.delegate = self
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        geofenceStatusLabel.text = geofenceNoneText
        geofenceCreationButton.addTarget(self, action: #selector(createRemoveGeofence), for: UIControlEvents.touchUpInside)
    }

    // MARK: CLLocationManager functions

    /**
         This function is called when the CLLocationManager's authorization changes.
     */
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        createGeofence()
    }

    /**
        Creates a notification with a geofence trigger if the app has Always or WhenInUse authorization
    */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse {
            // Install notification-based fence
            createGeofenceNotification((locations.last)!)
        } else {
            // Do nothing
            print("Cannot create a geofence because the user has not granted access to Location Services.")
        }
    }

    /**
        Log any errors to the console.
     */
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error occured: \(error.localizedDescription).")
    }

    // MARK: Geofence-based notification functions

    /**
         Creating a geofence entails requesting for authorization and then requesting for the current location,
         which is used for the location-based trigger for the geofence
     */
    func createGeofence() {
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined:
            manager.requestAlwaysAuthorization()
            break
        case .authorizedWhenInUse:
            manager.requestLocation()
            break
        case .authorizedAlways:
            manager.requestLocation()
            break
        case .restricted:
            // Restricted by e.g. parental controls. User can't enable Location Services
            geofenceStatusLabel.text = geofenceUnauthorizedText
            break
        case .denied:
            // User denied access to Location Services, but can grant access later from the Settings app
            geofenceStatusLabel.text = geofenceUnauthorizedText
            break
        }
    }

    /**
         Given a location, create a notification with a geofence trigger with a radius of 100m.
     */
    func createGeofenceNotification(_ currentLocation: CLLocation) {
       let center = currentLocation.coordinate
        print(currentLocation.coordinate.latitude)
        print(currentLocation.coordinate.longitude)
        let region = CLCircularRegion(center: center, radius: 100.0, identifier: "Current Location")
        region.notifyOnEntry = true
        region.notifyOnExit = true
        let trigger = UNLocationNotificationTrigger(region: region, repeats: true)
        notificationManager.registerForNotifications(trigger)

        doesGeofenceExist = true
        geofenceStatusLabel.text = geofenceCreatedText
        geofenceCreationButton.setTitle(removeGeofenceButtonTitle, for: [.normal])
    }

    /**
         Remove the notification along with its notification trigger
     */
    func removeGeofence() {
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined, .authorizedWhenInUse, .authorizedAlways:
            geofenceStatusLabel.text = geofenceNoneText
            break
        case .restricted, .denied:
            geofenceStatusLabel.text = geofenceUnauthorizedText
            break
        }

        doesGeofenceExist = false
        geofenceCreationButton.setTitle(createGeofenceButtonTitle, for: [.normal])
        notificationManager.removeNotifications()
    }
}
