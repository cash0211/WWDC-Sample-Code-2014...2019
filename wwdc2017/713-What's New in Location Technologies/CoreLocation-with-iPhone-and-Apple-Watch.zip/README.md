# PotLoc: CoreLocation with iPhone and Apple Watch

This sample demonstrates what you can do with CoreLocation, Apple Watch, and iPhone in iOS 11.0 and watchOS 4.0.

## Overview

This sample demonstrates how to use the Core Location Framework in a Watch app, and its counterpart iOS app, to stream for continuous locations and set geofences in the foreground and background and illustrates new changes to the Core Location Framework API. The project also serves as a handy reference for developing more complicated features. For a complete list of properties and functions available, see the [Core Location Framework API Reference](https://developer.apple.com/documentation/corelocation).

## Version

3.0

## Build Requirements

- Xcode 9.0 or later.
- iOS 11.0 SDK or later.
- watchOS 4.0 SDK or later.
- Valid provisioning profile that supports push notifications.

## Runtime Requirements

- iOS 11.0 or later.
- watchOS 4.0 or later.

## About Potloc

Potloc is a sample app for iOS and watchOS that demonstrates the basics on how to request locations and enable location monitoring on the Apple Watch and/or on iPhone.

Potloc demonstrates how to:
- Utilize the new location privacy usage description key, `NSLocationAlwaysAndWhenInUseUsageDescription`, which prompts the user to allow for `.always` or `.whenInUse` authorization. (We strongly encourage developers to support `.WhenInUse` authorization whenever possible.) The `NSLocationAlwaysAndWhenInUseUsageDescription` key replaces the `NSLocationAlwaysUsageDescription` key, which is now deprecated.
- Still enable location monitoring via geofences on the iPhone by creating location-based notifications when the location privacy authorization is `.whenInUse`. (Historically, location monitoring via geofences, significant location changes, and significant location visits were only available with `.always` authorization.)
- Stream for continuous location updates in the foreground and in the background on Apple Watch.
- Display location information as complications on Apple Watch.
