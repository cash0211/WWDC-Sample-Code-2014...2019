/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the ContinuousLocationInterfaceController, which shows how to stream
         for continuous notifications from the standalone watch in the foreground as well
         as in the background. Location streaming only occurs when the location privacy
         setting level is set to 'Always'.
*/

import WatchKit
import Foundation
import UIKit

/**
     The `ContinuousLocationInterfaceController.swift` is an interface controller that
     exemplifies how to call the `CLLocationManager` directly from a WatchKit Extension using
     the `startUpdatingLocation(_:)` method.
 
     When the user starts location updates, this controller first informs the
     `CLLocationManager` to `requestWhenInUseAuthorization()`, then starts updating locations.
 
     This controller keeps track of the cumulative number of locations it has received, both
     in the foreground and in the background, and displays the newly-updated number of received
     locations to the user.
 */
class ContinuousLocationInterfaceController: WKInterfaceController, CLLocationManagerDelegate {

    // MARK: Properties

    /// Location manager for requesting authorization when starting location updates.
    let manager = CLLocationManager()

    /// Static text informing the user of the meaning of the foregroundLocationCount label.
    @IBOutlet var foregroundLocationCountTitleLabel: WKInterfaceLabel!

    /// Label to display the number of foreground locations received.
    @IBOutlet var foregroundLocationCountLabel: WKInterfaceLabel!

    // Static text informing the user of the meaning of the backgroundLocationCount label.
    @IBOutlet var backgroundLocationCountTitleLabel: WKInterfaceLabel!

    /// Label to display the number of background locations received.
    @IBOutlet var backgroundLocationCountLabel: WKInterfaceLabel!

    /// Button to send start/stop location update commands to the phone.
    @IBOutlet var startStopButton: WKInterfaceButton!

    /// Flag to determine whether to command start or stop updating location.
    var commandStartUpdatingLocation = true

    /// Cumulative count of foreground locations.
    var foregroundLocationCount = 0

    /// Cumulative count of background locations.
    var backgroundLocationCount = 0

    // MARK: Localized String Convenience

    var interfaceTitle: String {
        return NSLocalizedString("Continuous", comment: "Indicates to the user that this interface" +
            "exemplifies how to start and stop location updates on the watch in the foreground and the background")
    }

    var foregroundLocationsReceivedText: String {
        return NSLocalizedString("Foreground Locations:", comment: "Informs the user that the number below" +
            "represents the number of foreground locations received")
    }

    var backgroundLocationsReceivedText: String {
        return NSLocalizedString("Background Locations:", comment: "Informs the user that the number below" +
            "represents the number of background locations received")
    }

    var startingTitle: String {
        return NSLocalizedString("Starting", comment: "Indicates that the command to start updating location has been sent")
    }

    var stoppingTitle: String {
        return NSLocalizedString("Stopping", comment: "Indicates that the command to stop updating location has been sent")
    }

    var deniedTitle: String {
        return NSLocalizedString("Denied", comment: "Indicates that the user cannot start updating location")
    }

    var inactiveTitle: String {
        return NSLocalizedString("Inactive", comment: "Indicates that the watch is not actively connected to the phone")
    }

    var startTitle: String {
        return NSLocalizedString("Start", comment: "Indicates to send the command to start updating location")
    }

    var stopTitle: String {
        return NSLocalizedString("Stop", comment: "Indicates to send the command to stop updating location")
    }

    // MARK: Interface Controller

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)

        // Remember to set the location manager's delegate.
        manager.delegate = self
        manager.allowsBackgroundLocationUpdates = true

        setTitle(interfaceTitle)
        foregroundLocationCountTitleLabel.setText(foregroundLocationsReceivedText)
        backgroundLocationCountTitleLabel.setText(backgroundLocationsReceivedText)
    }

    // MARK: Button Actions

    /**
     Commands the phone to start or stop updating location, and adjusts the
     interface as necessary. Request when in use location usage before sending the
     command to the phone. Since the user is interacting with the watch, the
     prompt should originate from the watch.
     */
    @IBAction func startStopUpdatingLocation() {
        guard commandStartUpdatingLocation else {
            sendStopUpdatingLocationCommand()

            return
        }

        let authorizationStatus = CLLocationManager.authorizationStatus()

        switch authorizationStatus {
        case .notDetermined:
            startStopButton.setTitle(startingTitle)
            manager.requestWhenInUseAuthorization()

        case .authorizedWhenInUse, .authorizedAlways:
            sendStartUpdatingLocationCommand()

        case .denied:
            startStopButton.setTitle(deniedTitle)

        default:
            break
        }
    }

    // MARK: Handles commands to start/stop location updates

    /// Sends the message to start updating location, and handles the reply.
    func sendStartUpdatingLocationCommand() {
        print("In sendStart")
        startStopButton.setTitle(startingTitle)

        manager.startUpdatingLocation()

        startStopButton.setTitle(stopTitle)
        commandStartUpdatingLocation = false
    }

    /// Sends the message to stop updating location, and handles the reply.
    func sendStopUpdatingLocationCommand() {
        print("In sendStop")
        startStopButton.setTitle(stoppingTitle)

        manager.stopUpdatingLocation()

        startStopButton.setTitle(startTitle)
        commandStartUpdatingLocation = true
    }

    // MARK: CLLocationManagerDelegate Methods

    /**
     Sends the command to start updating location if the authorization status has
     changed to .authorizedWhenInUse or .authorizedAlways.
     */
    private func locationManager(_ manager: CLLocationManager, didChange status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            sendStartUpdatingLocationCommand()
        } else if status == .denied {
            DispatchQueue.main.async {
                self.startStopButton.setTitle(self.deniedTitle)
            }
        }
    }

    /**
     Increases that location count by the number of locations received by the
     manager. Updates the batch count with the added locations.
     */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let state = WKExtension.shared().applicationState
        if state == .active {
            foregroundLocationCount += locations.count
            foregroundLocationCountLabel.setText(String(foregroundLocationCount))
        } else if state == .background {
            backgroundLocationCount += locations.count
            backgroundLocationCountLabel.setText(String(backgroundLocationCount))
        }
    }

    /// Log any errors to the console.
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error occured: \(error.localizedDescription).")
    }
}
