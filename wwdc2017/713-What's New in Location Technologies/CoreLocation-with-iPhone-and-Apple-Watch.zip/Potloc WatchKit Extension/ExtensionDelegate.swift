/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Default ExtensionDelegate provided by the project.
*/

import WatchKit
import CoreLocation

class ExtensionDelegate: NSObject, WKExtensionDelegate { }
