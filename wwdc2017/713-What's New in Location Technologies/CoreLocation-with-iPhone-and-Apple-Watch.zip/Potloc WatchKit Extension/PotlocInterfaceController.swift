/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Default interface controller provided by the project.
*/

import WatchKit
import Foundation

class PotlocInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
    }
}
