# SegueCatalog: Customizing and Unwinding with View Controller Containment

This sample demonstrates how to use External References to factor your storyboards, how to combine UIStoryboardSegue subclasses with Transition Delegates and Adaptivity, and how to use unwind segues with custom container view controllers.

This sample code builds with Swift 3.

## Requirements

### Build

Xcode 8.0, iOS 9.0 SDK

### Runtime

iOS 9.0

Copyright (C) 2015 Apple Inc. All rights reserved.
