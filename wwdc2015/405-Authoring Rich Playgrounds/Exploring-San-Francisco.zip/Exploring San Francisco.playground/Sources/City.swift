import UIKit
import CoreLocation

/// Declare City struct
public struct City: CustomStringConvertible {
    
    /// A dictionary of Places in this City mapped to a dictionary which maps destination Places to the travel time required to get to that Place.
    ///
    /// - note: This dictionary is somewhat sparse, so to determine the travel time between Places `foo` and `bar`, both of the following must be checked:
    ///
    ///   - `placesAndTravelTimes[foo]?[bar]`
    ///   - `placesAndTravelTimes[bar]?[foo]`
    var placesAndTravelTimes = [Place: [Place: Double]]()
    
    /// Initializes an empty City.
    public init() {}
    
    // Mutating function to allow adding of Place
    public mutating func addPlace(place: Place) {
        precondition(placesAndTravelTimes[place] == nil)
        placesAndTravelTimes[place] = [:]
    }
    
    /// Mutating function to allow adding of travel time between Places
    public mutating func addTravelTime(travelTime: Double, betweenPlaces origin: Place, _ destination: Place) {
        precondition(placesAndTravelTimes[origin] != nil)
        precondition(placesAndTravelTimes[destination] != nil)
        
        precondition(placesAndTravelTimes[origin]![destination] == nil)
        precondition(placesAndTravelTimes[destination]![origin] == nil)
        
        placesAndTravelTimes[origin]![destination] = travelTime
    }
    
    /// Returns the travel time between the given Places, or nil if it is not possible to travel from the origin to the destination.
    public func travelTimeBetweenPlaces(origin: Place, _ destination: Place) -> Double? {
        return placesAndTravelTimes[origin]?[destination] ?? placesAndTravelTimes[destination]?[origin]
    }
    
    public var places: Set<Place> {
        return Set(placesAndTravelTimes.keys)
    }
    
    public subscript(placeName: String) -> Place? {
        let filteredPlaces = places.filter { $0.name == placeName }
        precondition(filteredPlaces.count <= 1)
        return filteredPlaces.first
    }
    
    public struct PathsView: SequenceType, CustomStringConvertible {
        private let paths: [[Place]]
        
        public typealias Generator = IndexingGenerator<[[Place]]>
        
        private init(paths: [[Place]]) {
            self.paths = paths
        }
        
        public func generate() -> Generator {
            return IndexingGenerator(paths)
        }
        
        public var description: String {
            return "\(paths.count) paths"
        }
    }
    
    public func allPathsThroughCity(startingAtPlace start: Place? = nil, endingAtPlace end: Place? = nil) -> PathsView {
        let placesToSubtract = [start, end].flatMap { $0 }
        let remainingPlaces = self.places.subtract(placesToSubtract)
        let remainingPermutations = remainingPlaces.permutations
        return PathsView(paths: remainingPermutations.map { (partialPath) -> [Place] in
            var path: [Place] = []
            if let start = start { path.append(start) }
            path += partialPath
            if let end = end { path.append(end) }
            return path
        })
    }
    
    public func travelTimeForPath(path: [Place]) -> Double {
        if path.isEmpty { return 0 }
        
        var totalTravelTime: Double = 0
                
        for i in 0..<(path.count - 1) {
            totalTravelTime += self.travelTimeBetweenPlaces(path[i], path[i+1])!
        }
        
        return totalTravelTime
    }
    
    
    /// CustomStringConvertible conformance
    public var description: String {
        return "\(Array(placesAndTravelTimes.keys))"
    }
    
}

/// Extending our City struct to implement CustomPlaygroundQuickLookable
extension City: CustomPlaygroundQuickLookable {
    
    /// Implement customPlaygroundQuickLook() to return a view of our City
    public func customPlaygroundQuickLook() -> PlaygroundQuickLook {
        
        /// Create a view for our quick look
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 600))
        view.backgroundColor = UIColor.whiteColor()
        view.layer.borderColor = UIColor.darkGrayColor().CGColor
        view.layer.borderWidth = 2.0
        view.layer.cornerRadius = 5.0
        
        /// Bounding coordinates for the places in San Francisco we care about
        let topLeft = CLLocationCoordinate2D(latitude: 37.832713, longitude: -122.497338)
        let bottomRight = CLLocationCoordinate2D(latitude: 37.743991, longitude: -122.385758)
        
        var placeViews: [Place: Place.View] = [:]
        
        func viewForPlace(place: Place) -> Place.View {
            if let placeView = placeViews[place] {
                return placeView
            }
            
            let placeView = Place.View(name: place.name)
            placeView.center = place.location.pointInRect(view.bounds, topLeft: topLeft, bottomRight: bottomRight)
            view.addSubview(placeView)
            view.bringSubviewToFront(placeView)
            placeViews[place] = placeView
            return placeView
        }
        
        /// The line view is used only by the custom playground quick look, so we nest it within the `customPlaygroundQuickLook` method implementation.
        class LineView: UIView {
            
            enum Corner {
                case TopLeft
                case TopRight
                case BottomLeft
                case BottomRight
            }
            
            var lineStart: Corner {
                didSet {
                    setNeedsDisplay()
                }
            }
            
            var lineEnd: Corner {
                didSet {
                    setNeedsDisplay()
                }
            }
            
            var lineColor: UIColor = UIColor.blackColor() {
                didSet {
                    setNeedsDisplay()
                }
            }
            
            var lineWidth: CGFloat = 1.0 {
                didSet {
                    setNeedsDisplay()
                }
            }
            
            init(frame: CGRect, lineStart: Corner, lineEnd: Corner) {
                self.lineStart = lineStart
                self.lineEnd = lineEnd
                super.init(frame: frame)
            }
            
            required init(coder: NSCoder) {
                fatalError("init(coder:) not implemented")
            }
            
            private func CGPointForPoint(point: Corner) -> CGPoint {
                switch point {
                case .TopLeft:
                    return CGPoint()
                case .TopRight:
                    return CGPoint(x: bounds.width, y: 0)
                case .BottomLeft:
                    return CGPoint(x: 0, y: bounds.height)
                case .BottomRight:
                    return CGPoint(x: bounds.width, y: bounds.height)
                }
            }
            
            override func drawRect(_: CGRect) {
                backgroundColor?.set()
                UIRectFill(bounds)
                
                let path = UIBezierPath()
                
                path.moveToPoint(CGPointForPoint(lineStart))
                path.addLineToPoint(CGPointForPoint(lineEnd))
                
                lineColor.set()
                
                path.lineWidth = lineWidth
                
                path.stroke()
            }
            
        }
        
        
        /// Iterate over our Places
        for (origin, destinations) in placesAndTravelTimes {
            
            let originView = viewForPlace(origin)
            
            for (destination, _) in destinations {
                let destinationView = viewForPlace(destination)
                
                let lineX: CGFloat
                let lineWidth: CGFloat
                let startIsLeft: Bool
                
                switch (originView.frame.midX, destinationView.frame.midX) {
                case let (originX, destinationX) where originX <= destinationX:
                    lineX = originX
                    lineWidth = destinationX - originX
                    startIsLeft = true
                case let (originX, destinationX) where destinationX < originX:
                    lineX = destinationX
                    lineWidth = originX - destinationX
                    startIsLeft = false
                default:
                    fatalError("All cases should be handled above!")
                }
                
                let lineY: CGFloat
                let lineHeight: CGFloat
                let startIsTop: Bool
                
                switch (originView.frame.midY, destinationView.frame.midY) {
                case let (originY, destinationY) where originY <= destinationY:
                    lineY = originY
                    lineHeight = destinationY - originY
                    startIsTop = true
                case let (originY, destinationY) where destinationY < originY:
                    lineY = destinationY
                    lineHeight = originY - destinationY
                    startIsTop = false
                default:
                    fatalError("All cases should be handled above!")
                }
                
                let lineStart: LineView.Corner
                let lineEnd: LineView.Corner
                
                switch (startIsLeft, startIsTop) {
                case (true, true):
                    lineStart = .TopLeft
                    lineEnd = .BottomRight
                case (false, true):
                    lineStart = .TopRight
                    lineEnd = .BottomLeft
                case (true, false):
                    lineStart = .BottomLeft
                    lineEnd = .TopRight
                case (false, false):
                    lineStart = .BottomRight
                    lineEnd = .TopLeft
                }
                
                let lineView = LineView(frame: CGRect(x: lineX, y: lineY - 10, width: lineWidth, height: lineHeight), lineStart: lineStart, lineEnd: lineEnd)
                lineView.backgroundColor = .clearColor()
                lineView.lineColor = .lightGrayColor()
                lineView.lineWidth = 3.0
                view.addSubview(lineView)
                view.sendSubviewToBack(lineView)
            }
            
        }
        
        /// Return a PlaygroundQuickLook reflecting our view
        return PlaygroundQuickLook(reflecting: view)
    }
    
}
