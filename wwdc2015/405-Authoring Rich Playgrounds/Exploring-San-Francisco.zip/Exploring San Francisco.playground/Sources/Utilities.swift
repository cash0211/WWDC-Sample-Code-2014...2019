import UIKit
import CoreLocation

/// Extension on CLLocationCoordinate2D to convert from location to CGPoint in rect
extension CLLocationCoordinate2D {

    /// Converts a coordinate to a position within the supplied rect, given a bounding top-left and bottom-right coordinate
    public func pointInRect(rect: CGRect, topLeft: CLLocationCoordinate2D, bottomRight: CLLocationCoordinate2D) -> CGPoint {

        /// Find the minimum latitude
        let minLat = min(topLeft.latitude, bottomRight.latitude)
        /// Find the maximum latitude
        let maxLat = max(topLeft.latitude, bottomRight.latitude)
        /// Find the minimum longitude
        let minLon = min(topLeft.longitude, bottomRight.longitude)
        /// Find the maximum longitude
        let maxLon = max(topLeft.longitude, bottomRight.longitude)

        /// Calculate the horizontal position
        let x = CGRectGetWidth(rect) * CGFloat((longitude - minLon) / (maxLon - minLon))
        /// Calculate the vertical position
        let y = CGRectGetHeight(rect) * CGFloat((maxLat - latitude) / (maxLat - minLat))

        return CGPoint(x: x, y: y)
    }

}

extension CLLocationCoordinate2D: Hashable {
    public var hashValue: Int {
        return latitude.hashValue ^ longitude.hashValue
    }
}

public func ==(lhs: CLLocationCoordinate2D, rhs: CLLocationCoordinate2D) -> Bool {
    return lhs.latitude == rhs.latitude &&
        lhs.longitude == rhs.longitude
}

extension Array {
    /// Returns the element at the given `index` and a new array with that element removed.
    private func arrayByRemovingElementAtIndex(index: Int) -> (Element, [Element]) {
        var newArray = self
        let removedElement = newArray.removeAtIndex(index)
        return (removedElement, newArray)
    }

    /// Returns an array of arrays, where each array in the array is one permutation of the elements in the receiver.
    public var permutations: [[Element]] {
        switch self.count {
        case 0:
            return []
        case 1:
            return [self]
        default:
            precondition(self.count > 1)
            var permutations: [[Element]] = []
            for idx in 0..<self.count {
                let (currentElement, remainingElements) = self.arrayByRemovingElementAtIndex(idx)

                permutations += remainingElements.permutations.map { [currentElement] + $0 }
            }
            return permutations
        }
    }
}

extension Set {
    public var permutations: [[Element]] {
        return Array(self).permutations
    }
}
