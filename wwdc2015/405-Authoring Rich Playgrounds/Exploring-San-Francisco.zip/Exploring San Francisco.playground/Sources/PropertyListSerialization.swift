import Foundation

// MARK: PropertyListValue enum

/// PropertyListValue is an enum with cases for each of the different property list types:
///
///   - Arrays of property list values
///   - Dictionaries mapping strings to property list values
///   - Strings
///   - Data
///   - Dates
///   - Integers
///   - Floating point numbers
///   - Boolean values
public enum PropertyListValue {
    case Array([PropertyListValue])
    case Dictionary([Swift.String: PropertyListValue])
    case String(Swift.String)
    case Data(NSData)
    case Date(NSDate)
    case Integer(Int)
    case FloatingPoint(Double)
    case Boolean(Bool)
}

/// An extension which makes using PropertyListValue with Cocoa easier.
public extension PropertyListValue {
    /// Converts a property list object into a PropertyListValue for interoperability with Cocoa.
    ///
    /// - returns: A valid PropertyListValue, or nil if the given object was not actually a property list object.
    public init?(propertyListObject: AnyObject) {
        if let string = propertyListObject as? Swift.String {
            self = .String(string)
        }
        else if let dictionary = propertyListObject as? [Swift.String: AnyObject] {
            func constructDictionaryElement(key: Swift.String, propertyListObject: AnyObject) -> (Swift.String, PropertyListValue)? {
                if let propertyListValue = PropertyListValue(propertyListObject: propertyListObject) {
                    return (key, propertyListValue)
                }
                else {
                    return nil
                }
            }
            
            if let dictionary = dictionary.failable_map(constructDictionaryElement) {
                self = .Dictionary(dictionary)
            }
            else {
                return nil
            }
        }
        else if let array = propertyListObject as? [AnyObject] {
            func constructArrayElement(propertyListObject: AnyObject) -> PropertyListValue? {
                if let propertyListValue = PropertyListValue(propertyListObject: propertyListObject) {
                    return propertyListValue
                }
                else {
                    return nil
                }
            }
            
            if let array = array.failable_map(constructArrayElement) {
                self = .Array(array)
            }
            else {
                return nil
            }
        }
        else if let number = propertyListObject as? NSNumber {
            if number.objCType == nil {
                return nil
            }
            
            if let typeEncoding = Swift.String.fromCString(number.objCType) {
                switch typeEncoding {
                case "c", "C", "B":
                    self = .Boolean(number.boolValue)
                case "i", "s", "l", "q", "I", "S", "L", "Q":
                    self = .Integer(number.integerValue)
                case "f", "d":
                    self = .FloatingPoint(number.doubleValue)
                default:
                    // Bad type encoding for a plist number, return nil
                    return nil
                }
            }
            else {
                // Unable to get type encoding of number, so fail.
                return nil
            }
        }
        else if let date = propertyListObject as? NSDate {
            self = .Date(date)
        }
        else if let data = propertyListObject as? NSData {
            self = .Data(data)
        }
        else {
            return nil
        }
    }
    
    /// Returns the receiver as a property list object for interoperability with Cocoa.
    public var propertyListObject: AnyObject {
        switch self {
        case .Array(let array):
            return array.map { $0.propertyListObject }
        case .Dictionary(let dict):
            var objectDictionary: [Swift.String: AnyObject] = [:]
            for (key, value) in dict {
                objectDictionary[key] = value.propertyListObject
            }
            return objectDictionary
        case .String(let string):
            return string
        case .Data(let data):
            return data
        case .Date(let date):
            return date
        case .Integer(let integer):
            return integer
        case .FloatingPoint(let floatingPoint):
            return floatingPoint
        case .Boolean(let boolean):
            return boolean
        }
    }
}

// MARK: - PropertyListSerializable protocol

/// A protocol with an initializer and a property which can be used to serialize to and deserialize from a property list using the PropertyListValue enum.
public protocol PropertyListSerializable {
    /// Initializes with the contents of `propertyListValue`, or throws an error if the passed-in PropertyListValue  is not usable.
    init(propertyListValue: PropertyListValue) throws
    
    /// Returns a PropertyListValue representing the current contents of the receiver.
    var propertyListValue: PropertyListValue { get }
}

/// An extension on PropertyListSerializable which makes common property list tasks easier for types which conform to PropertyListSerializable.
public extension PropertyListSerializable {
    /// Initializes with the contents of `propertyListObject`, throwing an error if the passed-in property list object is not usable.
    ///
    /// - note: This initializer will currently crash if `propertyListObject` is not, in fact, a property list object.
    init(propertyListObject: AnyObject) throws {
        let plistValue = PropertyListValue(propertyListObject: propertyListObject)!
        try self.init(propertyListValue: plistValue)
    }
    
    /// Initializes with the contents of `propertyListData`, throwing an error if the passed-in property list data is not usable.
    init(propertyListData: NSData) throws {
        let plistObject = try NSPropertyListSerialization.propertyListWithData(propertyListData, options: .Immutable, format: nil)
        try self.init(propertyListObject: plistObject)
    }
    
    /// Initializes with the contents of the property list file at the given path, throwing an error if the passed-in path or the property list file at the passed-in path is not usable.
    init(contentsOfPropertyListFile path: String) throws {
        let plistData = try NSData(contentsOfFile: path, options: NSDataReadingOptions())
        try self.init(propertyListData: plistData)
    }
    
    /// Initializes with the contents of the property list file at the given URL, throwing an error if the passed-in URL or the property list file at the passed-in URL is not usable.
    init(contentsOfPropertyListAtURL url: NSURL) throws {
        let plistData = try NSData(contentsOfURL: url, options: NSDataReadingOptions())
        try self.init(propertyListData: plistData)
    }
    
    /// Returns a property list object representing the current contents of the receiver.
    final var propertyListObject: AnyObject {
        return propertyListValue.propertyListObject
    }
    
    /// Returns an NSData instance containing a property list in the requested format representing the current contents of the receiver, throwing an error if such data could not be generated.
    final func propertyListDataWithFormat(format: NSPropertyListFormat, options: NSPropertyListWriteOptions) throws -> NSData {
        return try NSPropertyListSerialization.dataWithPropertyList(propertyListObject, format: format, options: options)
    }
    
    /// Writes a property list file with the current contents of the receiver to the given path in the requested format, throwing an error if the operation could not be completed.
    final func writePropertyListToFile(path: String, format: NSPropertyListFormat, options: NSPropertyListWriteOptions) throws {
        let plistData = try propertyListDataWithFormat(format, options: options)
        try plistData.writeToFile(path, options: .DataWritingAtomic)
    }
    
    /// Writes a property list file with the current contents of the receiver to the given URL in the requested format, throwing an error if the operation could not be completed.
    final func writePropertyListToURL(url: NSURL, format: NSPropertyListFormat, options: NSPropertyListWriteOptions) throws {
        let plistData = try propertyListDataWithFormat(format, options: options)
        try plistData.writeToURL(url, options: .DataWritingAtomic)
    }
}

private extension Dictionary {
    func failable_map<T,U>(f: (Element) -> (T, U)?) -> Dictionary<T,U>? {
        var dict = [T: U](minimumCapacity: self.count)
        for element in self {
            if let newElement = f(element) {
                dict[newElement.0] = newElement.1
            }
            else {
                return nil
            }
        }
        return dict
    }
}

private extension Array {
    func failable_map<T>(f: (Element) -> T?) -> Array<T>? {
        var array = [T]()
        array.reserveCapacity(self.count)
        for element in self {
            if let newElement = f(element) {
                array.append(newElement)
            }
            else {
                return nil
            }
        }
        return array
    }
}

// MARK: - Place and City PropertyListSerializable conformances

import CoreLocation

extension Place: PropertyListSerializable {
    /// Represents possible deseriailization errors when trying to create a Place from a PropertyListValue.
    public enum DeserializationError: ErrorType {
        case NotADictionary
        case InvalidValue(String)
    }
    
    public init(propertyListValue: PropertyListValue) throws {
        guard case let .Dictionary(dict) = propertyListValue else {
            throw DeserializationError.NotADictionary
        }
        
        guard case let .String(name)? = dict["Name"] else {
            throw DeserializationError.InvalidValue("Name is missing or not a string")
        }
        
        guard case let .FloatingPoint(latitude)? = dict["Latitude"] else {
            throw DeserializationError.InvalidValue("Latitude is missing or not a floating point value")
        }
        
        guard case let .FloatingPoint(longitude)? = dict["Longitude"] else {
            throw DeserializationError.InvalidValue("Longitude is missing or not a floating point value")
        }
        
        self.name = name
        self.location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    public var propertyListValue: PropertyListValue {
        return .Dictionary([
            "Name": .String(self.name),
            "Latitude": .FloatingPoint(self.location.latitude),
            "Longitude": .FloatingPoint(self.location.longitude),
        ])
    }
}

extension City: PropertyListSerializable {
    /// Represents possible deserialization errors when trying to create a City from a PropertyListValue.
    public enum DeserializationError: ErrorType {
        case NotADictionary
        case InvalidValue(String)
    }
    
    public init(propertyListValue: PropertyListValue) throws {
        guard case let .Dictionary(dict) = propertyListValue else {
            throw DeserializationError.NotADictionary
        }
        
        guard case let .Array(placePlistValues)? = dict["Places"] else {
            throw DeserializationError.InvalidValue("Places array is missing or not an array")
        }
        
        var namesToPlaces: [String: Place] = [:]
        
        var placesAndTravelTimes: [Place: [Place: Double]] = [:]
        
        for placePlistValue in placePlistValues {
            do {
                let place = try Place(propertyListValue: placePlistValue)
                namesToPlaces[place.name] = place
                placesAndTravelTimes[place] = [:]
            }
                catch let underlyingError {
                    throw DeserializationError.InvalidValue("Failed to load Place: \(underlyingError)")
            }
        }
        
        guard case let .Array(travelTimes)? = dict["Travel Times"] else {
            throw DeserializationError.InvalidValue("Travel times array is missing or not an array")
        }
        
        var travelTimesAdded = 0
        for case let .Dictionary(travelTimeDict) in travelTimes {
            guard case let .String(originName)? = travelTimeDict["Origin"] else {
                throw DeserializationError.InvalidValue("Origin name is missing from travel time dictionary or it is not a string")
            }
            
            guard case let .String(destinationName)? = travelTimeDict["Destination"] else {
                throw DeserializationError.InvalidValue("Destination name is missing from travel time dictionary or it is not a string")
            }
            
            guard case let .FloatingPoint(travelTime)? = travelTimeDict["Travel Time"] else {
                throw DeserializationError.InvalidValue("Travel time is missing from travel time dictionary of it is not a floating point value")
            }
            
            guard let origin = namesToPlaces[originName] else {
                throw DeserializationError.InvalidValue("Travel time dictionary specifies an origin of '\(originName)', but that place is not present in this city")
            }
            
            guard let destination = namesToPlaces[destinationName] else {
                throw DeserializationError.InvalidValue("Travel time dictionary specifies a destination of '\(destinationName)', but that place is not present in this city")
            }
            
            if placesAndTravelTimes[origin]![destination] != nil || placesAndTravelTimes[destination]![origin] != nil {
                throw DeserializationError.InvalidValue("Duplicate travel time dictionary for '\(originName)' and '\(destinationName)'")
            }
            
            placesAndTravelTimes[origin]![destination] = travelTime
            
            travelTimesAdded++
        }
        
        if travelTimesAdded < travelTimes.count {
            throw DeserializationError.InvalidValue("\(travelTimes.count - travelTimesAdded) travel time(s) were not dictionaries")
        }
        
        self.placesAndTravelTimes = placesAndTravelTimes
    }
    
    public var propertyListValue: PropertyListValue {
        return .Dictionary([
            "Places": .Array(placesAndTravelTimes.keys.map { $0.propertyListValue }),
            "Travel Times": .Array(placesAndTravelTimes.flatMap({ placeAndTravelTimes -> [PropertyListValue] in
                let origin = placeAndTravelTimes.0
                let travelTimes = placeAndTravelTimes.1
                return travelTimes.map { (destination, travelTime) -> PropertyListValue in
                    return .Dictionary([
                        "Origin": .String(origin.name),
                        "Destination": .String(destination.name),
                        "Travel Time": .FloatingPoint(travelTime),
                        ])
                }
            }))
        ])
    }
}
