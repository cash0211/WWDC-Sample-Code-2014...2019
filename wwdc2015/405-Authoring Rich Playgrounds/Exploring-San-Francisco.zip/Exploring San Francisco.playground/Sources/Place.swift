import UIKit
import CoreLocation

/// Declare Place struct
public struct Place: Hashable, CustomStringConvertible {
    
    /// The name of the point of interest
    public var name: String
    
    /// The location of the point of interest (in lat/lon)
    public var location: CLLocationCoordinate2D
    
    public init(name: String, location: CLLocationCoordinate2D) {
        self.name = name
        self.location = location
    }
    
    /// CustomStringConvertible conformance
    public var description: String {
        return "\(name)"
    }
    
    // MARK: - Hashable conformance
    
    public var hashValue: Int {
        return name.hashValue ^ location.hashValue
    }
    
}

public func ==(lhs: Place, rhs: Place) -> Bool {
    return lhs.name == rhs.name &&
        lhs.location == rhs.location
}

/// Place extension to implement CustomPlaygroundQuickLookable
extension Place: CustomPlaygroundQuickLookable {
    
    /// Declare a UIView subclass to represent our Point of Interest
    class View: UIView {
        
        /// The name of the Place shown by this view.
        let name: String
        
        /// Provide a UIView to represent our location dot
        lazy var locationView: UIView = {
            let image = UIImage(named: self.name)!
            let view = UIImageView(image: image)
            view.contentMode = .ScaleAspectFill
            view.clipsToBounds = true
            return view
            }()
        
        /// Provide a UILabel to show our name
        lazy var nameLabel: UILabel = {
            let label = UILabel()
            label.text = self.name
            label.font = UIFont.boldSystemFontOfSize(18.0)
            label.textAlignment = .Center
            return label
            }()
        
        /// Initializers
        init(name: String) {
            self.name = name
            super.init(frame: CGRect(x: 0, y: 0, width: 250, height: 100))
            addSubview(locationView)
            addSubview(nameLabel)
        }
        
        required init(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        /// Layout our subviews
        override func layoutSubviews() {
            locationView.frame = CGRect(x: CGRectGetMidX(bounds) - 25.0, y: 15, width: 50.0, height: 50.0)
            nameLabel.frame = CGRect(x: 0, y: CGRectGetHeight(bounds) - 35, width: CGRectGetWidth(bounds), height: 35)
        }
        
    }
    
    /// Implement customPlaygroundQuickLook() to return our new PointOfInterestView
    public func customPlaygroundQuickLook() -> PlaygroundQuickLook {
        
        /// Return a PlaygroundQuickLook reflecting our View
        return PlaygroundQuickLook(reflecting: View(name: name))
    }
    
}
