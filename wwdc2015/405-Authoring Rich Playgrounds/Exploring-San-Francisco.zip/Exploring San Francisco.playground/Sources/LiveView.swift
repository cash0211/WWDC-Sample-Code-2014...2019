import UIKit
import MapKit

extension Place {
    
    private func locationInCityView(cityView: CityView) -> CGPoint {
        
        let longitudeMin = cityView.region.center.longitude - cityView.region.span.longitudeDelta / 2
        let longitudeMax = cityView.region.center.longitude + cityView.region.span.longitudeDelta / 2
        let latitudeMin = cityView.region.center.latitude - cityView.region.span.latitudeDelta / 2
        let latitudeMax = cityView.region.center.latitude + cityView.region.span.latitudeDelta / 2
        
        let longitudeOffset = CGFloat((location.longitude - longitudeMin) / (longitudeMax - longitudeMin))
        let latitudeOffset = 1 - CGFloat((location.latitude - latitudeMin) / (latitudeMax - latitudeMin))
        
        return CGPoint(x: floor(longitudeOffset * cityView.bounds.size.width), y: floor(latitudeOffset * cityView.bounds.size.height))
    }
    
}

private final class CityView: UIView {
    
    let overlayImage: UIImage
    let region: MKCoordinateRegion
    var highlightedPaths: [[Place]] = []
    var bestPathIndex: Int? = nil
    
    init(frame: CGRect, region: MKCoordinateRegion) {
        self.region = region
        self.overlayImage = UIImage(named: "San Francisco")!
        super.init(frame: frame)
        backgroundColor = UIColor(red: 0.6219, green: 0.8504, blue: 0.9505, alpha: 1.0)
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func markBestPath() {
        bestPathIndex = highlightedPaths.count - 1
        setNeedsDisplay()
    }
    
    private override func drawRect(rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        CGContextSaveGState(context)
        CGContextSetLineWidth(context, 5)
        
        overlayImage.drawInRect(bounds)
        
        for i in 0..<highlightedPaths.count {
            let path = highlightedPaths[i]
            
            if i == highlightedPaths.count - 1 {
                drawPath(path, inContext: context!, withColor: UIColor(red: 0.2235, green: 0.5843, blue: 0.9765, alpha: 1.0))
            } else {
                drawPath(path, inContext: context!, withColor: UIColor(red: 0.9056, green: 0.8989, blue: 0.8894, alpha: 1.0))
            }
        }
        
        if let bestPathIndex = bestPathIndex {
            let path = highlightedPaths[bestPathIndex]
            drawPath(path, inContext: context!, withColor: UIColor(red: 0.4588, green: 0.7176, blue: 0.5176, alpha: 1.0))
        }
        
        CGContextRestoreGState(context)
        
        UIColor.blackColor().set()
        UIRectFill(CGRect(x: 0, y: 0, width: bounds.size.width, height: 1))
        UIRectFill(CGRect(x: 0, y: 0, width: 1, height: bounds.size.height))
        UIRectFill(CGRect(x: 0, y: bounds.size.height - 1, width: bounds.size.width, height: 1))
        UIRectFill(CGRect(x: bounds.size.width - 1, y: 0, width: 1, height: bounds.size.height))
    }
    
    private func drawPath(path: [Place], inContext context: CGContextRef, withColor color: UIColor) {
        assert(path.count >= 2)
        
        CGContextBeginPath(context)
        var origin = path[0].locationInCityView(self)
        var destination = path[1].locationInCityView(self)
        
        CGContextMoveToPoint(context, origin.x, origin.y)
        CGContextAddLineToPoint(context, destination.x, destination.y)
        
        for i in 2..<path.count {
            origin = destination
            destination = path[i].locationInCityView(self)
            CGContextAddLineToPoint(context, destination.x, destination.y)
        }
        
        CGContextSetStrokeColorWithColor(context, color.CGColor)
        CGContextStrokePath(context)
    }
    
}

private final class PlaceAnnotationView: UIView {
    
    let place: Place
    
    init(place: Place) {
        self.place = place
        super.init(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        
        if let image = UIImage(named: place.name) {
            let imageView = UIImageView(image: image)
            imageView.frame = bounds
            addSubview(imageView)
        }
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func locationInCityView(cityView: CityView) -> CGPoint {
        var origin = place.locationInCityView(cityView)
        origin.x -= frame.size.width / 2
        origin.y -= frame.size.height / 2
        return origin
    }
    
    private override func willMoveToSuperview(newSuperview: UIView?) {
        super.willMoveToSuperview(newSuperview)
        if let cityView = newSuperview as? CityView {
            frame = CGRect(origin: locationInCityView(cityView), size: frame.size)
        }
    }
    
}

public class CityViewController: UIViewController {
    
    public var city: City? = nil {
        didSet {
            if isViewLoaded() {
                reloadAnnotations()
            }
        }
    }
    
    private var annotationViews: [PlaceAnnotationView] = []
    
    public init(city: City) {
        super.init(nibName: nil, bundle: nil)
        self.city = city
    }

    required public init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var cityView: CityView {
        return view as! CityView
    }
    
    override public func loadView() {
        // we hard code a region that corresponds to the San Francisco peninsula
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.72435387305068, longitude: -122.4268), span: MKCoordinateSpan(latitudeDelta: 0.2266213019128998, longitudeDelta: 0.2034242548975556))
        let v = CityView(frame: CGRect(x: 0, y: 0, width: 750, height: 1000), region: region)
        view = v
        reloadAnnotations()
    }
    
    private func reloadAnnotations() {
        for view in annotationViews {
            view.removeFromSuperview()
        }
        
        if let places = city?.places {
            for place in places {
                let annotation = PlaceAnnotationView(place: place)
                cityView.addSubview(annotation)
                annotationViews.append(annotation)
            }
        }
    }
    
    public func highlightPath(path: [Place]) {
        if NSThread.isMainThread() {
            cityView.highlightedPaths.append(path)
            cityView.setNeedsDisplay()
        } else {
            dispatch_sync(dispatch_get_main_queue()) {
                self.cityView.highlightedPaths.append(path)
                self.cityView.setNeedsDisplay()
            }
        }
    }
    
    public func markBestPath() {
        if NSThread.isMainThread() {
            cityView.markBestPath()
        } else {
            dispatch_sync(dispatch_get_main_queue()) {
                self.cityView.markBestPath()
            }
        }
    }
    
    public func visualizePathIteration(paths: City.PathsView, iterator: ([Place]) -> Void) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            for path in paths {
                dispatch_sync(dispatch_get_main_queue()) {
                    self.highlightPath(path)
                    iterator(path)
                }
            }
        }
    }
    
    public func visualizeLoop(callback: () -> Void) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            callback()
        }
    }
    
}
