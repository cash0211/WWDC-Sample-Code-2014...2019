/*:
# Nearest Neighbor Approximation

Being precise is all well and good, but what about when the *absolute* shortest path isn't really necessary? What about when an approximation will do?

We can get a path that pretty nearly resembles the shortest path in much less time using a *nearest neighbor* approximation.
*/

import UIKit
import XCPlayground

//: First, load a City representing San Francisco from a property list.

let sanFrancisco = try! City(contentsOfPropertyListAtURL: NSBundle.mainBundle().URLForResource("San Francisco", withExtension: "plist")!)

//: We also want to show a visualization of our path finding.

let viewController = CityViewController(city: sanFrancisco)
XCPShowView("San Francisco", view: viewController.view)

//: We start by choosing our origin and destination, and removing them from the set of all possible locations.

var start = sanFrancisco["Moscone Center"]!
let end = sanFrancisco["San Francisco International Airport"]!
var unvisited = sanFrancisco.places.subtract([start, end])
var bestPath: [Place] = [start]

//: Next, while some unvisited locations still exist, we start from our known starting point (or, the most recent location in our path) and find the next closest place to visit.

viewController.visualizeLoop {
    while unvisited.count > 0 {
        var nearestTime = Double.infinity
        var nearest: Place!
        for neighbor in unvisited {
            viewController.highlightPath(bestPath + [neighbor])
            let distance = sanFrancisco.travelTimeBetweenPlaces(start, neighbor)!
            if distance < nearestTime {
                nearestTime = distance
                nearest = neighbor
            }
        }
        
        if let next = unvisited.remove(nearest) {
            start = next
            bestPath.append(next)
            
            viewController.highlightPath(bestPath)
            viewController.markBestPath()
        }
    }
    
    bestPath.append(end)
    
    viewController.highlightPath(bestPath)
    viewController.markBestPath()
    
//: The resulting path, while not always optimal, will [on average only be 25% worse](http://en.wikipedia.org/wiki/Travelling_salesman_problem#Constructive_heuristics) than the optimal path.
    
    sanFrancisco.travelTimeForPath(bestPath)
    
    bestPath
    
    bestPath.description
    
//: Since, in our case, this only represents a 21-minute improvement over [the optimal route we determined earlier](Getting%20Around), the extra work required may not be worth the effort!
}
