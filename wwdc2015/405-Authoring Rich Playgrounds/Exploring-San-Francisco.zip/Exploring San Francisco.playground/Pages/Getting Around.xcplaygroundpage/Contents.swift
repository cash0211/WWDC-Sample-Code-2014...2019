/*:
# Exploring San Francisco

> **Important:**
> This is a preliminary document for an API or technology in development. Apple is supplying this information to help you plan for the adoption of the technologies and programming interfaces described herein for use on Apple-branded products. This information is subject to change, and software implemented according to this document should be tested with final operating system software and final documentation. Newer versions of this document may be provided with future betas of the API or technology. [License](License)

San Francisco is a rich and vibrant city full of attractions and things to do! But what if you don’t have much time? We can use a playground to help us find the *most efficient* way to see the sights.
*/

import UIKit
import XCPlayground

//: Load San Francisco as a City from a plist embedded in this playground.
let sanFrancisco = try! City(contentsOfPropertyListAtURL: NSBundle.mainBundle().URLForResource("San Francisco", withExtension: "plist")!)

let viewController = CityViewController(city: sanFrancisco)
XCPShowView("San Francisco", view: viewController.view)

//: Next, we compute all possible paths through the city beginning at **Moscone Center** and ending at the **San Francisco International Airport**.
let allPaths = sanFrancisco.allPathsThroughCity(startingAtPlace: sanFrancisco["Moscone Center"], endingAtPlace: sanFrancisco["San Francisco International Airport"])

var bestTravelTime = Double.infinity
var bestPath: [Place] = []

/*:
Finally, we evaluate which of the paths will give us the best results by:

* Computing the travel time for the path using data gathered from the iOS 9 Transit directions in Maps
* Determining if that travel time is shorter than the best travel time found so far
* Keeping track of the optimal path as we go
*/
viewController.visualizePathIteration(allPaths) { path in
    let travelTime = sanFrancisco.travelTimeForPath(path)
    
    if travelTime < bestTravelTime {
        bestTravelTime = travelTime
        bestPath = path
        viewController.markBestPath()
    }
    
    bestTravelTime
}





