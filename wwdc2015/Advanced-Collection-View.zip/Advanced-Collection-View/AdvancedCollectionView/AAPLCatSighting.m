/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A plain old data object for a cat sighting.
 */

#import "AAPLCatSighting.h"

@implementation AAPLCatSighting

@end
