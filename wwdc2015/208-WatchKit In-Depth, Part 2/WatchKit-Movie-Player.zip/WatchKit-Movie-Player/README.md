# WatchKitMoviePlayer: Using WKInterfaceMovie for Video Playback

This sample demonstrates how to use WatchKit elements to perform local video playback. Refer to this sample if you want to see how to use WKInterfaceMovie to provide UI and playback videos on watchOS 2.0.

## Requirements

### Build

Xcode 7.0, iOS 9.0 SDK, watchOS 2.0 SDK

### Runtime

iOS 9.0, watchOS 2.0

Copyright (C) 2015 Apple Inc. All rights reserved.
