/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	'AAPLMediaPlaybackController' controller object used for eacth table row in a WKInterfaceTable.
 */

#import "AAPLMediaPlaybackController.h"

@implementation AAPLMediaPlaybackController
@end
