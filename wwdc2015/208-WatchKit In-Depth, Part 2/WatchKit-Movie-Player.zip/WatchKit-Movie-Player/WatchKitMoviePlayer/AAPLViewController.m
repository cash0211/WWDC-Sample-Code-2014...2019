/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	'AAPLViewController' the view controller running on the iOS device.
 */

#import "AAPLViewController.h"

@implementation AAPLViewController
@end
