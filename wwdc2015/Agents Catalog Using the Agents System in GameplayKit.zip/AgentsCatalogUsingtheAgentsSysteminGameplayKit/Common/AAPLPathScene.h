/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	Non-interactive demonstration of path-following behavior.
 */

#import "AAPLGameScene.h"

@interface AAPLPathScene : AAPLGameScene
@end
