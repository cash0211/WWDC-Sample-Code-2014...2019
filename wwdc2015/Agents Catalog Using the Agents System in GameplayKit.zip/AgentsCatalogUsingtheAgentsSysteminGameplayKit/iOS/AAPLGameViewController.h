/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	iOS view controller. Handles switching demo scenes based on UI controls.
 */

@import SpriteKit;

@interface AAPLGameViewController : UIViewController
@end
