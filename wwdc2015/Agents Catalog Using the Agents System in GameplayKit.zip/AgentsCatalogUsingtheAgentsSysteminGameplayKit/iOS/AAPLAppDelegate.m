/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	Empty iOS app delegate implementation.
 */

#import "AAPLAppDelegate.h"

@implementation AAPLAppDelegate
@end
