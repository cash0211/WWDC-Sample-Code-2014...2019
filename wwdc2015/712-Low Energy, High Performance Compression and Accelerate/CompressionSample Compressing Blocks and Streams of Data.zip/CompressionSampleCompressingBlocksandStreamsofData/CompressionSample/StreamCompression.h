/*
    Copyright (C) 2015 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    Provides code that performs stream compression.
*/

#ifndef StreamCompression_c
#define StreamCompression_c

#include <stdio.h>
#include "compression.h"

float doStreamCompression(FILE* fi, FILE* fo, compression_algorithm algorithm, compression_stream_operation operation);

#endif
