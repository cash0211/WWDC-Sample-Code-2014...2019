/*
    Copyright (C) 2015 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    Provides a user interface for exercising the compression code.
*/

@import Cocoa;

@interface AAPLViewController : NSViewController

@end
