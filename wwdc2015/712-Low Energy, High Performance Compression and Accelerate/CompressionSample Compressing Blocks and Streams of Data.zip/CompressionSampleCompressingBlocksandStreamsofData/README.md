# CompressionSample: Compressing Blocks and Streams of Data

This sample illustrates the use of functions from the Compression library, introduced in OS X v10.11, to compress either a block of data or streaming data, and then decompress the compressed data to reconstruct the original data.

## Requirements

### Build

Xcode 7.0, OS X 10.11 SDK

### Runtime

OS X 10.11

Copyright (C) 2015 Apple Inc. All rights reserved.
