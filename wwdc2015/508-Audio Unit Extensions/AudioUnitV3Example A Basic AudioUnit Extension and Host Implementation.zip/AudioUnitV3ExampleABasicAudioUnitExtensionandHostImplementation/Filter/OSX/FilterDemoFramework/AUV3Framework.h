//
//  AUV3Framework.h
//  AUV3Framework
//
//  Created by jamesmcc on 3/31/15.
//  Copyright © 2015 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for AUv3Modular.
FOUNDATION_EXPORT double AUv3ModularVersionNumber;

//! Project version string for AUv3Modular.
FOUNDATION_EXPORT const unsigned char AUv3ModularVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AUV3Framework/PublicHeader.h>

#import <AUV3Framework/AUV3Unit.h>

@class AUV3ViewController;

