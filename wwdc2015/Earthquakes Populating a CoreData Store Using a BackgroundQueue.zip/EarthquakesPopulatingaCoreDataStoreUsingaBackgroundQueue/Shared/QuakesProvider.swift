/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A class to fetch data from the remote server and save it to the Core Data store.
  When requested (by clicking the Fetch Quakes button), this class creates an asynchronous `NSURLSession` task
  to retrieve JSON data about earthquakes. Earthquake data are compared with any existing managed objects to
  determine whether there are new quakes. New managed objects are created to represent new data, and saved to
  the persistent store on a private queue.
 */

import CoreData

/**
 Error handling
 An error domain, and an error code enumeration.
*/
let quakesErrorDomain = "QuakesErrorDomain"

enum QuakeErrorCode: NSInteger {
    case networkUnavailable = 101
    case wrongDataFormat = 102
}

class QuakesProvider: NSObject {
    
    /**
     Delegate of the fetchedResultsController.
     Give consumers a chance to upate UI when the fetchedResultsController content is changed.
    */
    weak var fetchedResultsControllerDelegate: NSFetchedResultsControllerDelegate?

    /**
     Persistent container: use NSPersistentContainer to create the Core Data stack
    */
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "Earthquakes")
        
        /**
         fatalError() causes the application to generate a crash log and terminate.
         You should not use this function in a shipping application.
        */
        container.loadPersistentStores(completionHandler: { (_, error) in
            guard let error = error as NSError? else { return }
            fatalError("Unresolved error \(error), \(error.userInfo)")
        })
        
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        container.viewContext.undoManager = nil // We don't need undo so set it to nil.
        container.viewContext.shouldDeleteInaccessibleFaults = true
        
        /**
         Merge the changes from other contexts automatically.
         You can also choose to merge the changes by observing NSManagedObjectContextDidSave
         notification and calling mergeChanges(fromContextDidSave notification: Notification)
        */
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        return container
    }()
    
    /**
     NSFetchedResultsController is available on macOS since 10.12.
     Create a controller for "Quake" entity, sorting with "time" field, and perform fetch.
    */
    lazy var fetchedResultsController: NSFetchedResultsController<Quake> = {
        
        let fetchRequest = NSFetchRequest<Quake>(entityName:"Quake")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "time", ascending:false)]
        
        let controller = NSFetchedResultsController(fetchRequest: fetchRequest,
                                                    managedObjectContext: persistentContainer.viewContext,
                                                    sectionNameKeyPath: nil, cacheName: nil)
        controller.delegate = fetchedResultsControllerDelegate
        
        do {
            try controller.performFetch()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        
        return controller
    }()

    /**
     Fetch earthquakes from the remote server.
    
     Create an `NSURLSession` and then session task to contact the earthquake
     server and retrieve JSON data. Because this server is out of our control
     and does not offer a secure communication channel, we'll use the http
     version of the URL and add "earthquake.usgs.gov" to the "NSExceptionDomains"
     value in the apps's info.plist. When you commmunicate with your own
     servers, or when the services you use offer a secure communication
     option, you should always prefer to use HTTPS.
    */
    func fetchQuakes(completionHandler: @escaping (Error?) -> Void) {
        
        /**
         Use the http version URL and add the domain name to the "NSExceptionDomains" value in
         the NSAppTransportSecurity entry of info.plist because this server is out of our control
         and does not offer a https version.
        */
        let jsonURL = URL(string: "http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson")!
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: jsonURL) { data, _, error in
            
            // If we don't get data back, alert the user.
            guard let data = data else {
                let description = NSLocalizedString("Could not get data from the remote server", comment: "")
                let fetchError = NSError(domain: quakesErrorDomain, code: QuakeErrorCode.networkUnavailable.rawValue,
                                         userInfo: [NSLocalizedDescriptionKey: description, NSUnderlyingErrorKey: error as Any])
                completionHandler(fetchError)
                return
            }
            
            // If we get data but can't digest it, alert the user.
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: data, options: [])
                
                if let jsonDictionary = jsonObject as? [AnyHashable: Any] {
                    try self.importQuakes(from: jsonDictionary)
                }
            } catch {
                let description = NSLocalizedString("Could not digest fetched data", comment: "")
                let fetchError = NSError(domain: quakesErrorDomain, code: QuakeErrorCode.wrongDataFormat.rawValue,
                                         userInfo: [NSLocalizedDescriptionKey: description, NSUnderlyingErrorKey: error as Any])
                completionHandler(fetchError)
                return
            }
            
            completionHandler(nil)

        }
        task.resume() // If the task is created, start it by calling resume.
    }
    
    /**
     Private functions for saving JSON to the Core Data store.
     Import a json dictionary into the Core Data store.
    */
    private func importQuakes(from jsonDictionary: [AnyHashable: Any]) throws {

        /**
         Create a context on a private queue to:
         - Fetch existing quakes to compare with incoming data.
         - Create new quakes as required.
        */
        let taskContext = persistentContainer.newBackgroundContext()
        taskContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        taskContext.undoManager = nil // We don't need undo so set it to nil.
        
        /**
         Sort the dictionaries by code so they can be compared in parallel with
         existing quakes.
        */
        guard let quakeDictionaries = jsonDictionary["features"] as? [[String: AnyObject]] else {
            
            let description = NSLocalizedString("Features data doesn't have the right type!", comment: "")
            throw NSError(domain: quakesErrorDomain, code: QuakeErrorCode.wrongDataFormat.rawValue,
                          userInfo: [NSLocalizedDescriptionKey: description])
        }
        
        let sortedQuakeDictionaries = try quakeDictionaries.sorted { lhs, rhs in
            
            guard let lhsResult = lhs["properties"]?["code"] as? String, let rhsResult = rhs["properties"]?["code"] as? String else {
                
                let description = NSLocalizedString("Properties or code data doesn't have right type!", comment: "")
                throw NSError(domain: quakesErrorDomain, code: QuakeErrorCode.wrongDataFormat.rawValue,
                              userInfo: [NSLocalizedDescriptionKey: description])
            }
            return lhsResult < rhsResult
        }
        
        // To avoid a high memory footprint, process records in batches.
        let batchSize = 256
        let count = sortedQuakeDictionaries.count
        
        var numBatches = count / batchSize
        numBatches += count % batchSize > 0 ? 1 : 0
        
        for batchNumber in 0 ..< numBatches {
            let batchStart = batchNumber * batchSize
            let batchEnd = batchStart + min(batchSize, count - batchNumber * batchSize)
            let range = batchStart..<batchEnd
            
            let quakesBatch = Array(sortedQuakeDictionaries[range])
            
            // Stop importing if hitting an unsuccessful import.
            if !importOneBatch(quakesBatch, taskContext: taskContext) {
                return
            }
        }
    }
    
    /**
     Import one batch of quakes.
     NSManagedObjectContext.performAndWait doesn't rethrow so we catch throws
     within the closure and use a return value to indicate if the import is successfult.
     Note that we reset the context to clean up the cache and low the memory footprint.
    */
    private func importOneBatch(_ quakesBatch: [[String: AnyObject]], taskContext: NSManagedObjectContext) -> Bool {
        
        var success = false
        taskContext.performAndWait { // Wait doesn't block as taskContext is a background context
            
            /**
             Fetch the existing records with the same code, then remove them and create new records with the latest data
             to replace them.
            */
            let matchingQuakeRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Quake")
            
            let codesOrNil: [String?] = quakesBatch.map { dictionary in
                return dictionary["properties"]?["code"] as? String
            }
            guard let codes = codesOrNil as? [String] else {
                print("Error: Properties or code doesn't have the right type!")
                return
            }

            matchingQuakeRequest.predicate = NSPredicate(format: "code in %@", argumentArray: [codes])
            
            // Create batch delete request and set the result type to .resultTypeObjectIDs so that we can merge the changes
            let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: matchingQuakeRequest)
            batchDeleteRequest.resultType = .resultTypeObjectIDs
            
            // Execute the request to de batch delete and merge the changes to viewContext, which triggers the UI update
            do {
                let batchDeleteResult = try taskContext.execute(batchDeleteRequest) as? NSBatchDeleteResult
                
                if let deletedObjectIDs = batchDeleteResult?.result as? [NSManagedObjectID] {
                    NSManagedObjectContext.mergeChanges(fromRemoteContextSave: [NSDeletedObjectsKey: deletedObjectIDs],
                                                        into: [self.persistentContainer.viewContext])
                }
            } catch {
                print("Error: \(error)\nCould not batch delete existing records.")
                return
            }
            
            // Create new records.
            for quakeDictionary in quakesBatch {
                
                guard let quake = NSEntityDescription.insertNewObject(forEntityName: "Quake", into: taskContext) as? Quake else {
                    print("Error: Failed to create a new Quake object!")
                    return
                }
                
                /**
                 Set the attribute values the quake object.
                 If the data is not valid, delete the object and continue to process the next one.
                */
                do {
                    try quake.update(with: quakeDictionary)
                } catch {
                    print("Error: \(error)\nThe quake object will be deleted.")
                    taskContext.delete(quake)
                }
            }
            
            // Save all the changes just made and reset the taskContext to free the cache.
            if taskContext.hasChanges {
                do {
                    try taskContext.save()
                } catch {
                    print("Error: \(error)\nCould not save Core Data context.")
                    return
                }
                taskContext.reset() // Reset the context to clean up the cache and low the memory footprint.
            }
            success = true
        }
        return success
    }
}
