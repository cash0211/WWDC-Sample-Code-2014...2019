/*
Copyright (C) 2018 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Managed object class for the Quake entity.
*/

import CoreData

class Quake: NSManagedObject {

    @NSManaged var magnitude: Float
    @NSManaged var place: String
    @NSManaged var time: Date
    @NSManaged var longitude: Float
    @NSManaged var latitude: Float
    @NSManaged var depth: Float
    @NSManaged var detailURL: String
    @NSManaged var code: String
    
    /**
     A convenience method to update a quake object with a dictionary.
    */
    func update(with quakeDictionary: [String: AnyObject]) throws {
        
        /**
         Only update the quake if all the relevant properties can be accessed.
         Use NSNumber for numeric values, then convert the result to the right type.
        */
        guard let properties = quakeDictionary["properties"] as? [String: AnyObject],
            let newCode = properties["code"] as? String,
            let newMagnitude = properties["mag"] as? NSNumber,
            let newPlace = properties["place"] as? String,
            let newDetailURL = properties["detail"] as? String,
            let newTime = properties["time"] as? NSNumber,
            let geometry = quakeDictionary["geometry"] as? [String: AnyObject],
            let coordinates = geometry["coordinates"] as? [NSNumber] else {
                
                let description = NSLocalizedString("Could not interpret data from the earthquakes server.", comment: "")
                
                throw NSError(domain: quakesErrorDomain, code: QuakeErrorCode.wrongDataFormat.rawValue,
                              userInfo: [NSLocalizedDescriptionKey: description])
        }
        
        code = newCode
        magnitude = Float(truncating: newMagnitude)
        place = newPlace
        detailURL = newDetailURL
        
        time = Date(timeIntervalSince1970: Double(truncating: newTime) / 1000.0)

        longitude = Float(truncating: coordinates[0])
        latitude = Float(truncating: coordinates[1])
        depth = Float(truncating: coordinates[2])
    }
}
