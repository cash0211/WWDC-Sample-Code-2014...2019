/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A UITableViewCell subclass to display the information a quake.
 */

import UIKit

class QuakeCell: UITableViewCell {
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var magnitudeLabel: UILabel!
    @IBOutlet weak var magnitudeImage: UIImageView!

    /**
     Configure the cell with a quake instance
    */
    func configure(with quake: Quake) {
        
        locationLabel.text = quake.place
        dateLabel.text = QuakeCell.dateFormatter.string(from: quake.time)
        magnitudeLabel.text = String(format: "%.1f", quake.magnitude)
        magnitudeImage.image = image(for: quake.magnitude)
    }
    
    private static let dateFormatter: DateFormatter = {
        
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone.current
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        return formatter
    }()
    
    /**
     Private functions for saving JSON to the Core Data store.
    */
    private func image(for magnitude: Float) -> UIImage? {
        
        if magnitude >= 5.0 {
            return #imageLiteral(resourceName: "5.0")
        }
        if magnitude >= 4.0 {
            return #imageLiteral(resourceName: "4.0")
        }
        if magnitude >= 3.0 {
            return #imageLiteral(resourceName: "3.0")
        }
        if magnitude > 0.0 {
            return #imageLiteral(resourceName: "2.0")
        }
        return nil
    }
}
