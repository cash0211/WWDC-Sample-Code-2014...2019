/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A UIViewController subclass to manage a table view that displays a collection of quakes.
 */

import UIKit
import CoreData

class QuakesViewController: UITableViewController, NSFetchedResultsControllerDelegate {

    lazy var spinner: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        indicator.color = .gray
        indicator.hidesWhenStopped = true
        return indicator
    }()

    private lazy var dataProvider: QuakesProvider = {
        
        let provider = QuakesProvider()
        provider.fetchedResultsControllerDelegate = self
        return provider
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if spinner.superview == nil, let superView = tableView.superview {
            superView.addSubview(spinner)
            superView.bringSubview(toFront: spinner)
            spinner.center = CGPoint(x: superView.frame.size.width / 2, y: superView.frame.size.height / 2)
        }
    }
    
    @IBAction func fetchQuakes(_ sender: UIBarButtonItem) {
        
        navigationItem.rightBarButtonItem?.isEnabled = false
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        spinner.startAnimating()

        dataProvider.fetchQuakes(completionHandler: { error in
            DispatchQueue.main.async {
                
                self.navigationItem.rightBarButtonItem?.isEnabled = true
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                self.spinner.stopAnimating()

                guard let error = error else { return }
                
                let alert = UIAlertController(title: "Fetch quakes error!",
                                              message: error.localizedDescription,
                                              preferredStyle: .alert)

                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        })
    }
}

/**
 UITableViewDataSource and UITableViewDelegate
*/
extension QuakesViewController {
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "QuakeCell", for: indexPath) as? QuakeCell else {
            print("Error: tableView.dequeueReusableCell doesn'return a QuakeCell!")
            return QuakeCell()
        }
        guard let quake = dataProvider.fetchedResultsController.fetchedObjects?[indexPath.row] else { return cell }
        
        cell.configure(with: quake)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataProvider.fetchedResultsController.fetchedObjects?.count ?? 0
    }
}

/**
 NSFetchedResultsControllerDelegate, available since macOS 10.12+
*/
extension QuakesViewController {
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.reloadData()
    }
}
