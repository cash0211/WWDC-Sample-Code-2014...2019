/*
Copyright (C) 2018 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
An NSViewController subclass to manage a table view that displays a collection of quakes.
*/

import Cocoa
import CoreData

class QuakesViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate, NSFetchedResultsControllerDelegate {
    
    /**
     An enumeration to specify the names of earthquake properties that would
     be displayed in the table view.
    */
    private enum QuakeDisplayProperty: String {
        case place // = "place"
        case time // = "time"
        case magnitude // = "magnitude"
    }

    @IBOutlet weak var tableView: NSTableView!
    @IBOutlet weak var fetchQuakesButton: NSButton!
    @IBOutlet weak var progressIndicator: NSProgressIndicator!
    
    /**
     Lazily create the data provider object
    */
    private lazy var dataProvider: QuakesProvider = {
        
        let provider = QuakesProvider()
        provider.fetchedResultsControllerDelegate = self
        return provider
    }()
    
    /**
     Use dataProvider to fetch quakes from the remote server
    */
    @IBAction func fetchQuakes(_ sender: AnyObject) {
        
        // Ensure the button can't be pressed again before the fetch is complete.
        fetchQuakesButton.isEnabled = false
        progressIndicator.isHidden = false
        progressIndicator.startAnimation(nil)
        
        dataProvider.fetchQuakes(completionHandler: { error in
            DispatchQueue.main.async {
                
                self.fetchQuakesButton.isEnabled = true
                self.progressIndicator.isHidden = true
                self.progressIndicator.stopAnimation(nil)
                
                guard let error = error else { return }
                NSApp.presentError(error)
            }
        })
    }
}

/**
 NSTableViewDataSource and NSTableViewDelegate
*/
extension QuakesViewController {

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {

        let identifier = tableColumn!.identifier
        
        guard let cellView = tableView.makeView(withIdentifier: identifier, owner: self) as? NSTableCellView,
            let propertyEnum = QuakeDisplayProperty(rawValue: identifier.rawValue) else { return nil }
        
        if let quake = dataProvider.fetchedResultsController.fetchedObjects?[row] {
            
            switch propertyEnum {
            case .place:
                cellView.textField!.stringValue = quake.place
                
            case .time:
                cellView.textField!.objectValue = quake.time
                
            case .magnitude:
                cellView.textField!.objectValue = quake.magnitude
            }
        }
        return cellView
    }

    func numberOfRows(in tableView: NSTableView) -> Int {
        return dataProvider.fetchedResultsController.fetchedObjects?.count ?? 0
    }
}

/**
 NSFetchedResultsControllerDelegate, available on macOS 10.12+
*/
extension QuakesViewController {

    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.reloadData()
    }
}
