/*
	Copyright (C) 2015 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	'AAPLTimeRangView' is a simple view that draws a yellow highlight.
 */

#import <Cocoa/Cocoa.h>

@interface AAPLTimeRangeView : NSView

@end
