# SignalProcessing: Using Biquadratic Filter Functions

This sample illustrates the use of functions from the Accelerate/vDSP for filtering a stereo signal with cascading biquadratic IIR filters. The filter characteristics can be changed during the processing of the signal.

## Requirements

### Build

Xcode 7.0, iOS 9.0 SDK

### Runtime

iOS 9.0

Copyright (C) 2015 Apple Inc. All rights reserved.
