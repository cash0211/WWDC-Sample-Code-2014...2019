/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our view controller
*/

@import AppKit;
@import MetalKit;

#import "AAPLRenderer.h"

// Our view controller
@interface AAPLViewController : NSViewController

@end
