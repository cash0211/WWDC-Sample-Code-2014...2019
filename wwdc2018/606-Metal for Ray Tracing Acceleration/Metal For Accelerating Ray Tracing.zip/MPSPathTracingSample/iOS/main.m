/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Main Application Entrypoint
*/

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
                            
}
