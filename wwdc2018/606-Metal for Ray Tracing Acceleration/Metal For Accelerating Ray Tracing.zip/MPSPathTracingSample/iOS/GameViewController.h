/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our iOS view controller
*/

#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import "Renderer.h"

// Our iOS view controller
@interface GameViewController : UIViewController

@end
