/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our iOS Application Delegate
*/

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
                        

@end

