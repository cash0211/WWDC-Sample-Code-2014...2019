/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implements the app delegate for TrueDepth Streamer
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
