/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Bridging header for TrueDepthStreamer
*/

#import "HistogramCalculator.h"
#import "PointCloudMetalView.h"
