/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Class containing methods for tone generation.
*/

import AudioToolbox
import AVFoundation

extension ViewController {
    func configureAudioUnit() {
        let kOutputUnitSubType = kAudioUnitSubType_RemoteIO

        let ioUnitDesc = AudioComponentDescription(
            componentType: kAudioUnitType_Output,
            componentSubType: kOutputUnitSubType,
            componentManufacturer: kAudioUnitManufacturer_Apple,
            componentFlags: 0,
            componentFlagsMask: 0)

        guard
            let ioUnit = try? AUAudioUnit(componentDescription: ioUnitDesc,
                                          options: AudioComponentInstantiationOptions()),
            let outputRenderFormat = AVAudioFormat(
                standardFormatWithSampleRate: ioUnit.outputBusses[0].format.sampleRate,
                channels: 1) else {
                    print("Unable to create outputRenderFormat")
                    return
        }

        do {
            try ioUnit.inputBusses[0].setFormat(outputRenderFormat)
        } catch {
            print("Error setting format on ioUnit")
            return
        }

        ioUnit.outputProvider = { (
            actionFlags: UnsafeMutablePointer<AudioUnitRenderActionFlags>,
            timestamp: UnsafePointer<AudioTimeStamp>,
            frameCount: AUAudioFrameCount,
            busIndex: Int,
            rawBufferList: UnsafeMutablePointer<AudioBufferList>) -> AUAudioUnitStatus in

            let bufferList = UnsafeMutableAudioBufferListPointer(rawBufferList)
            if !bufferList.isEmpty {
                let signal = self.getSignal()

                bufferList[0].mData?.copyMemory(from: signal,
                                                byteCount: self.numSamples * MemoryLayout<Float>.size)
            }

            return noErr
        }

        do {
            try ioUnit.allocateRenderResources()
        } catch {
            print("Error allocating render resources")
            return
        }

        do {
            try ioUnit.startHardware()
        } catch {
            print("Error starting audio")
        }
    }
}
