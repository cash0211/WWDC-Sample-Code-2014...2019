/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of iOS view controller that demonstrates signal extraction from noise.
*/

import UIKit
import Accelerate

let RENDER_AUDIO = false

class ViewController: UIViewController {

    let numSamples = 1024

    lazy var noisySignal = ViewController.signal(noiseAmount: noiseAmount,
                                                 numSamples: numSamples)

    var threshold = Float(0)
    var noiseAmount: Float = 0
    var showFrequencyDomain = false

    let shapeLayer = CAShapeLayer()
    let overlayLayer = CAShapeLayer()

    // MARK: Toolbar Controls

    var noiseSliderItem: UIBarButtonItem = {
        let noiseSlider = UISlider()
        noiseSlider.minimumValue = 0
        noiseSlider.maximumValue = 5
        noiseSlider.addTarget(self,
                              action: #selector(noiseSliderHandler),
                              for: .valueChanged)

        return UIBarButtonItem(customView: noiseSlider)
    }()

    var thresholdSliderItem: UIBarButtonItem = {
        let thresholdSlider = UISlider()
        thresholdSlider.minimumValue = 0
        thresholdSlider.maximumValue = 256
        thresholdSlider.addTarget(self,
                                  action: #selector(thresholdSliderHandler),
                                  for: .valueChanged)

        return UIBarButtonItem(customView: thresholdSlider)
    }()

    var forwardInverseSwitchItem: UIBarButtonItem = {
        let button = UISwitch()

        button.addTarget(self,
                         action: #selector(forwardInverseSwitch),
                         for: .valueChanged)

        return UIBarButtonItem(customView: button)
    }()

    @IBOutlet weak var toolbar: UIToolbar!

    // MARK: Overridden View Functions

    override func viewDidLoad() {
        super.viewDidLoad()

        view.layer.addSublayer(shapeLayer)
        view.layer.addSublayer(overlayLayer)

        let spacer = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)

        toolbar.setItems([UIBarButtonItem(title: "Noise Level", style: .plain, target: nil, action: nil),
                          noiseSliderItem,
                          spacer,
                          UIBarButtonItem(title: "Threshold", style: .plain, target: nil, action: nil),
                          thresholdSliderItem,
                          spacer,
                          forwardInverseSwitchItem],
                         animated: false)

        if RENDER_AUDIO {
            configureAudioUnit()
        } else {
            let displaylink = CADisplayLink(target: self,
                                            selector: #selector(getSignal))

            displaylink.add(to: .current,
                            forMode: .default)
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        noiseSliderItem.customView?.frame.size.width = view.frame.width * 0.3
        thresholdSliderItem.customView?.frame.size.width = view.frame.width * 0.3

        shapeLayer.frame = view.frame.insetBy(dx: 0, dy: 50)
        overlayLayer.frame = view.frame.insetBy(dx: 0, dy: 50)
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }

    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge {
        return .bottom
    }

    deinit {
        vDSP_DFT_DestroySetup(dctSetupForward)
        vDSP_DFT_DestroySetup(dctSetupInverse)
    }

    // MARK: UI Control Handlers

    @objc
    func forwardInverseSwitch(button: UISwitch) {
        showFrequencyDomain = !showFrequencyDomain
    }

    @objc
    func noiseSliderHandler(slider: UISlider) {
        noiseAmount = slider.value

        noisySignal = ViewController.signal(noiseAmount: noiseAmount,
                                            numSamples: numSamples)
    }

    @objc
    func thresholdSliderHandler(slider: UISlider) {
        threshold = slider.value
    }

    // MARK: DCT Setup
    lazy var dctSetupForward: vDSP_DFT_Setup = {
        guard let setup = vDSP_DCT_CreateSetup(
            nil,
            vDSP_Length(numSamples),
            .II) else {
                fatalError("can't create forward vDSP_DFT_Setup")
        }

        return setup
    }()

    lazy var dctSetupInverse: vDSP_DFT_Setup = {
        guard let setup = vDSP_DCT_CreateSetup(
            nil,
            vDSP_Length(numSamples),
            .III) else {
                fatalError("can't create inverse vDSP_DFT_Setup")
        }

        return setup
    }()

    // MARK: Signal Generation

    static func signal(noiseAmount: Float,
                       numSamples: Int) -> [Float] {

        let tau = Float.pi * 2

        return (0 ..< numSamples).map { i in
            let phase = Float(i) / Float(numSamples) * tau

            var signal = cos(phase * 1) * 1.0
            signal += cos(phase * 2) * 0.8
            signal += cos(phase * 4) * 0.4
            signal += cos(phase * 8) * 0.8
            signal += cos(phase * 16) * 1.0
            signal += cos(phase * 32) * 0.8

            return signal + .random(in: -1...1) * noiseAmount
        }
    }

    // MARK: Execute DCT

    lazy var forwardDCT = [Float](repeating: 0,
                                  count: numSamples)

    lazy var inverseDCT = [Float](repeating: 0,
                                  count: numSamples)

    @objc
    func getSignal() -> [Float] {
        vDSP_DCT_Execute(dctSetupForward,
                         noisySignal,
                         &forwardDCT)

        let stride = vDSP_Stride(1)
        let count = vDSP_Length(numSamples)

        vDSP_vthres(forwardDCT,
                    stride,
                    &threshold,
                    &forwardDCT,
                    stride,
                    count)

        vDSP_DCT_Execute(dctSetupInverse,
                         forwardDCT,
                         &inverseDCT)

        var divisor = Float(count)
        vDSP_vsdiv(inverseDCT,
                   stride,
                   &divisor,
                   &inverseDCT,
                   stride,
                   count)

        displayWaveInLayer(shapeLayer,
                           ofColor: .red,
                           signal: showFrequencyDomain ? forwardDCT : inverseDCT,
                           min: showFrequencyDomain ? nil : -2,
                           max: showFrequencyDomain ? nil : 2,
                           hScale: showFrequencyDomain ? 4 : 1)

        if showFrequencyDomain {
            displayThreshold()
        } else {
            overlayLayer.path = nil
        }

        return inverseDCT
    }

    // MARK: Display Waveform and Threshold

    func displayThreshold() {
        var min: Float = 0
        vDSP_minv(forwardDCT,
                  1,
                  &min,
                  vDSP_Length(forwardDCT.count))

        var max: Float = 0
        vDSP_maxv(forwardDCT,
                  1,
                  &max,
                  vDSP_Length(forwardDCT.count))

        let thresholdVector = [Float](repeating: threshold,
                                      count: numSamples)

        displayWaveInLayer(overlayLayer,
                           ofColor: .blue,
                           signal: thresholdVector,
                           min: min,
                           max: max,
                           hScale: 4)
    }

    func displayWaveInLayer(_ targetLayer: CAShapeLayer,
                            ofColor color: UIColor,
                            signal: [Float],
                            min: Float?, max: Float?,
                            hScale: CGFloat) {
        DispatchQueue.main.async {
            GraphUtility.drawGraphInLayer(targetLayer,
                                          strokeColor: color.cgColor,
                                          lineWidth: 3,
                                          values: signal,
                                          minimum: min,
                                          maximum: max,
                                          hScale: hScale)
        }
    }
}
