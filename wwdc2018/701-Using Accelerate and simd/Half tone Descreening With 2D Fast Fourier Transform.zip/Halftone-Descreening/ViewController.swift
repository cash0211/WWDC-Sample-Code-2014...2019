/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of iOS view controller that demonstrates falftone descreening.
*/

import UIKit

class ViewController: UIViewController {

    enum Thresholds: String {
        case off = "Off"
        case low = "Low"
        case medium = "Medium"
        case high = "High"

        func value() -> Float? {
            switch self {
            case .off:
                return nil
            case .low:
                return 5e+07
            case .medium:
                return 5e+08
            case .high:
                return 5e+14
            }
        }
    }

    let thresholdSegmentedControlItem: UIBarButtonItem = {
        let segmentedControl = UISegmentedControl(items: [Thresholds.off.rawValue,
                                                          Thresholds.high.rawValue,
                                                          Thresholds.medium.rawValue,
                                                          Thresholds.low.rawValue])

        segmentedControl.selectedSegmentIndex = 0

        segmentedControl.setTitleTextAttributes(
            [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16)],
            for: .normal)

        segmentedControl.addTarget(self,
                                   action: #selector(thresholdSegmentedControlChangeHandler),
                                   for: .valueChanged)

        return UIBarButtonItem(customView: segmentedControl)
    }()

    @IBOutlet var imageView: UIImageView!
    @IBOutlet weak var toolbar: UIToolbar!

    let activityIndicator = UIActivityIndicatorView(style: .whiteLarge)

    override func viewDidLoad() {
        super.viewDidLoad()

        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        activityIndicator.color = .green
        imageView.addSubview(activityIndicator)

        toolbar.setItems([thresholdSegmentedControlItem],
                         animated: false)

        showImage(threshold: nil)
    }

    let sourceImageName = "Flowers_1024_10.jpg"
    let halftoneSampleName = "HalftoneScreen_1024_10.jpg"

    func showImage(threshold: Float?) {
        if let threshold = threshold {
            activityIndicator.frame = imageView.frame
            activityIndicator.startAnimating()

            DispatchQueue.global().async {
                guard
                    let sourceImage = UIImage(named: self.sourceImageName),
                    let halftoneSample = UIImage(named: self.halftoneSampleName),
                    let result = HalftoneDescreener.descreen(sourceImage: sourceImage,
                                                             halftoneSample: halftoneSample,
                                                             threshold: threshold) else {
                                                                print("Error")
                                                                return
                }
                DispatchQueue.main.async {
                    self.imageView.image = result
                    self.activityIndicator.stopAnimating()
                }

            }
        } else {
            imageView.image = UIImage(named: sourceImageName)
        }
    }

    @objc
    func thresholdSegmentedControlChangeHandler(segmentedControl: UISegmentedControl) {
        guard
            let newThresholdName = segmentedControl.titleForSegment(at: segmentedControl.selectedSegmentIndex),
            let newThreshold = Thresholds(rawValue: newThresholdName) else {
                return
        }

        showImage(threshold: newThreshold.value())
    }

    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge {
        return .bottom
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
