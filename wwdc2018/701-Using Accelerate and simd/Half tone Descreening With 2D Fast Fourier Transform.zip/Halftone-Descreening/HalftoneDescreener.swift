/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Class containing static methods for halftone descreening.
*/

import Accelerate
import simd
import UIKit

class HalftoneDescreener {
    // MARK: 2D FFT to demo halftone descreening
    static func descreen(sourceImage: UIImage, halftoneSample: UIImage, threshold: Float) -> UIImage? {
        assert(sourceImage.size == CGSize(width: 1024, height: 1024) &&
            halftoneSample.size == CGSize(width: 1024, height: 1024),
               "Image must be 1024 x 1024")
        
        let width = Int(sourceImage.size.width)
        let height = Int(sourceImage.size.height)
        let pixelCount = width * height
        let n = pixelCount / 2
        
        var sourceImageReal = [Float](repeating: 0, count: n)
        var sourceImageImaginary = [Float](repeating: 0, count: n)
        var sourceImageSplitComplex = DSPSplitComplex(realp: &sourceImageReal,
                                                      imagp: &sourceImageImaginary)
        
        imageToComplex(sourceImage,
                       splitComplex: &sourceImageSplitComplex)
        
        var halftoneSampleReal = [Float](repeating: 0, count: n)
        var halftoneSampleImag = [Float](repeating: 0, count: n)
        var halftoneSampleSplitComplex = DSPSplitComplex(realp: &halftoneSampleReal,
                                                         imagp: &halftoneSampleImag)
        
        imageToComplex(halftoneSample,
                       splitComplex: &halftoneSampleSplitComplex)
        
        return fft_2D(sourceImageSplitComplex: &sourceImageSplitComplex,
                      halftoneSampleSplitComplex: &halftoneSampleSplitComplex,
                      size: sourceImage.size,
                      threshold: threshold)
    }
    
    static let fftSetUp: FFTSetup = {
        let log2n = vDSP_Length(log2(1024.0 * 1024.0))
        
        guard let fftSetUp = vDSP_create_fftsetup(
            log2n,
            FFTRadix(kFFTRadix2)) else {
                fatalError("can't create FFT Setup")
        }
        return fftSetUp
    }()
    
    static func fft_2D(sourceImageSplitComplex: inout DSPSplitComplex,
                       halftoneSampleSplitComplex: inout DSPSplitComplex,
                       size: CGSize,
                       threshold: Float) -> UIImage? {
        
        let width = Int(size.width)
        let height = Int(size.height)
        let pixelCount = width * height
        let n = pixelCount / 2
        let stride = vDSP_Stride(1)
        
        var sourceImage_floatPixelsReal_spatial = [Float](repeating: 0,
                                                          count: n)
        var sourceImage_floatPixelsImag_frequency = [Float](repeating: 0,
                                                            count: n)
        var sourceImage_floatPixels_frequency = DSPSplitComplex(
            realp: &sourceImage_floatPixelsReal_spatial,
            imagp: &sourceImage_floatPixelsImag_frequency)
        
        vDSP_fft2d_zrop(fftSetUp,
                        &sourceImageSplitComplex,
                        stride,
                        0,
                        &sourceImage_floatPixels_frequency,
                        stride,
                        0,
                        vDSP_Length(log2(Float(width))),
                        vDSP_Length(log2(Float(height))),
                        FFTDirection(kFFTDirection_Forward))
        
        var halftoneSample_floatPixelsReal_frequency = [Float](repeating: 0,
                                                               count: n)
        var halftoneSample_floatPixelsImag_frequency = [Float](repeating: 0,
                                                               count: n)
        var halftoneSample_floatPixels_frequency = DSPSplitComplex(
            realp: &halftoneSample_floatPixelsReal_frequency,
            imagp: &halftoneSample_floatPixelsImag_frequency)
        
        vDSP_fft2d_zrop(fftSetUp,
                        &halftoneSampleSplitComplex,
                        stride,
                        0,
                        &halftoneSample_floatPixels_frequency,
                        stride,
                        0,
                        vDSP_Length(log2(Float(width))),
                        vDSP_Length(log2(Float(height))),
                        FFTDirection(kFFTDirection_Forward))
        
        var halftoneSampleAmplitude = [Float](repeating: 0,
                                              count: n)
        vDSP_zvmags(&halftoneSample_floatPixels_frequency,
                    stride,
                    &halftoneSampleAmplitude,
                    stride,
                    vDSP_Length(n))
        
        // all values in `halftoneSampleAmplitude` greater than `threshold` to -1, else +1...
        var outputConstant: Float = -1
        
        var mutableThreshold = threshold
        
        vDSP_vthrsc(halftoneSampleAmplitude,
                    stride,
                    &mutableThreshold,
                    &outputConstant,
                    &halftoneSampleAmplitude,
                    stride,
                    vDSP_Length(n))
        
        // all negative values in `halftoneSampleAmplitude` to 0...
        var low = Float(0)
        var hi = Float(1)
        vDSP_vclip(halftoneSampleAmplitude,
                   stride,
                   &low,
                   &hi,
                   &halftoneSampleAmplitude,
                   stride,
                   vDSP_Length(n))
        
        // multiply frequency domain pixels by values in `halftoneSampleAmplitude`...
        halftoneSampleAmplitude[0] = 1
        vDSP_zrvmul(&sourceImage_floatPixels_frequency,
                    stride,
                    halftoneSampleAmplitude,
                    stride,
                    &sourceImage_floatPixels_frequency,
                    stride,
                    vDSP_Length(n))
        
        // perform inverse FFT to create image from frequency domain data...
        var floatPixelsReal_spatial = [Float](repeating: 0,
                                              count: n)
        var floatPixelsImag_spatial = [Float](repeating: 0,
                                              count: n)
        var floatPixels_spatial = DSPSplitComplex(realp: &floatPixelsReal_spatial,
                                                  imagp: &floatPixelsImag_spatial)
        
        vDSP_fft2d_zrop(fftSetUp,
                        &sourceImage_floatPixels_frequency,
                        stride,
                        0,
                        &floatPixels_spatial,
                        stride,
                        0,
                        vDSP_Length(log2(Float(width))),
                        vDSP_Length(log2(Float(height))),
                        FFTDirection(kFFTDirection_Inverse))
        
        let image = imageFromPixelSource(floatPixels_spatial,
                                         width: width,
                                         height: height,
                                         bitmapInfo: CGBitmapInfo(rawValue: 0))
        
        return image
    }
    
    static func imageToComplex(_ image: UIImage, splitComplex splitComplexOut: inout DSPSplitComplex) {
        guard let cgImage = image.cgImage else {
            fatalError("unable to generate cgimage")
        }
        
        let pixelCount = Int(image.size.width * image.size.height)
        
        let pixelData = cgImage.dataProvider?.data
        let pixels: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        
        var floatPixels = [Float](repeating: 0,
                                  count: pixelCount)
        
        vDSP_vfltu8(pixels,
                    1,
                    &floatPixels,
                    1,
                    vDSP_Length(pixelCount))
        
        let n = vDSP_Length(pixelCount / 2)
        
        var interleavedPixels = stride(from: 1, to: floatPixels.count, by: 2).map {
            return DSPComplex(real: floatPixels[$0.advanced(by: -1)],
                              imag: floatPixels[$0])
        }
        
        vDSP_ctoz(&interleavedPixels,
                  2,
                  &splitComplexOut,
                  1,
                  n)
    }
    
    static func imageFromPixelSource(_ pixelSource: DSPSplitComplex,
                                     width: Int, height: Int,
                                     denominator: Float = pow(2, 29),
                                     bitmapInfo: CGBitmapInfo) -> UIImage? {
        
        let pixelCount = width * height
        let n = vDSP_Length(pixelCount / 2)
        let stride = vDSP_Stride(1)
        
        // multiply all float values (1 / denominator) * 255
        var multiplier = Float((1 / denominator) * 255)
        var mutablePixelSource = pixelSource
        // use a stride of 0 through `multiplier` to treat it as a scalar value
        vDSP_zrvmul(&mutablePixelSource,
                    stride,
                    &multiplier,
                    0,
                    &mutablePixelSource,
                    stride,
                    n)
        
        // Clip values to 0...255
        var low: Float = 0
        var high: Float = 255
        vDSP_vclip(pixelSource.realp,
                   stride,
                   &low,
                   &high,
                   pixelSource.realp,
                   stride,
                   n)
        
        vDSP_vclip(pixelSource.imagp,
                   stride,
                   &low,
                   &high,
                   pixelSource.imagp,
                   stride, n)
        
        var interleavedPixels = [DSPComplex](repeating: DSPComplex(real: 0, imag: 0),
                                             count: pixelCount)
        vDSP_ztoc(&mutablePixelSource,
                  stride,
                  &interleavedPixels,
                  2,
                  vDSP_Length(pixelCount))

        var uIntPixels_OUT = [UInt8](repeating: 0,
                                     count: pixelCount)
        
        let floatPixels = interleavedPixels.map {
            return [$0.real, $0.imag]
            }.flatMap { $0 }

        vDSP_vfixu8(floatPixels,
                    stride,
                    &uIntPixels_OUT,
                    stride,
                    vDSP_Length(pixelCount))
        
        if
            let outputData = CFDataCreate(nil, uIntPixels_OUT, pixelCount),
            let cgDataProvider = CGDataProvider(data: outputData),
            let cgImage = CGImage(width: width,
                                  height: height,
                                  bitsPerComponent: 8,
                                  bitsPerPixel: 8,
                                  bytesPerRow: width,
                                  space: CGColorSpaceCreateDeviceGray(),
                                  bitmapInfo: bitmapInfo,
                                  provider: cgDataProvider,
                                  decode: nil,
                                  shouldInterpolate: false,
                                  intent: CGColorRenderingIntent.defaultIntent) {
            
            let final = UIImage(cgImage: cgImage)
            
            return final
        } else {
            print("Unable to create CGImage")
            return nil
        }
    }
    
    static func destroySetup() {
        vDSP_destroy_fftsetup(fftSetUp)
    }
}
