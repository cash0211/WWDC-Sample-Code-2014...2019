# Halftone Descreening with 2D Fast Fourier Transform

Reduce or remove periodic artifacts from images.

## Overview

Accelerate’s vDSP module provides functions to perform 2D fast Fourier transforms (FFTs) on matrices of data, such as images. You can exploit the amplitude peaks in the frequency domain of periodic patterns, such as halftone screens, to reduce or remove such artifacts from images. The example below shows an image with halftone artifacts (left) and the same image with the halftone artifacts reduced (right):

![Photographs showing before and after images.](Documentation/halftone_descreen_2x.png)

Using a halftone screen sample that you’ve created programmatically or taken from source material, you’ll follow these steps for halftone descreening of an image:

1. Converting the image data to a split complex vector
2. Preparing the FFT setup
3. Performing forward 2D FFTs on image data
4. Zeroing the peaks in the halftone sample magnitude
5. Descreening the source image
6. Performing inverse 2D FFT on the source image frequency domain data
7. Generating an image from a split complex vector

The sample works on a single-channel, monochrome image. 

## Convert Image Data to a Split Complex Vector

Create a split complex vector—suitable for use with vDSP’s 2D FFT—by copying odd pixels to the real parts and even pixels to the imaginary parts of an array of complex numbers. Use the following code to convert the 8-bit unsigned integer image data to floating-point data that the 2D FFT routine works with: 

``` swift
let pixelCount = Int(image.size.width * image.size.height)

let pixelData = cgImage.dataProvider?.data
let pixels: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)

var floatPixels = [Float](repeating: 0,
                          count: pixelCount)

vDSP_vfltu8(pixels,
            1,
            &floatPixels,
            1,
            vDSP_Length(pixelCount))
```

With the floating-point values populated, create an array of complex numbers, `interleavedPixels`, that you pass to [`vDSP_ctoz`](https://developer.apple.com/documentation/accelerate/1450388-vdsp_ctoz), which copies the values into a split complex vector:

``` swift
let n = vDSP_Length(pixelCount / 2)

var interleavedPixels = stride(from: 1, to: floatPixels.count, by: 2).map {
    return DSPComplex(real: floatPixels[$0.advanced(by: -1)],
                      imag: floatPixels[$0])
}

vDSP_ctoz(&interleavedPixels,
          2,
          &splitComplexOut,
          1,
          n)
```
                  
## Prepare the 2D FFT Setup

Create a setup object that contains all the information required to perform the forward and inverse 2D FFT operations. Creating this setup object can be expensive, so do it only once—for example, when your app is starting—and reuse it.

The following code creates a setup object suitable for performing forward and inverse 2D FFTs on a 1024 x 1024 pixel image:

``` swift
static let fftSetUp: FFTSetup = {
    let log2n = vDSP_Length(log2(1024.0 * 1024.0))
    
    guard let fftSetUp = vDSP_create_fftsetup(
        log2n,
        FFTRadix(kFFTRadix2)) else {
            fatalError("can't create FFT Setup")
    }
    return fftSetUp
}()
```

## Perform Forward 2D FFTs on Image Data

Use the [`vDSP_fft2d_zrop`](https://developer.apple.com/documentation/accelerate/1450361-vdsp_fft2d_zrop) function to perform a forward 2D FFT on the image data, creating the frequency domain representation of the image. Pass `vDSP_fft2d_zrop` a split complex structure as the destination, with the same length as the source structure. 

The following example shows the code required to perform the FFT on the source image data that populates `sourceImage_floatPixels_frequency`. Repeat this step for the halftone sample image, populating `halftoneSample_floatPixels_frequency`.

``` swift
let width = Int(size.width)
let height = Int(size.height)
let pixelCount = width * height
let n = pixelCount / 2
let stride = vDSP_Stride(1)

var sourceImage_floatPixelsReal_spatial = [Float](repeating: 0,
                                                  count: n)
var sourceImage_floatPixelsImag_frequency = [Float](repeating: 0,
                                                    count: n)
var sourceImage_floatPixels_frequency = DSPSplitComplex(
    realp: &sourceImage_floatPixelsReal_spatial,
    imagp: &sourceImage_floatPixelsImag_frequency)

vDSP_fft2d_zrop(fftSetUp,
                &sourceImageSplitComplex,
                stride,
                0,
                &sourceImage_floatPixels_frequency,
                stride,
                0,
                vDSP_Length(log2(Float(width))),
                vDSP_Length(log2(Float(height))),
                FFTDirection(kFFTDirection_Forward))
```

## Zero the Peaks in the Halftone Sample Magnitude

You can reduce the halftone screen artifacts by manipulating the magnitude of the frequency domain data for the halftone sample. Zero all the samples above a specified threshold in the magnitudes and clamp the data to 0...1. Then multiply the frequency domain data of the source image by the manipulated magnitudes.

The [`vDSP_zvmags`](https://developer.apple.com/documentation/accelerate/1450557-vdsp_zvmags) function computes the magnitude of the complex values representing the halftone sample:

``` swift
var halftoneSampleAmplitude = [Float](repeating: 0,
                                      count: n)
vDSP_zvmags(&halftoneSample_floatPixels_frequency,
            stride,
            &halftoneSampleAmplitude,
            stride,
            vDSP_Length(n))
```

Use the [`vDSP_vthrsc`](https://developer.apple.com/documentation/accelerate/1450631-vdsp_vthrsc) function to set all magnitude values that are over the threshold to -1, and all magnitude values that are less than or equal to the threshold to 1:

``` swift
var outputConstant: Float = -1

var mutableThreshold = threshold

vDSP_vthrsc(halftoneSampleAmplitude,
            stride,
            &mutableThreshold,
            &outputConstant,
            &halftoneSampleAmplitude,
            stride,
            vDSP_Length(n))
```

You can now clip the magnitude data between 0 and 1. After [`vDSP_vclip`](https://developer.apple.com/documentation/accelerate/1450071-vdsp_vclip) returns, all the originally high-magnitude values in `halftoneSampleAmplitude` are set to 0, and all the originally low-magnitude values are set to 1:

``` swift
var low = Float(0)
var hi = Float(1)
vDSP_vclip(halftoneSampleAmplitude,
           stride,
           &low,
           &hi,
           &halftoneSampleAmplitude,
           stride,
           vDSP_Length(n))
```

## Descreen the Source Image

Multiply the source image frequency domain data by the values in `halftoneSampleAmplitude` to remove or reduce the halftone screen:

``` swift
vDSP_zrvmul(&sourceImage_floatPixels_frequency,
            stride,
            halftoneSampleAmplitude,
            stride,
            &sourceImage_floatPixels_frequency,
            stride,
            vDSP_Length(n))
```

## Perform Inverse 2D FFT on Source Image Frequency Domain Data

You can now perform an inverse 2D FFT to generate a spatial domain version of the image. Use the same `fftSetup` pointer as you used for the forward 2D FFT, but specify the inverse direction:

``` swift
var floatPixelsReal_spatial = [Float](repeating: 0,
                                      count: n)
var floatPixelsImag_spatial = [Float](repeating: 0,
                                      count: n)
var floatPixels_spatial = DSPSplitComplex(realp: &floatPixelsReal_spatial,
                                          imagp: &floatPixelsImag_spatial)

vDSP_fft2d_zrop(fftSetUp,
                &sourceImage_floatPixels_frequency,
                stride,
                0,
                &floatPixels_spatial,
                stride,
                0,
                vDSP_Length(log2(Float(width))),
                vDSP_Length(log2(Float(height))),
                FFTDirection(kFFTDirection_Inverse))
```

## Generate an Image from a Split Complex Vector

The last step is to create a displayable image from the spatial domain representation of the treated source image. The final image is generated from 8-bit, unsigned integers. Because single-precision values can exceed the range of an 8-bit, unsigned integer, clamp the values before storing them:

``` swift
var low: Float = 0
var high: Float = 255
vDSP_vclip(pixelSource.realp,
           stride,
           &low,
           &high,
           pixelSource.realp,
           stride,
           n)

vDSP_vclip(pixelSource.imagp,
           stride,
           &low,
           &high,
           pixelSource.imagp,
           stride, n)
```

vDSP’s conversion functions allow you to convert the clamped floating-point values to 8-bit, unsigned integers. To prepare the split complex vector for conversion, copy its contents to an array of interleaved complex numbers:

``` swift
var interleavedPixels = [DSPComplex](repeating: DSPComplex(real: 0, imag: 0),
                                     count: pixelCount)
vDSP_ztoc(&mutablePixelSource,
          stride,
          &interleavedPixels,
          2,
          vDSP_Length(pixelCount))
```

Use [`vDSP_vfixu8`](https://developer.apple.com/documentation/accelerate/1450800-vdsp_vfixu8) to convert the floating-point values back to 8-bit unsigned integers suitable for generating an image:

``` swift
var uIntPixels_OUT = [UInt8](repeating: 0,
                             count: pixelCount)

let floatPixels = interleavedPixels.map {
    return [$0.real, $0.imag]
    }.flatMap { $0 }

vDSP_vfixu8(floatPixels,
            stride,
            &uIntPixels_OUT,
            stride,
            vDSP_Length(pixelCount))
```

Now that `uIntPixels_OUT` is populated with the pixel values, generate a `CGImage` instance from those values:

``` swift
if
    let outputData = CFDataCreate(nil, uIntPixels_OUT, pixelCount),
    let cgDataProvider = CGDataProvider(data: outputData),
    let cgImage = CGImage(width: width,
                          height: height,
                          bitsPerComponent: 8,
                          bitsPerPixel: 8,
                          bytesPerRow: width,
                          space: CGColorSpaceCreateDeviceGray(),
                          bitmapInfo: bitmapInfo,
                          provider: cgDataProvider,
                          decode: nil,
                          shouldInterpolate: false,
                          intent: CGColorRenderingIntent.defaultIntent) {
    
    let final = UIImage(cgImage: cgImage)
    
    return final
} else {
    print("Unable to create CGImage")
    return nil
}
```

## Deallocate FFT Setup Memory

When you’re finished using the setup object, it’s important to deallocate memory that’s been allocated to it. The code below shows how to use the [vDSP_destroy_fftsetup](https://developer.apple.com/documentation/accelerate/1450396-vdsp_destroy_fftsetup) function to destroy the setup object:

``` swift
vDSP_destroy_fftsetup(fftSetUp)
```
