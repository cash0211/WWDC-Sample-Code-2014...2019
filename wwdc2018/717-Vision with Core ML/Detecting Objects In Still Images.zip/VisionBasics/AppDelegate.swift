/*
See LICENSE folder for this sample’s licensing information.

Abstract:
App delegate for Vision object detection.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
}

