/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The play library.
*/

import Foundation

/// The collection of all plays that we know about.
class PlayLibrary: NSObject {

    /// The play library used throughout the app.
    static var shared = PlayLibrary()
    
    private(set) var plays: [Play] = []

    override init() {
        super.init()
        setupClassKit()
    }
    
    /// Adds a play to the play library.
    /// - Parameters:
    ///     - play: The play to add.
    ///
    /// - Tag: addPlay
    func addPlay(_ play: Play) {
        plays.append(play)
        
        // Give ClassKit a chance to set up its own contexts.
        setupContext(play: play)
    }
}
