/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A node in the data model hierarchy.
*/

import ClassKit

/// A node in the data model hierarchy.
/// - Tag: nodeProtocolDeclaration
protocol Node {
    var parent: Node? { get }
    var children: [Node]? { get }
    var identifier: String { get }
    var contextType: CLSContextType { get }
}

// MARK: Identifiers

extension Node {
    var identifierPath: [String] {
        var pathComponents: [String] = [identifier]
        
        if let parent = self.parent {
            pathComponents = parent.identifierPath + pathComponents
        }
        
        return pathComponents
    }
    
    /// Finds a node in the play list hierarchy by its identifier path.
    func descendant(matching identifierPath: [String]) -> Node? {
        if let identifier = identifierPath.first {
            if let child = children?.first(where: { $0.identifier == identifier }) {
                return child.descendant(matching: Array(identifierPath.suffix(identifierPath.count - 1)))
            } else {
                return nil
            }
        } else {
            return self
        }
    }
}

// MARK: Activity

extension Node {
    /// Activates the context for this node and starts its activity.
    /// - Tag: beginActivity
    func beginActivity(asNew: Bool = false) {
        print("Start \(identifierPath)")

        CLSDataStore.shared.mainAppContext.descendant(matchingIdentifierPath: identifierPath) { context, _ in

            // Activate the context.
            context?.becomeActive()

            if asNew == false,
                let activity = context?.currentActivity {
                
                // Re-start the existing activity
                activity.start()
                
            } else {
                // Create and start an activity.
                context?.createNewActivity().start()
            }
            
            CLSDataStore.shared.save { error in
                guard error == nil else { print("***Save error: \(error!.localizedDescription)"); return }
            }
        }
    }

    /// Updates the current activity with latest progress.
    /// - Tag: updateProgress
    func update(progress: Double) {
        CLSDataStore.shared.mainAppContext.descendant(matchingIdentifierPath: identifierPath) { context, _ in
            guard let activity = context?.currentActivity,
                progress > activity.progress,
                activity.isStarted else { return }
            
            activity.addProgressRange(fromStart: 0, toEnd: progress)
            print("Progress \(self.identifierPath): \(Int(progress * 100))%")
        }
    }

    /// Adds a score as the primary activity item.
    /// - Tag: addScore
    func addScore(_ score: Double, title: String, primary: Bool = false) {
        print("Score \(identifierPath)")
        
        CLSDataStore.shared.mainAppContext.descendant(matchingIdentifierPath: identifierPath) { context, _ in
            guard let activity = context?.currentActivity,
                activity.isStarted else { return }

            // Create the score item and add it.
            let item = CLSScoreItem(identifier: "score", title: title, score: score, maxScore: 1)

            if primary {
                activity.primaryActivityItem = item
            } else {
                activity.addAdditionalActivityItem(item)
            }

            print("  => \(title): \(item)")
        }
    }
    
    /// Adds a quantity as a secondary item.
    /// - Tag: addQuantity
    func addQuantity(_ quantity: Double, title: String, primary: Bool = false) {
        print("Quantity \(identifierPath)")
        
        CLSDataStore.shared.mainAppContext.descendant(matchingIdentifierPath: identifierPath) { context, _ in
            guard let activity = context?.currentActivity,
                activity.isStarted else { return }

            // Create the quantity item and add it.
            let item = CLSQuantityItem(identifier: "quantity", title: title)
            item.quantity = quantity
            
            if primary {
                activity.primaryActivityItem = item
            } else {
                activity.addAdditionalActivityItem(item)
            }
            
            print("  => \(title): \(quantity)")
        }
    }
    
    /// Marks the current context and its activity as done.
    /// - Tag: endActivity
    func endActivity() {
        print("End \(identifierPath)")

        CLSDataStore.shared.mainAppContext.descendant(matchingIdentifierPath: identifierPath) { context, _ in
            guard let activity = context?.currentActivity else { return }

            print("  => \(activity.duration) seconds elapsed.")

            // Mark the activity as complete.
            activity.stop()
            context?.resignActive()
            
            CLSDataStore.shared.save { error in
                guard error == nil else { print("***Save error: \(error!.localizedDescription)"); return }
            }
        }
    }
}
