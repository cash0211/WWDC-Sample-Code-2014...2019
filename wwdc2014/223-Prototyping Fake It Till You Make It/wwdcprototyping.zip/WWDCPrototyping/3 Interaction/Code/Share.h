/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Interactive share squence where we fake taking a picture of your toast and typing some information related to your toast.
  
 */

#import "ToastKit.h"

@interface Share : Layer

@end
