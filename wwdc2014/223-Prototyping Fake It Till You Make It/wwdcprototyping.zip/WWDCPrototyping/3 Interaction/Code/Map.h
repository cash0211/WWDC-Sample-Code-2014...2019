/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Fake map view using a picture as map.
  
 */

#import "ToastKit.h"

@interface Map : Layer

@end
