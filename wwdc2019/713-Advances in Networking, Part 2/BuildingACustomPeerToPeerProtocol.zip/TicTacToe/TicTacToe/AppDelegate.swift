/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implement the default application delegate.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var window: UIWindow?
}

