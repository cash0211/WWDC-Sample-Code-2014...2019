# Effecting People Occlusion in Custom Renderers

Occlude your app's virtual content where ARKit recognizes people in the camera feed by using matte generator.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [607: Bringing People into AR](https://developer.apple.com/videos/play/wwdc19/607/).

- Note: To run the app, use an iOS device with A12 chip or later.
