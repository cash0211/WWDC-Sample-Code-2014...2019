/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Bridging header for shared shader types.
*/

#import "ShaderTypes.h"
