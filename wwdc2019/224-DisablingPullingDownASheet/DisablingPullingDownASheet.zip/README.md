# Disabling Pulling Down a Sheet

Disable the sheet pull-down gesture when dismissal would be destructive.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [224: Modernizing Your UI for iOS 13](https://developer.apple.com/videos/play/wwdc19/224/).

