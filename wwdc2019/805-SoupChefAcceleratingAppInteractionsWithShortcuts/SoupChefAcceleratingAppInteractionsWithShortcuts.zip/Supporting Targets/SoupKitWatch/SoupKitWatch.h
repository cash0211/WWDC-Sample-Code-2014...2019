/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Umbrella header for the SoupKitWatch framework
*/

#import <WatchKit/WatchKit.h>

//! Project version number for SoupKitWatch.
FOUNDATION_EXPORT double SoupKitWatchVersionNumber;

//! Project version string for SoupKitWatch.
FOUNDATION_EXPORT const unsigned char SoupKitWatchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SoupKitWatch/PublicHeader.h>
