# Reading Phone Numbers in Real Time

Analyze and filter phone numbers from text recognized in live capture, building evidence over time.

## Overview

- Note: For more information about this sample code project, see [WWDC 2019 Session 234: Text Recognition in Vision Framework](https://developer.apple.com/videos/play/wwdc19/234/).
