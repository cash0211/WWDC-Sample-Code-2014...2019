/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for the iOS and tvOS application delegate
*/

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
                        

@end

