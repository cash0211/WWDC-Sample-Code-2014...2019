# Supporting Simulator in a Metal App 

Modify Metal Apps to Run in Simulator.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [418: Getting the Most Out of Simulator](https://developer.apple.com/videos/play/wwdc19/418/).

## Configure the Sample Code Project

Before you run the sample code project in Xcode:

* Make sure your Mac is running macOS 10.15 or later.
* Make sure you are running Xcode 11 or later.
