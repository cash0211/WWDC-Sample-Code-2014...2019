# Reading and Writing HealthKit Series Data

Share and read heartbeat and quantity series data using series builders and queries.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [218: Exploring New Data Representations in HealthKit](https://developer.apple.com/wwdc19/218).
