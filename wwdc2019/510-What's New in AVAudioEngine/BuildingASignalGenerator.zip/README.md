# Building a Signal Generator
Use `AVAudioSourceNode` and a custom render callback to generate audio signals.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [510: What's New in AVAudioEngine](https://developer.apple.com/videos/play/wwdc19/510/).

## Configure the Sample Code Project

Before you run the sample code project in Xcode:

* This sample code project requires macOS 10.15