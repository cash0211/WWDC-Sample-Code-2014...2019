# Refreshing and Maintaining Your App Using Background Tasks

Use scheduled background tasks for refreshing your app content and for performing maintenance.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [707: Advances in App Background Execution](https://developer.apple.com/videos/play/wwdc19/707/).

This sample code project must be run on a physical device.
