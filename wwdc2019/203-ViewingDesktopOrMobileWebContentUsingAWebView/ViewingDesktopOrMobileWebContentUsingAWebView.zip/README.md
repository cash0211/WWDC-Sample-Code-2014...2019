# Viewing Desktop or Mobile Web Content Using a Web View

Implement a simple iPad web browser that can view either the desktop or mobile version of a website.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [203: Introducing Desktop-class Browsing on iPad](https://developer.apple.com/videos/play/wwdc19/203/).
