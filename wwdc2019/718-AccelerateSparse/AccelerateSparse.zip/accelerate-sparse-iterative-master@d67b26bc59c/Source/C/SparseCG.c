/*
 <samplecode>
 <abstract>
 Solve a symmetric positive-definite linear system using the Conjugate Gradient Method
 </abstract>
 </samplecode>
 */

#include <stdio.h>
#include <Accelerate/Accelerate.h>

int main(void) {
    //#-code-listing(cg_1)
    int rowIndices[]    = {    0,   1,   3,    1,    2,   3,   2,   3 };
    double values[]     = { 10.0, 1.0, 2.5, 12.0, -0.3, 1.1, 9.5, 6.0 };
    //#-end-code-listing
    
    //#-code-listing(cg_2)
    long columnStarts[] = {   0,               3,              6,   7,   8};
    //#-end-code-listing
    
    //#-code-listing(cg_3)
    SparseMatrix_Double A = {
        // Structure of the matrix, without any values
        .structure = {
            .rowCount = 4,
            .columnCount = 4,
            .columnStarts = columnStarts,
            .rowIndices = rowIndices,
            // Matrix meta-data
            .attributes = {
                .kind = SparseSymmetric,          // We are using a symmetric matrix format
                .triangle = SparseLowerTriangle   // We are storing the lower triangle only
                // (we could alternatively store the upper triangle only)
            },
            // For some problems, there may be a blockSize x blockSize block of values associated with
            // each structural matrix entry, rather than a single value. This is not the case in our
            // example, so we set blockSize=1.
            .blockSize = 1
        },
        // Numerical values of the matrix
        .data = values
    };
    //#-end-code-listing
    
    //#-code-listing(cg_4)
    double bValues[] = { 2.20, 2.85, 2.79, 2.87 };
    double xValues[] = { 0.00, 0.00, 0.00, 0.00 };
    DenseVector_Double b = {
        .count = 4,     // Number of entries in the vector, used for error checking
        .data = bValues // The numerical values
    };
    DenseVector_Double x = {
        .count = 4,     // Number of entries in the vector, used for error checking
        .data = xValues // The numerical values
    };
    //#-end-code-listing
    
    //#-code-listing(cg_5)
    __auto_type status = SparseSolve(SparseConjugateGradient(), A, b, x, SparsePreconditionerDiagonal);
    //#-end-code-listing
    
    //#-code-listing(cg_6)
    if(status!=SparseIterativeConverged) {
        printf("Failed to converge. Returned with error %d\n", status);
        exit(1);
    }

    printf("x = "); for(int i=0; i<x.count; i++) printf(" %.2f", x.data[i]); printf("\n");
    //#-end-code-listing
    return 0;
}
