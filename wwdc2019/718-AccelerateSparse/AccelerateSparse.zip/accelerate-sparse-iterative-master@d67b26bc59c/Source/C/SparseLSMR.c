/*
 <samplecode>
 <abstract>
 Solve a least squares problem using the iterative method LSMR
 </abstract>
 </samplecode>
 */

#include <stdio.h>
#include <Accelerate/Accelerate.h>

int main(void) {
    //#-code-listing(lsmr_1)
    int rowIndices[]    = {   0,    1,   3,   0,   1,    2,   3,   1,   2 };
    double values[]     = { 2.0, -0.2, 2.5, 1.0, 3.2, -0.1, 1.1, 1.4, 0.5 };
    
    long columnStarts[] = {   0,              3,                   7,        9};

    SparseMatrix_Double A = {
        // Structure of the matrix, without any values
        .structure = {
            .rowCount     = 4,
            .columnCount  = 3,
            .columnStarts = columnStarts,
            .rowIndices   = rowIndices,
            // Matrix meta-data
            .attributes = {
                .kind = SparseOrdinary,           // We are storing an ordinary matrix
            },
            // For some problems, there may be a blockSize x blockSize block of values associated with
            // each structural matrix entry, rather than a single value. This is not the case in our
            // example, so we set blockSize=1.
            .blockSize = 1
        },
        // Numerical values of the matrix
        .data = values
    };
    //#-end-code-listing
    
    //#-code-listing(lsmr_4)
    double bValues[] = { 1.200, 1.013, 0.205, -0.172 };
    double xValues[] = {   0.0,   0.0,   0.0 };
    DenseVector_Double b = {
        .count = 4,     // Number of entries in the vector, used for error checking
        .data = bValues // The numerical values
    };
    DenseVector_Double x = {
        .count = 3,     // Number of entries in the vector, used for error checking
        .data = xValues // The numerical values
    };
    //#-end-code-listing
    
    //#-code-listing(lsmr_5)
    __auto_type status = SparseSolve( SparseLSMR(), A, b, x, SparsePreconditionerDiagScaling);
    
    if(status!=SparseIterativeConverged) {
        printf("Failed to converge. Returned with error %d\n", status);
        exit(1);
    }

    printf("x = "); for(int i=0; i<x.count; i++) printf(" %.2f", x.data[i]); printf("\n");
    //#-end-code-listing
    return 0;
}
