/*
 <samplecode>
 <abstract>
 Demonstrates advanced usage of iterative methods using user-defined matrix-vector operator and
 preconditioner.
 </abstract>
 </samplecode>
 */

#include <stdio.h>
#include <Accelerate/Accelerate.h>

// Structure to hold an elemental matrix descriptor
typedef struct {
    int n, nelt;
    int *sizes, *indices;
    double *data;
} Element;

// Function prototypes, see definitions for description
void doMatrixVector(Element matrix, bool accumulate, bool trans, const double *x, double *y);
SparseOpaquePreconditioner_Double buildPreconditioner(Element matrix);
void applyPreconditioner(void *mem, enum CBLAS_TRANSPOSE trans, DenseMatrix_Double X, DenseMatrix_Double Y);

// A simple routine to print status reports from GMRES
void reportStatus(const char *msg) { printf("GMRES: %s", msg); }

int main(void) {
    //#-code-listing(advanced_1)
    int elementSizes[] = { 4, 4, 2, 4, 4, 2 };
    int elementIndices[] = { 0, 1, 4, 5,      // A
        1, 2, 5, 6,      // B
        2, 6,            // C
        4, 5, 8, 9,      // D
        5, 6, 9, 10,     // E
        6, 10         }; // F
    double elementValues[] = {
        0.2, -3.0,  4.5, -0.1,  0.1,  0.5,  0.1, -2.0,  0.4, -0.5,  0.3,  0.1,  0.6, -2.2,  2.0,  0.3,  // A
        1.0, -0.2,  0.3,  5.4,  0.7, -0.2,  0.1,  1.5,  7.8, -0.6,  0.8,  0.1,  1.1,  0.9,  0.5,  0.7,  // B
        5.5,  0.4, -0.3,  0.2,                                                                          // C
        -1.5,  0.2, -4.5,  0.1,  0.2,  0.1, -2.1,  0.1,  0.3,  2.5,  0.3,  1.3,  0.7,  0.2, -4.0,  0.1, // D
        0.2, -2.5,  3.1,  0.2, -0.6,  0.3,  0.1,  0.5,  0.8, -1.6,  0.8,  2.8,  0.8,  0.7,  3.5,  2.5,  // E
        -0.4,  3.1,  0.2, -0.7 };                                                                       // F
    Element matrix = { .n=12, .nelt=6, .sizes=elementSizes, .indices=elementIndices, .data=elementValues };
    //#-end-code-listing
    
    //#-code-listing(advanced_2)
    double bdata[] = { 0.0, 0.0, 2.5, 0.0, 0.0, 0.0, 1.2, 0.0, 0.0, 0.0, 3.0, 0.0 };
    DenseVector_Double b = { .count=12, .data=bdata }; // 3 constrained nodes are just be set to zero.
    //#-end-code-listing
    
    //#-code-listing(advanced_3)
    double xdata[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
    DenseVector_Double x = { .count=12, .data=xdata };
    //#-end-code-listing
    
    //#-code-listing(advanced_4)
    __auto_type P = buildPreconditioner(matrix);
    //#-end-code-listing
    
    //#-code-listing(advanced_5)
    __auto_type status = SparseSolve(
                                     SparseGMRES((SparseGMRESOptions) {
        // We set some options for the method to use
        .variant = SparseVariantGMRES,    // Use GMRES rather than the default DQGMRES as it's faster for this example
        .reportError = reportStatus,      // Report errors via reportStatus() instead of trapping.
        .reportStatus = reportStatus,     // Also print status every few iterations.
        .nvec = 8                         // Only use 8 vectors for orthagonalization.
    }),
                                     // This block specifies how to apply the matrix-multiplication operator
                                     // We just call our doMatrixVector() routine
                                     ^void(bool accumulate, enum CBLAS_TRANSPOSE trans, DenseVector_Double x, DenseVector_Double y) {
                                         doMatrixVector(matrix, accumulate, (trans==CblasTrans), x.data, y.data);
                                     }, b, x, P);
    //#-end-code-listing
    
    //#-code-listing(advanced_6)
    if(status!=SparseIterativeConverged) {
        printf("Failed to converge. Returned with error %d\n", status);
        exit(1);
    }
    //#-end-code-listing
    
    //#-code-listing(advanced_7)
    printf("x = "); for(int i=0; i<x.count; i++) printf(" %.2f", x.data[i]); printf("\n");
    //#-end-code-listing
    return 0;
}

// Performs the operation y =     op(A) x (if accumulate is false)
//                     or y = y + op(A) x (if accumulate is true)
// where op(A) = A or A^T depending on the value of trans
void doMatrixVector(Element matrix, bool accumulate, bool trans, const double *x, double *y) {
    // Initialise y to zero if we are not asked to accumulate
    if(!accumulate)
        for(int i=0; i<matrix.n; i++) y[i] = 0.0;
    
    // Loop over elements, performing a matrix-vector product restricted to their indices with each
    int *indices = matrix.indices; double *values = matrix.data;
    for(int elt=0; elt<matrix.nelt; elt++) {
        int sz = matrix.sizes[elt]; // Number of indices in this element
        if(trans) {
            // Multiplying by A^T
            for(int jj=0; jj<sz; jj++) {
                int j = indices[jj];
                for(int ii=0; ii<sz; ii++) {
                    int i = indices[ii];
                    y[j] += values[jj*sz+ii] * x[i];
                }
            }
        } else {
            // Multiplying by A
            for(int jj=0; jj<sz; jj++) {
                int j = indices[jj];
                for(int ii=0; ii<sz; ii++) {
                    int i = indices[ii];
                    y[i] += values[jj*sz+ii] * x[j];
                }
            }
        }
        // Increment index and value pointers
        indices += sz;
        values  += sz*sz;
    }
}

// Create a Block-Jacobi (diagonal) preconditioner
// A block jacobi preconditioner is one that is equivalent to solving Dx = b, where D is the
// matrix consisting of only the diagonal blocks of our full matrix.
SparseOpaquePreconditioner_Double buildPreconditioner(Element matrix) {
    __CLPK_integer blockSize = 3; // We will use 3x3 blocks (we use __CLPK_integer for compatibility with LAPACK later)
    int blockElements = blockSize * blockSize;
    int nblk = (matrix.n-1)/blockSize + 1; // Number of blocks required
    
    // To construct the preconditioner we need to store all the data we will need
    // in a single storage block.
    size_t dataSize = 2*sizeof(__CLPK_integer) +             // Storage for blockSize and nblk
    nblk*blockElements*sizeof(double) +    // Storage for block data
    nblk*blockSize*sizeof(__CLPK_integer); // Storage for LAPACK pivoting permutation
    SparseOpaquePreconditioner_Double P = {
        .type = SparsePreconditionerUser, // User-defined preconditioner. SparseCleanup() will have no effect if called.
        .mem = malloc(dataSize),          // void* pointer passed unchanged to applyPreconditioner()
        .apply = applyPreconditioner      // Function pointer for routine to apply the preconditioner
    };
    
    // Store nblk and blockSize into our memory block
    ((__CLPK_integer*) P.mem)[0] = nblk;
    ((__CLPK_integer*) P.mem)[1] = blockSize;
    
    // For ease of reference, we construct pointers into our single storage block.
    double *blockData        = (double*) ((char*)P.mem + 2*sizeof(__CLPK_integer));
    __CLPK_integer *ipivData = (__CLPK_integer*) ((char*)P.mem + 2*sizeof(__CLPK_integer) + nblk*blockElements*sizeof(double));
    
    // Zero block data
    memset(blockData, 0, nblk*blockElements*sizeof(double));
    
    // Iterate over element representation, dropping entries into place
    int *indices = matrix.indices; double *values = matrix.data;
    for(int elt=0; elt<matrix.nelt; elt++) {
        int sz = matrix.sizes[elt]; // Number of indices in this element
        for(int jj=0; jj<sz; jj++) {
            int j = indices[jj];          // The index of variable jj of this element
            int jBlock = j / blockSize;   // Block index of block j belongs to
            double *block = &blockData[jBlock*blockElements]; // Pointer to the preconditioner block j is in
            for(int ii=0; ii<sz; ii++) {
                int i = indices[ii];        // The index of variable ii of this element
                int iBlock = i / blockSize; // Block index of block i belongs to
                if(iBlock == jBlock) {
                    // Entry falls within a diagonal block, sum it into the current value
                    block[ (j % blockSize)*blockSize + (i % blockSize) ] += values[jj*sz+ii];
                }
            }
        }
        // Increment index and value pointers
        indices += sz;
        values  += sz*sz;
    }
    
    // Iterate over blocks, performing an LU factorization using the LAPACK routine DGETRF.
    for(int blk=0; blk<nblk; blk++) {
        double *block = &blockData[blk*blockElements];   // Pointer to current block's data
        __CLPK_integer *ipiv = &ipivData[blk*blockSize]; // Pointer to current block's pivoting permutation
        
        // If there is a zero on the diagonal, variable corresponds to a constrained (ommitted) variable,
        // to prevent LAPACK complaining, we set the diagonal to 1.0 in these cases.
        for(int i=0; i<blockSize; i++)
            if(block[i*blockSize+i]==0.0) block[i*blockSize+i] = 1.0;
        
        // Call LAPACK to perform LU factorization
        __CLPK_integer info;
        dgetrf_(&blockSize, &blockSize, block, &blockSize, ipiv, &info);
    }
    
    // All the information we need to apply the preconditioner is now stored in P.mem, so return
    // the fully constructed SparseOpaquePreconditioner_Double object.
    return P;
}

// Applies our Block Jacobi preconditioner after unpacking data passed via mem
// We use the LAPACK function DGETRS to perform a solve using the output from DGETRF when we built
// the preconditioner.
void applyPreconditioner(void *mem, enum CBLAS_TRANSPOSE trans, DenseMatrix_Double X, DenseMatrix_Double Y) {
    // We assume X and Y are not transposed (as we haven't used transpose in our SparseSolve() call)
    // and that we have a single right-hand side.
    __CLPK_integer nrhs = 1; // Number of right-hand sides
    
    // Extract useful information from mem
    __CLPK_integer nblk      = ((__CLPK_integer*) mem)[0];
    __CLPK_integer blockSize = ((__CLPK_integer*) mem)[1];
    int blockElements = blockSize * blockSize;
    double *blockData        = (double*) ((char*)mem + 2*sizeof(__CLPK_integer));
    __CLPK_integer *ipivData = (__CLPK_integer*) ((char*)mem + 2*sizeof(__CLPK_integer) + nblk*blockElements*sizeof(double));
    
    // Copy X into Y, as LAPACK's solves are in-place.
    // Note we assume a single right-hand side.
    for(int i=0; i<Y.rowCount; i++)
        Y.data[i] = X.data[i];
    
    // Apply the preconditioner by performing a solve with each block in turn
    for(int blk=0; blk<nblk; blk++) {
        double *block = &blockData[blk*blockElements];   // Pointer to current block's data
        __CLPK_integer *ipiv = &ipivData[blk*blockSize]; // Pointer to current block's pivoting permutation
        char transC = (trans==CblasNoTrans) ? 'N' : 'T'; // Transpose indicator
        __CLPK_integer ldy = Y.columnStride;             // Leading dimension of Y
        __CLPK_integer info;
        dgetrs_(&transC, &blockSize, &nrhs, block, &blockSize, ipiv, &Y.data[blk*blockSize], &ldy, &info);
    }
}
