# Solving Sparse Systems

This sample demonstrates how to use the new Sparse Solvers in the Accelerate Framework.

## Overview

In addition to Sparse BLAS operations, Accelerate now provides sparse linear solvers that provide a sparse equivalent to the
dense solvers in Accelerate's LAPACK library.

A sparse matrix is one in which most entries are zero. By exploiting knowledge of this structure, sparse matrices require
significantly less storage than dense matrices. Further, linear algebra algorithms that exploit the sparse structure can
be thousands of times faster than their dense equivalents.

Accelerate provides both direct methods (matrix factorizations) and iterative methods to solve linear equations *Ax = b* and
least squares problems min *||Ax-b||*.
- **[Direct methods](https://developer.apple.com/reference/Accelerate/sparse_solvers/solving_systems_using_direct_methods)** are the easiest to use, and often the fastest for all except the largest matrices.
- **[Iterative methods](https://developer.apple.com/reference/Accelerate//sparse_solvers/solving_systems_using_iterative_methods)** provide fast approximate solutions for large matrices where an expert user provides a good preconditioner for their problem.

## Getting Started

Examples are provided in both C and Swift. In both cases all that is required is to use the Accelerate framework:

C:

```#include <accelerate/accelerate.h>```

Swift:

```import Accelerate```

If you are using XCode, linking should be automatic, otherwise you may need to supply the following argument at link time:
```-framework accelerate```

## Iterative Method Examples

The following files provide examples of using iterative methods
- **SparseCG** - example of solving *Ax = b* for symmetric positive-definte matrices *A* using the Conjugate Gradient method.
- **SparseLSMR** -  example of solving the least squares problem *||Ax - b||* for rectangular matrices using the LSMR method.
- **SparseIterativeAdvanced** - example of solving *Ax = b* where an operator function is provided rather than an explicit matrix,
  and a user-supplied preconditioner is used.

Note that it is generally recommended that a direct method such as Cholesky factorization should be employed except in cases where either:
 * The matrix is not directly available, but multiplication by the matrix is available as a function (i.e. *A* is in treated as an operator in the mathematical sense).
 * Performance and/or memory constraints make the direct method infeasible.

This is because a problem-specific preconditioner is normally required to achieve convergence and/or performance in the iterative method, and as such more developer effort is required.

## Sparse CG in Detail
This program solves the following equation via the Conjugate Gradient (CG) Method.
```
     ( 10.0  1.0      2.5 )     ( 2.20 )
     (  1.0 12.0 -0.3 1.1 ) x = ( 2.85 )
     (      -0.3  9.5     )     ( 2.79 )
     (  2.5  1.1      6.0 )     ( 2.87 )
```
In this illustration, *A* refers to the 4 x 4 matrix, and *b* to the right-hand-side vector. The code in this sample solves finds a solution to the equation *Ax = b*.
  
Note that *A* is sparse: Some entries (those that are blank) are zero. For small matrices such as this, there is little gain in exploiting this structure. However it is essential for larger systems that would not otherwise fit in memory, even on a large machine.
  
The code below uses an iterative method, this requires the multiplication of a vector by a the matrix *A*. To aid convergence, the code also specifies a preconditioner to use, in this case the inverse of the diagonal of *A* (also known as Jacobi preconditioning). CG requires that the matrix is symmetric positive-definite, that is to say *A = A^T* and all eigenvalues are greater than zero. A sufficient (but not necessary) condition for a this is that the matrix is diagonally dominant (the sum of the absolute values of the off-diagonal entries in each row or column is less than the value of the diagonal). This is the case for the above matrix.

In the Accelerate framework, Sparse Solvers stores sparse matrices using Compressed Sparse Column (CSC) format. CSC stores a matrix as a series of column vectors where the nonzero entries are specified as (row-index, value) pairs and the zero entries are omitted. Because it is symmetric, the values in the upper triangle of the matrix are redundant and should be excluded from the data passed to the matrix initializer.

- CodeListing: cg_1

In addition to the (row-index, value) pairs, you need to create a third array that specifies where each column starts. This array requires an additional, final entry that defines the final column's length.

- CodeListing: cg_2

The two structural arrays, `rowIndices` and `columnStarts`, are used to create a `SparseMatrixStructure` instance that describes the matrix's structure. The `SparseMatrixStructure` initializer requires an attributes object, `SparseAttributes_t`, that specifies a symmetric matrix and the values derive from the lower triangle. With the structure and values defined, you can create a `SparseMatrix_Double` instance:

- CodeListing: cg_3

You define the right-hand-side and solution vectors as arrays wrapped in flexible data types. The initial values of x are used as an initial guess of the solution. If no good estimate is known, initialize all the values to zero:

- CodeListing: cg_4

With the matrix and vectors created, you are ready to perform the solve using the Conjugate Gradient Method with diagonal preconditioning. `SparseSolve()` returns a status which, if equal to `SparseIterativeConverged`, indicates that the vector, `x`, contains the solution.

- CodeListing: cg_5

If there is an error, the above code prints an error message and terminates. You may instead want to capture the error by using the optional options argument to `SparseConjugateGradient()` with the member `options.reportError` set to a user-supplied error-handling routine.
    
With the matrix and vectors created, you are ready to perform the full CG iteration and iterate over the results in `x`. `SparseSolve()` returns a status which, if equal to `SparseIterativeConverged`, indicates that the vector, `x`, contains the solution.

- CodeListing: cg_6

You should get this output:
```
x =  0.10 0.20 0.30 0.40
```

## Sparse LSMR in Detail

This program solves the following equation by using the iterative method Least Squares Minimum Residual (LSMR) to find the solution to this equation:
```
   ( 2.0  1.0     )     ( 1.200 )
   ( -0.2 3.2 1.4 ) x = ( 1.013 )
   (     -0.1 0.5 )     ( 0.205 )
   ( 2.5  1.1     )     (-0.172 )
```
In the equation above, A refers to the 4 x 3 matrix, and b to the right-hand-side vector. The code in this article solves the equation Ax = b by finding x.

Because *A* is overdetermined (it has more rows than columns), for most right-hand sides there will not be an exact solution. In this case, it is normally required to find the closest solution, in the sense that it minimizes the 2-norm of the error. That is, it solves the optimization *min ‖ Ax - b ‖₂*. This is known as the least-squares problem.

You could solve this problem through a direct method such as Sparse QR; however, for some problems, a faster method that provides a "good enough" solution is the iterative method LSMR. Unlike direct methods that factorize the matrix *A*, iterative methods only require the ability to multiply by the matrix (and its transpose, *Aᵀ*). They move through a sequence of approximate solutions, converging to the correct answer. However, these methods run into numerical difficulties more often than direct methods. Resolving these issues requires expert knowledge, and is sometimes impossible. The most common method to improve and accelerate convergence is to use a preconditioner—an operator that approximates *A⁻¹*, and is hence problem specific. For least-squares problems, just using a diagonal matrix with entries equal to the 2-norm of each column is often sufficient, and is the method discussed here.

Although you do not need the matrix explicitly to use iterative methods, the Accelerate framework offers the ability to supply a matrix explicitly if it is available, reducing the code required. The example takes advantage of this ability.

As with the CG sample, the `rowIndices` array specifies the row in the matrix that contains the corresponding item in `values`, and the `columnStarts` array specifies where each column starts in the `rowIndices` array.

In this case, the `attributes` parameter allows you to specify that the matrix is unsymmetric:

- CodeListing: lsmr_1

We define the right-hand side and solution vectors as arrays wrapped in flexible data-types. The initial values of `x` are used as an initial guess of the solution. If no good estimate is known, they should be initialised to be all zero.

- CodeListing: lsmr_4

With the matrix and vectors created, you are ready to perform the full LSMR iteration and iterate over the results in `x`. `SparseSolve()` returns a status which, if equal to `SparseIterativeConverged`, indicates that the vector, `x`, contains the solution.

- CodeListing: lsmr_5

You should get this output:
```
x = 0.10 0.20 0.30.
```

## Sparse Iterative Advanced in Detail
This program demonstrates advanced usage of Accelerate's Sparse Solvers by using the iterative method GMRES in a matrix-free context with a Block Jacobi preconditioner.

Consider a simple finite element problem with the following grid:
```
0 ----- 1 ----- 2 ----- 3
|       |       |       |
|   A   |   B   |   C   |
|       |       |       |
4 ----- 5 ----- 6 ----- 7
|       |       |       |
|   D   |   E   |   F   |
|       |       |       |
8 ----- 9 ---- 10----- 11
```
In each element `A-F`, there are sets of equations that relate the values at nodes `0-11`. For the purposes of this example, there is a single degree of freedom at each node, and the values at `3`, `7` and `11` are constrained. The values for the elemental matrices (the constrains mentioned previously) are:
```
A: 0 (  0.2  0.1  0.4  0.6 ) B: 1 (  1.0  0.7  7.8  1.1 ) C: 2 (  5.5  0.4 )
   1 ( -3.0  0.5 -0.5 -2.2 )    2 ( -0.2 -0.2 -0.6  0.9 )    6 ( -0.3  0.2 )
   4 (  4.5  0.1  0.3  2.0 )    5 (  0.3  0.1  0.8  0.5 )
   5 ( -0.1 -2.0  0.1  0.3 )    6 (  5.4  1.5  0.1  0.7 )

D: 4 ( -1.5  0.2  0.3  0.7 ) E: 5 (  0.2 -0.6  0.8  0.8 ) F: 6 ( -0.4  0.2 )
   5 (  0.2  0.1  2.5  0.2 )    6 ( -2.5  0.3 -1.6  0.7 )   10 (  3.1 -0.7 )
   8 ( -4.5 -2.1  0.3 -4.0 )    9 (  3.1  0.1  0.8  3.5 )
   9 (  0.1  0.1  1.3  0.1 )   10 (  0.2  0.5  2.8  2.5 )
```
The fact that `3`, `7` and `11` are constrained means that they don't appear in the equation, but they are treated as zero rows and columns to make addressing easier - if the right-hand side is zero and the starting guess for `x` in those locations zero, then they will have no effect on the iterative method's convergence.

- CodeListing: advanced_1

Although you could assemble these element matrices to get one large sparse matrix, it can be more efficient to just store them separately if you just need to perform a matrix-vector multiplication. This is done in the routine `doMatrixVector()`.
    
To aid convergence, build a block-Jacobi preconditioner by assembling only the diagonal blocks of the full matrix and factorizing them. This is done in the routine `buildPreconditioner()`.
    
The code in this sample solves for the right-hand-side that is zero, except in positions `2`, `6`, and `10` on the basis that those values participate in elements with constrained nodes.

The following code creates the *b* vectors:

- CodeListing: advanced_2

Next, you create a solution vector with an initial guess of `0.0`:

- CodeListing: advanced_3

The `buildPreconditioner()` method returns a suitable preconditioner for `matrix`:

- CodeListing: advanced_4

'SparseSolve()' solves the equation, populating x with the solution:

- CodeListing: advanced_5

If the solve has failed to converge, the program prints an error message and exits:

- CodeListing: advanced_6

In the output you should see the residual decreasing. Only the residual for the first right-hand side is printed, if more information is desired, use `SparseIterate()` instead.
```
GMRES:     0     4.09e+00
GMRES:     1     2.48e+00
GMRES:     2     2.24e+00
GMRES:     3     2.24e+00
GMRES:     4     2.24e+00
GMRES:     5     1.42e+00
GMRES:     6     1.04e+00
GMRES:     7     2.53e-01
GMRES:     8     8.53e-02
GMRES:    16     1.61e-02
GMRES:    24     1.74e-03
GMRES:    32     1.18e-04
GMRES:    40     1.54e-05
GMRES:    48     1.70e-06
GMRES:    56     1.60e-07
GMRES:    64     1.80e-08
```
- CodeListing: advanced_7

You should get this output:
```
x =  0.11 -0.13 0.36 0.00 0.14 -0.11 0.87 0.00 -0.01 -0.10 0.10 0.00
```



## Further Reading

[Accelerate's Sparse Solver Documentation](https://developer.apple.com/reference/Accelerate/sparse_solvers)
