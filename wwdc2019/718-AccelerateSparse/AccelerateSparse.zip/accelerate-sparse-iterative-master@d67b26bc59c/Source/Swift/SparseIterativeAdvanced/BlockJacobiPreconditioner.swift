/*
 <samplecode>
 <abstract>
 Supporting code: implements a simple block jacobi preconditioner
 </abstract>
 </samplecode>
 */

import Foundation
import Accelerate
// swiftlint:disable identifier_name

// Type implementing a block Jacobi preconditioner.
struct BlockJacobiPreconditioner {
    struct Block {
        var blockSize: Int
        var pivots: [__CLPK_integer]
        var data: [Double]
        
        init(blockSize: Int) {
            self.blockSize = blockSize
            self.pivots = Array(repeating: -1, count: blockSize)
            self.data = Array(repeating: 0.0, count: blockSize * blockSize)
        }
        
        // Define a subscripting operator on the block to allow easy access to its values
        subscript(row: Int, col: Int) -> Double {
            get { return data[col * blockSize + row] }
            set { data[col * blockSize + row] = newValue }
        }
        
        // Perform LU factorization of the block
        mutating func factor() {
            // If there is a zero on the diagonal, variable corresponds to a constrained (ommitted) variable,
            // to prevent LAPACK complaining, we set the diagonal to 1.0 in these cases.
            for i in 0...blockSize - 1 where self[i, i] == 0.0 {
                self[i, i] = 1.0
            }
            
            // Call LAPACK to perform LU factorization
            var info: __CLPK_integer = 0
            let clpkBlockSize = __CLPK_integer(blockSize)
            var m = clpkBlockSize, n = clpkBlockSize, lda = clpkBlockSize, dataCopy = data
            dgetrf_(&m, &n, &dataCopy[0], &lda,
                    &pivots[0], &info)
            data = dataCopy
        }
        
        // Perform a solve with the block
        // swiftlint:disable identifier_name
        mutating func solve(transpose: CBLAS_TRANSPOSE, numberRHS: Int, Y: UnsafeMutablePointer<Double>, columnStride: Int32) {
            var transposeChar: CChar = (transpose == CblasNoTrans) ? 78 /* 'N' */ : 84 /* 'T' */ // Transpose indicator
            var info: __CLPK_integer = 0
            var clpkNumberRHS = __CLPK_integer(numberRHS)
            var clpkColumnStride = __CLPK_integer(columnStride)
            let clpkBlockSize = __CLPK_integer(blockSize)
            var n = clpkBlockSize, lda = clpkBlockSize, dataCopy = data
            dgetrs_(&transposeChar, &n, &clpkNumberRHS, &dataCopy[0], &lda,
                    &pivots[0], Y, &clpkColumnStride, &info)
            data = dataCopy
        }
    }
    var blockSize: Int
    var factored: Bool
    var blocks: [Block] = []
    
    init(blockCount: Int, blockSize: Int) {
        self.blockSize = blockSize
        self.factored = false
        
        blocks = [Block](repeating: Block(blockSize: blockSize), count: blockCount)
    }
    
    // Sum the given entry into the preconditioner (if it falls within a diagonal block)
    mutating func addEntry(row: Int, column: Int, value: Double) {
        let rowBlock = row / blockSize  // Block index of row
        let columnBlock = column / blockSize // Block index of col
        if rowBlock != columnBlock { return } // Ignore this entry, not in a diagonal block
        
        blocks[columnBlock][row % blockSize, column % blockSize] += value
    }
    
    // Factorize the blocks of the preconditioner
    mutating func factor() {
        if factored { return } // Already factorized
        
        for index in blocks.indices { blocks[index].factor() }
        factored = true
    }
    
    // Apply the preconditioner
    // swiftlint:disable identifier_name
    mutating func apply(transpose: CBLAS_TRANSPOSE, x: DenseMatrix_Double, y: DenseMatrix_Double) {
        // Copy 'x' into 'y', as LAPACK's solves are in-place.
        // Note we assume a single right-hand side.
        for i in 0..<y.rowCount { y.data[Int(i)] = x.data[Int(i)] }
        
        // Apply the preconditioner by performing a solve with each block in turn
        for index in blocks.indices {
            let block_offset = Int(index * self.blockSize)
            blocks[index].solve(transpose: transpose, numberRHS: 1, Y: &y.data[block_offset], columnStride: y.columnStride)
        }
    }
}

