/*
 <samplecode>
 <abstract>
 Demonstrates advanced usage of iterative methods using user-defined matrix-vector operator and
 preconditioner.
 </abstract>
 </samplecode>
 */

import Foundation
import Accelerate

// This program demonstrates advanced usage of Accelerate's Sparse Solvers by using the
// iterative method GMRES in a matrix-free context with a Block Jacobi preconditioner.

// Two auxilary classes are defined in ElementMatrix.swift and BlockJacobiPreconditioner.swift:
// ElementMatrix             - an implementation of an elemental matrix, with methods to multiply
//                             and to create a preconditioner
// BlockJacobiPreconditioner - implentation of a block jacobi preconditioner with a method to apply

// We also will need to define a couple of helper functions before we begin:

// A simple routine to print status reports from GMRES
func reportStatus(msg: UnsafePointer<CChar>) {
    print("GMRES: ", String(cString: msg), terminator: "")
}

// Unpacks our data from P and applies the preconditioner
// This function must match prototype for Preconditioner.apply() callback
// swiftlint:disable identifier_name
func applyPreconditioner(mem: UnsafeMutableRawPointer, trans: CBLAS_TRANSPOSE, x: DenseMatrix_Double, y: DenseMatrix_Double) {
    let preconditioner = mem.assumingMemoryBound(to: BlockJacobiPreconditioner.self)
    preconditioner.pointee.apply(transpose: trans, x: x, y: y)
}

// We will consider a simple finite element problem with the following grid:
//
//  0 ----- 1 ----- 2 ----- 3
//  |       |       |       |
//  |   A   |   B   |   C   |
//  |       |       |       |
//  4 ----- 5 ----- 6 ----- 7
//  |       |       |       |
//  |   D   |   E   |   F   |
//  |       |       |       |
//  8 ----- 9 ---- 10----- 11
//
// In each element A-F, there are sets of equations that relate the values at nodes 0-11.
// For the purposes of this example, we have a single degree of freedom at each node, and
// further assume the values at 3, 7 and 11 are constrained. Let the elemental matrices
// (the constrains mentioned previously) be as follows:
//
// A: 0 (  0.2  0.1  0.4  0.6 ) B: 1 (  1.0  0.7  7.8  1.1 ) C: 2 (  5.5  0.4 )
//    1 ( -3.0  0.5 -0.5 -2.2 )    2 ( -0.2 -0.2 -0.6  0.9 )    6 ( -0.3  0.2 )
//    4 (  4.5  0.1  0.3  2.0 )    5 (  0.3  0.1  0.8  0.5 )
//    5 ( -0.1 -2.0  0.1  0.3 )    6 (  5.4  1.5  0.1  0.7 )
//
// D: 4 ( -1.5  0.2  0.3  0.7 ) E: 5 (  0.2 -0.6  0.8  0.8 ) F: 6 ( -0.4  0.2 )
//    5 (  0.2  0.1  2.5  0.2 )    6 ( -2.5  0.3 -1.6  0.7 )   10 (  3.1 -0.7 )
//    8 ( -4.5 -2.1  0.3 -4.0 )    9 (  3.1  0.1  0.8  3.5 )
//    9 (  0.1  0.1  1.3  0.1 )   10 (  0.2  0.5  2.8  2.5 )
//
// The fact that 3, 7 and 11 are constrained means that they don't appear in our equation,
// but we will treat them as zero rows and columns to make addressing easier - if we make the
// right-hand side zero and the starting guess for x in those locations zero, then they will
// have no effect on the iterative method's convergence.
var matrix = ElementMatrix(maximumIndex: 12)
matrix.addElement(size: 4, indices: [0, 1, 4, 5],  // A
    values: [ 0.2, -3.0, 4.5, -0.1, 0.1, 0.5, 0.1, -2.0, 0.4, -0.5, 0.3, 0.1, 0.6, -2.2, 2.0, 0.3 ])
matrix.addElement(size: 4, indices: [1, 2, 5, 6],  // B
    values: [ 1.0, -0.2, 0.3, 5.4, 0.7, -0.2, 0.1, 1.5, 7.8, -0.6, 0.8, 0.1, 1.1, 0.9, 0.5, 0.7 ])
matrix.addElement(size: 2, indices: [2, 6],        // C
    values: [ 5.5, 0.4, -0.3, 0.2 ])
matrix.addElement(size: 4, indices: [4, 5, 8, 9],  // D
    values: [-1.5, 0.2, -4.5, 0.1, 0.2, 0.1, -2.1, 0.1, 0.3, 2.5, 0.3, 1.3, 0.7, 0.2, -4.0, 0.1 ])
matrix.addElement(size: 4, indices: [5, 6, 9, 10], // E
    values: [ 0.2, -2.5, 3.1, 0.2, -0.6, 0.3, 0.1, 0.5, 0.8, -1.6, 0.8, 2.8, 0.8, 0.7, 3.5, 2.5 ])
matrix.addElement(size: 2, indices: [6, 10],       // F
    values: [-0.4, 3.1, 0.2, -0.7 ])

// Whilst we could assemble these element matrices to get one large sparse matrix,
// it can be more efficient to just store them separately if we just need to perform
// a matrix-vector multiplication. This is done in the routine doMatrixVector().
//
// To aid convergence, we will build a block-Jacobi preconditioner by assembling only the diagonal
// blocks of the full matrix and factorizing them. This is done in the routine buildPreconditioner().

// We will solve for the right-hand side that is zero, except in positions 2, 6, and 10
// on the basis that those values participate in elements with constrained nodes.
var bdata = [ 0.0, 0.0, 2.5, 0.0, 0.0, 0.0, 1.2, 0.0, 0.0, 0.0, 3.0, 0.0 ]
// swiftlint:disable identifier_name
let b = DenseVector_Double ( count: 12, data: &bdata ) // 3 constrained nodes are just be set to zero.

// Make the initial guess 0.0
var xdata = [ 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ]
let x = DenseVector_Double ( count: 12, data: &xdata )

// Create the preconditioner
var swiftPreconditioner = matrix.buildPreconditioner()

let preconditioner = SparseOpaquePreconditioner_Double(
    type: SparsePreconditionerUser, // User-defined preconditioner. SparseCleanup() will have no effect if called.
    mem: &swiftPreconditioner, // void* pointer passed unchanged to applyPreconditioner()
    apply: applyPreconditioner      // Function pointer for routine to apply the preconditioner
)

// Make the main SparseSolve() call
let status = SparseSolve(
    SparseGMRES(SparseGMRESOptions (
        // We set some options for the method to use
        reportError: reportStatus,      // Report errors via reportStatus() instead of trapping.
        variant: SparseVariantGMRES,    // Use GMRES rather than the default DQGMRES as it's faster for this example
        nvec: 8,                        // Only use 8 vectors for orthagonalization.
        maxIterations: 0,               // Use default
        atol: 0,                        // Use default
        rtol: 0,                        // Use default
        reportStatus: reportStatus      // Also print status every few iterations.
    )),
    // This block specifies how to apply the matrix-multiplication operator
    // We just call our doMatrixVector() routine
    // swiftlint:disable identifier_name
    {(accumulate: Bool, trans: CBLAS_TRANSPOSE, x: DenseVector_Double, y: DenseVector_Double) in
        matrix.multiply(accumulate: accumulate, trans: (trans == CblasTrans), x: x.data, y: y.data)
}, b, x, preconditioner)
// Check the return status and print an error message if we failed to converge
if status != SparseIterativeConverged {
    print("Failed to converge. Returned with error ", status)
    exit(1)
}
// In the output we should see the residual decreasing. Only the residual for the first
// right-hand side is printed, if more information is desired, use SparseIterate() instead.
//   GMRES:     0     4.09e+00
//   GMRES:     1     2.48e+00
//   GMRES:     2     2.24e+00
//   GMRES:     3     2.24e+00
//   GMRES:     4     2.24e+00
//   GMRES:     5     1.42e+00
//   GMRES:     6     1.04e+00
//   GMRES:     7     2.53e-01
//   GMRES:     8     8.53e-02
//   GMRES:    16     1.61e-02
//   GMRES:    24     1.74e-03
//   GMRES:    32     1.18e-04
//   GMRES:    40     1.54e-05
//   GMRES:    48     1.70e-06
//   GMRES:    56     1.60e-07
//   GMRES:    64     1.80e-08

// We can now print the solution. We should get the output:
//   x =  0.11 -0.13 0.36 0.00 0.14 -0.11 0.87 0.00 -0.01 -0.10 0.10 0.00
print("x = ", terminator: " ")
for xv in xdata {
    print(String(format: "%.2f", xv), terminator: " ")
}
print()

