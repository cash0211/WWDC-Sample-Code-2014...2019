/*
 <samplecode>
 <abstract>
 Solve a least squares problem using the iterative method LSMR
 </abstract>
 </samplecode>
 */

import Foundation
import Accelerate

// Note that it is generally recommended that a direct method such as Cholesky
// factorization should be employed except in cases where either:
// * The matrix is not directly available, but multiplication by the matrix is
//   available as a function (i.e. A is in treated as an operator in the mathematical
//   sense).
// * Performance and/or memory constraints make the direct method infeasible.
//
// This is because a problem-specific preconditioner is normally required to
// achieve convergence and/or performance in the iterative method, and as such
// more developer effort is required.

// This program solves the following overdetermined equation via the iterative method LSMR
// to find the least squares solution.
//   ( 2.0  1.0     )     ( 1.200 )
//   ( -0.2 3.2 1.4 ) x = ( 1.013 )
//   (     -0.1 0.5 )     ( 0.205 )
//   ( 2.5  1.1     )     (-0.172 )
// We refer to the 4x3 matrix as A, and the right-hand side vector as b, and are
// hence find a solution to the equation Ax = b. As A is overdetermined (it has more
// rows than columns), for most right-hand sides there will not be an exact solution.
// In this case, it is normally required to find the closest solution, in the sense
// that it minimises the 2-norm of the error. That is, it to solve the optimization
//   min || Ax-b ||_2.
// This is known as the least-squares problem.
//
// We could solve this problem through a direct method such as Sparse QR, however for
// some problems a faster method that provides a "good enough" solution is the iterative
// method LSMR. Unlike direct methods that factorize the matrix A, iterative methods only
// require the ability to multiply by the matrix (and its transpose). They move through
// a sequence of approximate solutions, hopefully converging to the correct answer.
// However, these methods run into numerical difficulties more often than direct methods,
// and resolving these issues requires expert knowledge, and is sometimes impossible.
// The most common method to improve and/or accelerate convergence is to use a preconditioner.
// This is an operator that approximates A^-1, and is hence problem specific. For least-squares
// problems, just using a diagonal matrix with entries equal to the 2-norm of each column
// is often sufficient, and is the method we will use below.

// Whilst we do not need the matrix explicitly to use iterative methods, the accelerate
// framework offers the ability to supply a matrix explicitly if it is available, reducing
// the code required. This ability is used in this example. Matrix data is stored in a format
// known as Compressed Sparse Column (CSC) to store the data. Further,
// as the matrix is symmetric, we only need to store half the data. The CSC format
// stores the matrix as a series of column vectors where only the non-zero entries are
// specified, stored as the pair of (row index, value), although in seperate arrays:
// swiftlint:disable comma
var rowIndices: [Int32] = [   0,    1,   3,   0,   1,    2,   3,   1,   2 ]
var values              = [ 2.0, -0.2, 2.5, 1.0, 3.2, -0.1, 1.1, 1.4, 0.5 ]
// In addition to the (row index, value) pairs we need to specify where each column
// starts in these arrays. It is assumed to continue until the next column starts,
// which is why there is an additional entry in the next array so that the final
// column's length is known.
var columnStarts        = [   0,              3,                   7,        9]
// swiftlint:enable comma
// In this library, this raw information is all wrapper into a flexible data type
// that allows for more complex use cases in other situations.
// swiftlint:disable identifier_name
// swiftlint:disable colon
let a = SparseMatrix_Double(
    // Structure of the matrix, without any values
    structure: SparseMatrixStructure(
        rowCount:     4,
        columnCount:  3,
        columnStarts: &columnStarts,
        rowIndices:   &rowIndices,
        // Matrix meta-data
        attributes: SparseAttributes_t(
            transpose: false,
            triangle: SparseLowerTriangle,  // Irrelevant as kind is SparseOrdinary
            kind: SparseOrdinary,           // We are storing an ordinary matrix
            _reserved: 0,
            _allocatedBySparse: false
        ),
        // For some problems, there may be a blockSize x blockSize block of values associated with
        // each structural matrix entry, rather than a single value. This is not the case in our
        // example, so we set blockSize=1.
        blockSize: 1
    ),
    // Numerical values of the matrix
    data: &values
)

// We define the right-hand side and solution vectors as arrays wrapped in flexible data-types.
// The initial values of x are used as an initial guess of the solution. If no good estimate is
// known, they should be initialised to be all zero.
var bValues = [ 1.200, 1.013, 0.205, -0.172 ]
var xValues = [ 0.0, 0.0, 0.0 ]
let b = DenseVector_Double(
    count: 4,       // Number of entries in the vector, used for error checking
    data:  &bValues // The numerical values
)
let x = DenseVector_Double(
    count: 3,       // Number of entries in the vector, used for error checking
    data:  &xValues // The numerical values
)
// swiftlint:enable colon

// Perform the full LSMR iteration
let status = SparseSolve(SparseLSMR(), a, b, x, SparsePreconditionerDiagScaling)
// Check the return status and print an error message if we failed to converge
if status != SparseIterativeConverged {
    print("Failed to converge. Returned with error %d\n", status)
    exit(1)
}

// Otherwise, iteration successfully converged: print the solution. We should get the output:
//   x =  0.10 0.20 0.30
print("x = ", terminator: " ")
for xv in xValues {
    print(String(format: "%.2f", xv), terminator: " ")
}
print()

