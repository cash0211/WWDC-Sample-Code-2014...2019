# Animating and Denoising a Raytraced Scene

Support dynamic scenes and denoising by extending your ray tracer with Metal Performance Shaders.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [613: Ray Tracing with Metal](https://developer.apple.com/videos/play/wwdc19/613/).
