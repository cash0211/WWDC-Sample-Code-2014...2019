# Using Core Bluetooth Classic

Use Core Bluetooth APIs to discover and communicate with a Bluetooth Classic device.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [901: What's New in Core Bluetooth](https://developer.apple.com/videos/play/wwdc19/901/).
