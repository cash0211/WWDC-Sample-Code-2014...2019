/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The AppDelegate to handle system events.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}

