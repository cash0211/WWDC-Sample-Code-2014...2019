/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view controller that displays a single reservation.
*/

import UIKit
import Intents

class ReservationDetailsViewController: UIViewController {
    var reservation: INReservation?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Donate the reservation when the user sees it
        donateReservation()
    }

    func donateReservation() {
        guard let reservation = reservation, let reservationItemReference = reservation.itemReference else {
            return
        }

        // Since the app is in the reservation detials view controller, it's showing a single reservation.
        // In the intent, indicate the itemReferences of the reservation the user requested in the reservationItemReferences array
        // along with the container reference that serves as a reference to that list of reservations.
        // In this case, since there's only one item in the array, use the same reference for both.
        let intent = INGetReservationDetailsIntent(reservationContainerReference: reservationItemReference,
                                                   reservationItemReferences: [reservationItemReference])
        let intentResponse = INGetReservationDetailsIntentResponse(code: .success, userActivity: nil)
        intentResponse.reservations = [reservation]
        let interaction = INInteraction(intent: intent, response: intentResponse)
        interaction.donate { error in
            if let error = error {
                print(error)
            }
        }
    }
}
