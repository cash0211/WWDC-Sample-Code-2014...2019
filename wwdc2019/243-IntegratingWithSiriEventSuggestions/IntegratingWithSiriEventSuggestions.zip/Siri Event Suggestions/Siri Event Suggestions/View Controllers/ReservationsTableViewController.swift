/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A table view controller that displays a list of individual reservations in a group of reservations.
*/

import UIKit
import Intents

class ReservationsTableViewController: UITableViewController {
    var reservationContainerReference: INSpeakableString?
    var reservations: [INReservation] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        if let reservationContainerReference = reservationContainerReference {
            self.navigationItem.title = reservationContainerReference.spokenPhrase
            if let reservations = Server.sharedInstance.reservations(inReservationContainer: reservationContainerReference) {
                self.reservations = reservations

                // Donate the reservations when the user sees them
                donateReservations()
            }
        }
    }

    // MARK: - UITableViewDataSource
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reservations.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let reservation = reservations[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReservationCell", for: indexPath)
        cell.textLabel?.text = reservation.itemReference?.spokenPhrase
        return cell
    }

    // MARK: - UITableViewDelegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedReservation = reservations[indexPath.row]
        showReservation(selectedReservation)
    }

    // MARK: - Helpers
    fileprivate func showReservation(_ reservation: INReservation) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let reservationDetailsViewController = storyboard.instantiateViewController(withIdentifier: "ReservationDetailsViewController")
            as? ReservationDetailsViewController {
            reservationDetailsViewController.reservation = reservation
            self.present(reservationDetailsViewController, animated: true, completion: nil)
        }
    }

    fileprivate func donateReservations() {
        guard let reservationContainerReference = reservationContainerReference, !reservations.isEmpty else {
            return
        }

        // Since the app is in the list reservations table view controller, it's showing more than one reservation.
        // In the intent, indicate the itemReferences of the reservations the user requested in the reservationItemReferences array
        // along with the container reference that serves as a reference to that list of reservations.
        let reservationItemReferences = reservations.map { $0.itemReference! }
        let intent = INGetReservationDetailsIntent(reservationContainerReference: reservationContainerReference,
                                                   reservationItemReferences: reservationItemReferences)

        let intentResponse = INGetReservationDetailsIntentResponse(code: .success, userActivity: nil)
        intentResponse.reservations = reservations

        let interaction = INInteraction(intent: intent, response: intentResponse)
        interaction.donate { error in
            if let error = error {
                print(error)
            }
        }
    }
}
