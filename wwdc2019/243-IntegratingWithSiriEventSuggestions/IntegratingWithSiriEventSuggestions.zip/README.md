# Integrating with Siri Event Suggestions

Provide deep system integration by sharing reservation details with Siri

## Overview

- Note: This sample code project is associated with WWDC 2019 session [243: Integrating with Siri Event Suggestions](https://developer.apple.com/videos/play/wwdc19/243/).

## Configure the Sample Code Project

- Note: An iOS device is required to run this sample.

Build Requirements: Xcode 11.0, iOS 13.0 SDK Runtime Requirements: iOS 13.0 or later
